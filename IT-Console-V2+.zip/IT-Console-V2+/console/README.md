# IT Console V2+ console（V2-P0 + V2-P2 spike）

獨立新專案，與 repo 根目錄的現行系統**完全無關聯**（不同程式、不同資料庫、不同 port）。

> ⚠️ **開發前必讀（不分人工或 AI agent）**：[`docs/roadmap.md`](docs/roadmap.md)（目前
> 階段與下一步）→ [`docs/capability-manifest.md`](docs/capability-manifest.md)（完成／
> 未完成權威清單）→ [`docs/SESSION_LOG.md`](docs/SESSION_LOG.md) 最新幾筆（上一個
> session 停在哪）。開發到一個段落務必在 `SESSION_LOG.md` 補記錄，規則見 `CLAUDE.md`。

背景與範圍見 [`../README.md`](../README.md)（V2+ 開發文件導覽）。

分支：`v2plus-foundation`。

## 快速開始

```bash
cd console
python -m venv venv
venv\Scripts\activate          # Windows
pip install -r requirements.txt
cp .env.example .env           # 預設 SQLite 絕對路徑即可用，不用改 V2PLUS_DATABASE_URL

python manage.py init-db       # 依 Alembic migration 建表（非 db.create_all()）
python manage.py seed-demo     # 建立 demo-a / demo-b 兩個獨立 Environment 示範隔離

python wsgi.py                 # http://127.0.0.1:8100
```

`seed-demo` 會印出兩組帳號（`demo-a` / `demo-b`，密碼皆為 `DemoPass!12345`）。
分別登入（環境代碼欄位留空，直接用 username/password），選擇 Environment 後再按 Tenant
清單的「進入管理」，驗證彼此看不到對方的 Environment、Managed Tenant UUID 與 accounts 清單。

### 平台管理者：開設環境與使用者

`seed-demo` 之外，平台管理者（`platform_operator`）可以透過網頁介面開設環境與使用者
（不需要每次都寫 CLI 指令）：

```bash
# 第一個平台管理者一定要用 CLI bootstrap（雞生蛋問題：要先有人才能用網頁介面建人）
python manage.py create-principal --display-name "Platform Admin" \
  --platform-username platform-admin --platform-password "ChangeMe!12345" --platform-operator
```

登入後（環境代碼留空）前往 `/platform/environments`：新增環境、新增使用者、把使用者加入
環境並指派角色（`environment_admin` 或 `viewer`）。平台角色**不隱含任何 Environment 資料
存取**——`/platform/` 底下的頁面完全不查 accounts 等業務資料，只操作 Principal／Environment／
Membership（05 §3）。

### 環境管理者：連接 Managed Tenant（BYO app）

環境成員登入並切換到自己的環境後，前往「Managed Tenant」頁（`/microsoft/managed-tenants/`）：

1. 先在您自己的 Entra Tenant 建立一個 App Registration，取得 tenant id／client id／client secret，
   並授予至少 `Organization.Read.All`（測試連線用）。
2. 「新增 Tenant」表單輸入以上資訊；client secret 會用 `V2PLUS_ENCRYPTION_KEY`（Fernet）加密後存入資料庫。
3. 按「測試連線」——會實際呼叫 Microsoft 驗證憑證並比對回傳的 tenant id，成功才會把狀態轉成
   `active`（防止 client_id/secret 屬於錯誤 tenant 卻被誤判成功，見 capability-manifest §4）。
4. 回到 Tenant 清單按該列「進入管理」；目前 Tenant 會鎖定在 server-side session。再從左側
   「查詢功能 → M365 → 帳號管理」按「立即同步」排入 `accounts.sync` 工作。
5. 要管理其他 Tenant 必須回 Tenant 清單重新選擇；功能頁的 URL／表單無法覆寫目前 Tenant，
   `pending`／未測試成功的 Tenant 也不能進入管理。

目前可用 capability 包含帳號、裝置、登入記錄、授權與 MFA 稽核、應用程式稽核、Intune 軟體清冊、Teams 團隊快速同步、SharePoint 網站快速同步、Defender 告警增量同步、資安事件（Incidents）增量同步及跨模組總覽儀表板。所有已開發與後續
capability 都遵守同一規則：一次只操作一個 Tenant，不提供「全部 Tenant」
管理模式。選單沿用 IT Console V2 的左側階層式 sidebar；行動版由左上角按鈕開合。

登入除本地帳號外，另支援 Entra SSO（預設關閉）：設定 `V2PLUS_ENTRA_*` 環境變數
（見 `.env.example`）後，登入頁出現「使用 Entra 帳號登入」；身分繫結固定
`(issuer, subject)`，未綁定的 Entra 身分無法登入——先本地登入後到 `/auth/entra/link` 綁定。

Worker 與 Web 為獨立 process。`.env.example` 已內建開箱即用的 GraphClient factory：

```bash
V2PLUS_GRAPH_CLIENT_FACTORY=app.microsoft.factory:default_graph_client_factory
```

（`MsalTokenBroker` + `HttpGraphClient`，見 `app/microsoft/factory.py`；仍需真實 Entra
Tenant／App Registration 與 `TenantConnection` 設定才能實際打到 Graph，見 `.env.example`
內的三步驟說明。）

**單機自架：不必另開 worker。** `wsgi.py` 啟動時會內嵌一個背景 worker（`app/jobs/embedded.py`），
網頁按「立即同步」後自動處理，所有操作都在 web 上完成。要停用（改跑獨立 worker）時設
`V2PLUS_EMBEDDED_WORKER=false`。

**水平擴充／獨立部署 worker：** 停用內嵌 worker 後，跑一個或多個獨立 worker process：

```bash
python manage.py run-worker
```

SIGTERM／SIGINT 會停止 claim 新工作，等待目前工作完成後退出；`--once` 可供部署 smoke test。
durable queue 的 lease／idempotency／SKIP LOCKED 保證對「內嵌執行緒」或「獨立 process」皆成立。

### Audit chain 簽章與 anchor

```bash
# .env 設 V2PLUS_AUDIT_MASTER_KEY 後：
python manage.py write-audit-anchor --environment demo-a     # 把目前 chain head 簽章寫入本機 anchor 檔
python manage.py verify-audit-chain --environment demo-a             # 只驗內部自洽性
python manage.py verify-audit-chain --environment demo-a --anchor    # 額外比對最新 anchor（可抓「整條被重算」的竄改）
```

anchor 檔案在 `instance/audit_anchors/<slug>.jsonl`（dev/self-host 過渡實作；正式環境目標
是 immutable Blob，見 capability-manifest §3）。

## 為什麼獨立成新專案

依 `../06-migration-roadmap.md` §1 與使用者指示：先在不影響現行系統的前提下驗證
租戶核心（Environment／ManagedTenant／RLS／TenantContext）可行性，之後才視 spike
結果決定併回主程式或維持獨立部署。**不 import 現行系統的 `app/`，不共用 `.env`／DB／port。**

⚠️ `V2PLUS_DATABASE_URL` 刻意不叫 `DATABASE_URL`——本機 shell 常已匯出後者指向現行
系統 Postgres，沿用同名變數會在無提示情況下接錯資料庫（實測踩過，見 capability-manifest §4）。

⚠️ 不要在 `.env` 裡把 `V2PLUS_DATABASE_URL` 設成相對路徑（例如 `sqlite:///instance/xxx.db`）——
留空用預設值（config.py 用 `BASE_DIR` 算出的絕對路徑）最安全；相對路徑在不同 cwd 執行
`manage.py` 時會解析到不存在的檔案（也是實測踩過，見 capability-manifest §4）。

## 測試

```bash
python -m pytest tests/ -v
```

預設全部使用 `sqlite:///:memory:`（符合 AGENTS.md sandbox 規則）。`tests/test_rls_postgres.py`
是 opt-in：需明確設定 `V2PLUS_TEST_DATABASE_URL` 指向一個拋棄式 Postgres DB 才會執行，
未設定時全數 skip（不是靜默通過）。

## PostgreSQL 正式部署（Phase 3 起）

1. 建立**專屬**資料庫（不可指向現行系統的 DB），例如 `it_console_v2plus_dev`。
2. `V2PLUS_DATABASE_URL=postgresql://...` 寫入 `.env`。
3. `python manage.py init-db` 會執行 Alembic migration，含 RLS policy（`ENABLE ROW LEVEL
   SECURITY` + `FORCE ROW LEVEL SECURITY`，見 `migrations/versions/0001_tenancy_kernel.py`）。
4. **手動**建立非 owner、無 `BYPASSRLS` 的應用 DB role（03 §7 表格）；migration 本身不建
   這個 role（屬 IaC／DBA 範疇，09 §7）。

## 目錄結構

```text
console/
  app/
    platform/          # Principal／Environment／Membership／RBAC／audit／audit signing
    control_plane/      # service.py：Principal／Environment／Membership 共用邏輯（CLI + web 共用）
    microsoft/          # ManagedTenant／TenantConnection／HttpGraphClient／MsalTokenBroker／
                         # onboarding_service（BYO app）／encryption（Fernet）
    capabilities/        # accounts（垂直切片，framework-agnostic）
    jobs/               # PgJobQueue durable transport（lease／retry／DLQ／idempotency）
    storage/            # TenantContext／scoped repository／RLS session helper
    web/                # blueprint／forms／templates（唯一可 import flask 的殼層）
      platform/          # /platform/：平台管理者開設 Principal／Environment／Membership
      microsoft/          # /microsoft/managed-tenants/：BYO app 連接 + 測試連線
      auth/、environments/、capabilities/accounts/
  migrations/           # Alembic（唯一 schema 真實來源，禁 db.create_all()）
  tests/
  docs/capability-manifest.md
```

package 邊界依 `../09-development-standards.md` §1；`app/storage/tenant_context.py`、
`app/storage/repository.py`、`app/capabilities/**/service.py` 禁止 import flask
（ADR-007 §4.3：保留日後換殼的能力）。
