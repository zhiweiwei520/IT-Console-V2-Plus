# CLAUDE.md — V2+ console（本目錄專用規則）

本檔案為 `console/` 範圍內的工作規則；衝突時本檔案優先。
**這是一個獨立新專案，不 import、不共用 DB、不共用 port 8000。**

## 開工前（強制）

任何新 session（不論是 Claude、Codex 或其他 agent）在 `console/` 目錄下開始任何
開發工作前，**必須依序讀完**：

1. [`docs/roadmap.md`](docs/roadmap.md) — 目前在哪個階段、下一步是什麼
2. [`docs/capability-manifest.md`](docs/capability-manifest.md) — 目前完成／未完成的權威清單
3. [`docs/SESSION_LOG.md`](docs/SESSION_LOG.md) 最新 3～5 筆 — 上一個 session 做了什麼、停在哪、有沒有交接事項

不得跳過直接動手，否則容易重工或忽略上一個 session 留下的阻塞點。

## 收工前（強制）

開發到一個段落（完成任務、遇到阻塞、或對話即將結束）**必須**依
`docs/SESSION_LOG.md` 的範本補一筆記錄，加在檔案最上方（最新記錄在最上面）。
沒有記錄等於這次工作對下一個 session 不存在——這是唯一的交接機制。

`docs/capability-manifest.md` 若有新完成或新發現的落差，同一輪也要更新（它是
「現況快照」，`SESSION_LOG.md` 是「歷程」，兩者都要維護，不能只寫一個）。

## 本目錄的環境變數陷阱（已實測踩過，見 capability-manifest.md §4）

- `V2PLUS_DATABASE_URL` 留空用預設絕對路徑；**不要**設成相對路徑（`sqlite:///instance/...`）。
- 一律用 `V2PLUS_*` 前綴的環境變數，不要用跟 repo 根目錄同名的變數（例如 `DATABASE_URL`）。
- Server 只用 `manage.py` 或 preview 工具啟動；不要手動另開 `python wsgi.py`，多個
  process 疊在同一 port 會製造難以復現的假性 bug。

## 測試

`FLASK_ENV=testing python -m pytest tests/ -q`；一律 `sqlite:///:memory:`（AGENTS.md
sandbox 規則）。`tests/test_rls_postgres.py` 是 opt-in，需 `V2PLUS_TEST_DATABASE_URL`
指向使用者明確核准的拋棄式 Postgres。
