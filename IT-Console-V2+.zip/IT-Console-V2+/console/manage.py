"""
manage.py — V2+ console 管理 CLI（獨立於 repo 根目錄 manage.py）。

用法：
    python manage.py init-db
    python manage.py create-principal --display-name "Alice" --platform-username alice --platform-password "ChangeMe!12345"
    python manage.py create-principal --display-name "Ops" --platform-username ops --platform-password "ChangeMe!12345" --platform-operator
    python manage.py create-environment --slug acme --name "Acme Corp"
    python manage.py create-managed-tenant --environment acme --entra-tenant-id 11111111-1111-1111-1111-111111111111 --display-name "Acme Prod Tenant"
    python manage.py add-membership --environment acme --username alice --role environment_admin --all-tenants
    python manage.py seed-demo          # 建立兩個獨立 Environment 示範隔離（08 §5 spike 驗收用）
    python manage.py run-worker --once
    python manage.py write-audit-anchor --environment acme      # 需先設 V2PLUS_AUDIT_MASTER_KEY
    python manage.py verify-audit-chain --environment acme --anchor
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import signal
import socket
import sys
import uuid

from app import create_app
from app.extensions import db


def cmd_init_db(app, _args):
    """依 Alembic migration 建表（禁止 db.create_all()，見 09-development-standards.md §7）。"""
    from flask_migrate import upgrade as migrate_upgrade

    with app.app_context():
        migrate_upgrade()

        from app.platform.models import ManagementEnvironment
        from app.platform.permissions import ensure_builtin_permissions, ensure_environment_builtin_roles
        ensure_builtin_permissions()
        for environment_id in db.session.execute(
            db.select(ManagementEnvironment.id)
        ).scalars():
            ensure_environment_builtin_roles(environment_id)
        print("[init-db] 完成：schema 已升級至 head，權限目錄已同步。")


def cmd_create_principal(app, args):
    from app.control_plane.service import create_principal

    with app.app_context():
        try:
            principal = create_principal(
                args.display_name,
                platform_username=args.platform_username,
                platform_password=args.platform_password,
                platform_operator=args.platform_operator,
            )
        except ValueError as exc:
            print(f"錯誤：{exc}", file=sys.stderr)
            sys.exit(1)
        print(f"[create-principal] principal_id={principal.id} display_name={principal.display_name} "
              f"platform_operator={args.platform_operator}")


def cmd_create_environment(app, args):
    from app.control_plane.service import create_environment

    with app.app_context():
        try:
            env = create_environment(args.slug, args.name)
        except ValueError as exc:
            print(f"錯誤：{exc}", file=sys.stderr)
            sys.exit(1)
        print(f"[create-environment] environment_id={env.id} slug={env.slug}")


def cmd_create_managed_tenant(app, args):
    from app.platform.models import ManagementEnvironment
    from app.microsoft.models import ManagedTenant

    with app.app_context():
        env = ManagementEnvironment.query.filter_by(slug=args.environment).first()
        if env is None:
            print(f"錯誤：找不到環境 '{args.environment}'", file=sys.stderr)
            sys.exit(1)
        tenant = ManagedTenant(
            environment_id=env.id,
            entra_tenant_id=args.entra_tenant_id,
            display_name=args.display_name,
            status="active",
        )
        db.session.add(tenant)
        db.session.commit()
        print(f"[create-managed-tenant] managed_tenant_id={tenant.id}")


def cmd_add_membership(app, args):
    from app.control_plane.service import add_membership
    from app.microsoft.models import ManagedTenant
    from app.platform.models import ManagementEnvironment, PlatformLocalLogin
    from app.platform.security import normalize_username

    with app.app_context():
        env = ManagementEnvironment.query.filter_by(slug=args.environment).first()
        if env is None:
            print(f"錯誤：找不到環境 '{args.environment}'", file=sys.stderr)
            sys.exit(1)
        login = PlatformLocalLogin.query.filter_by(normalized_username=normalize_username(args.username)).first()
        if login is None:
            print(f"錯誤：找不到平台帳號 '{args.username}'", file=sys.stderr)
            sys.exit(1)

        tenant_ids = []
        if not args.all_tenants:
            for tenant_slug_or_id in (args.tenant or []):
                tenant = ManagedTenant.query.filter_by(environment_id=env.id, id=tenant_slug_or_id).first()
                if tenant is None:
                    print(f"警告：找不到 managed_tenant_id '{tenant_slug_or_id}'，略過", file=sys.stderr)
                    continue
                tenant_ids.append(tenant.id)

        try:
            membership = add_membership(
                env, login.principal, role_code=args.role,
                all_managed_tenants=args.all_tenants, managed_tenant_ids=tenant_ids,
            )
        except ValueError as exc:
            print(f"錯誤：{exc}", file=sys.stderr)
            sys.exit(1)
        print(f"[add-membership] membership_id={membership.id} role={args.role} all_tenants={args.all_tenants}")


def cmd_seed_demo(app, _args):
    """建立兩個獨立 Environment，各一個使用者、一個 Managed Tenant 與示範帳號（隔離測試手動驗收用）。"""
    from app.platform.models import (
        EnvironmentMembership, ManagementEnvironment, Principal,
        PlatformLocalLogin, RoleAssignment,
    )
    from app.microsoft.models import ManagedTenant
    from app.platform.permissions import ensure_builtin_permissions, ensure_environment_builtin_roles
    from app.platform.security import hash_password, normalize_username
    from app.capabilities.accounts.service import seed_demo_accounts
    from app.capabilities.devices.service import seed_demo_devices
    from app.capabilities.signin_logs.service import seed_demo_sign_in_logs
    from app.storage.time_utils import utc_now_naive

    with app.app_context():
        ensure_builtin_permissions()

        for label in ("a", "b"):
            slug = f"demo-{label}"
            env = ManagementEnvironment.query.filter_by(slug=slug).first()
            if env is None:
                env = ManagementEnvironment(slug=slug, name=f"Demo Environment {label.upper()}", status="active")
                db.session.add(env)
                db.session.commit()
            roles = ensure_environment_builtin_roles(env.id)

            username = f"demo-{label}"
            login = PlatformLocalLogin.query.filter_by(normalized_username=username).first()
            if login is None:
                principal = Principal(display_name=f"Demo User {label.upper()}")
                db.session.add(principal)
                db.session.flush()
                login = PlatformLocalLogin(
                    principal_id=principal.id,
                    normalized_username=username,
                    password_hash=hash_password("DemoPass!12345"),
                )
                db.session.add(login)
                db.session.commit()

            membership = EnvironmentMembership.query.filter_by(
                environment_id=env.id, principal_id=login.principal_id,
            ).first()
            if membership is None:
                membership = EnvironmentMembership(
                    environment_id=env.id, principal_id=login.principal_id, all_managed_tenants=True,
                )
                db.session.add(membership)
                db.session.flush()
                db.session.add(RoleAssignment(
                    environment_id=env.id, membership_id=membership.id,
                    role_id=roles["environment_admin"].id, granted_at=utc_now_naive(),
                ))
                db.session.commit()

            tenant = ManagedTenant.query.filter_by(environment_id=env.id).first()
            if tenant is None:
                tenant = ManagedTenant(
                    environment_id=env.id,
                    entra_tenant_id=str(uuid.uuid4()),
                    display_name=f"Demo Tenant {label.upper()}",
                    status="active",
                )
                db.session.add(tenant)
                db.session.commit()
                seed_demo_accounts(db.session, environment_id=env.id, managed_tenant_id=tenant.id)
                seed_demo_devices(db.session, environment_id=env.id, managed_tenant_id=tenant.id)
                seed_demo_sign_in_logs(db.session, environment_id=env.id, managed_tenant_id=tenant.id)
                db.session.commit()

            print(f"[seed-demo] environment={slug} username={username} password=DemoPass!12345 "
                  f"environment_id={env.id} managed_tenant_id={tenant.id}")

        print("\n驗收方式：兩組帳號分別以 environment_slug=demo-a / demo-b 登入 /auth/login，"
              "確認彼此看不到對方的 accounts 清單與 UUID。")


def cmd_run_worker(app, args):
    """啟動 durable Worker；收到 signal 後停止 claim 並 drain 目前工作。"""
    factory_path = os.environ.get("V2PLUS_GRAPH_CLIENT_FACTORY", "").strip()
    if not factory_path:
        raise SystemExit(
            "錯誤：未設定 V2PLUS_GRAPH_CLIENT_FACTORY（格式：package.module:factory）。"
        )

    from app.jobs.bootstrap import build_handlers, load_graph_client_factory
    from app.jobs.process import WorkerProcess
    from app.jobs.worker import WorkerMetrics, WorkerRunner

    with app.app_context():
        graph_client_factory = load_graph_client_factory(factory_path)
        metrics = WorkerMetrics()
        worker_id = args.worker_id or f"{socket.gethostname()}-{os.getpid()}"
        runner = WorkerRunner(
            db.session,
            build_handlers(db.session, graph_client_factory),
            worker_id=worker_id,
            lease_seconds=args.lease_seconds,
            metrics=metrics,
        )
        process = WorkerProcess(
            db.session,
            runner,
            poll_seconds=args.poll_seconds,
            metrics_callback=(
                lambda snapshot: print(json.dumps(snapshot, ensure_ascii=False), flush=True)
                if args.metrics_stdout else None
            ),
        )

        def _request_stop(_signum, _frame):
            process.request_stop()

        signal.signal(signal.SIGINT, _request_stop)
        if hasattr(signal, "SIGTERM"):
            signal.signal(signal.SIGTERM, _request_stop)

        if args.once:
            asyncio.run(process.run_cycle())
        else:
            asyncio.run(process.run_forever())
        print(json.dumps(metrics.snapshot(), ensure_ascii=False), flush=True)


def cmd_write_audit_anchor(app, args):
    """把指定 Environment 目前的 audit chain head 簽章寫入本機 anchor 檔（05 §5 過渡實作）。"""
    from app.platform.audit_anchor import LocalFileAuditAnchorWriter
    from app.platform.audit_signing import AuditSigningKeyUnavailable
    from app.platform.models import EnvironmentAuditChainHead, ManagementEnvironment

    with app.app_context():
        env = ManagementEnvironment.query.filter_by(slug=args.environment).first()
        if env is None:
            print(f"錯誤：找不到環境 '{args.environment}'", file=sys.stderr)
            sys.exit(1)
        head = db.session.get(EnvironmentAuditChainHead, env.id)
        if head is None:
            print(f"錯誤：環境 '{args.environment}' 尚無任何 audit 紀錄，無 chain head 可簽", file=sys.stderr)
            sys.exit(1)

        writer = LocalFileAuditAnchorWriter(app.config["INSTANCE_DIR"] / "audit_anchors")
        try:
            record = writer.write(
                environment_id=env.id, environment_slug=env.slug,
                chain_sequence=head.last_sequence, chain_hash=head.last_hash,
            )
        except AuditSigningKeyUnavailable as exc:
            print(f"錯誤：{exc}", file=sys.stderr)
            sys.exit(1)
        print(f"[write-audit-anchor] environment={env.slug} chain_sequence={record.chain_sequence} "
              f"chain_hash={record.chain_hash}")


def cmd_verify_audit_chain(app, args):
    """驗證 Environment 的 audit chain 內部自洽性；--anchor 額外比對最新 anchor 檢查點。"""
    from app.platform.audit import verify_audit_chain, verify_chain_against_anchor
    from app.platform.audit_anchor import LocalFileAuditAnchorWriter
    from app.platform.audit_signing import AuditSigningKeyUnavailable
    from app.platform.models import ManagementEnvironment

    with app.app_context():
        env = ManagementEnvironment.query.filter_by(slug=args.environment).first()
        if env is None:
            print(f"錯誤：找不到環境 '{args.environment}'", file=sys.stderr)
            sys.exit(1)

        if args.anchor:
            writer = LocalFileAuditAnchorWriter(app.config["INSTANCE_DIR"] / "audit_anchors")
            anchor = writer.latest(env.slug)
            if anchor is None:
                print(f"錯誤：環境 '{args.environment}' 尚無 anchor 記錄，先跑 write-audit-anchor", file=sys.stderr)
                sys.exit(1)
            try:
                result = verify_chain_against_anchor(env.id, anchor)
            except AuditSigningKeyUnavailable as exc:
                print(f"錯誤：{exc}", file=sys.stderr)
                sys.exit(1)
        else:
            result = verify_audit_chain(env.id)

        status = "VALID" if result.valid else "INVALID"
        print(f"[verify-audit-chain] environment={env.slug} status={status} "
              f"entry_count={result.entry_count} error={result.error or '-'}")
        if not result.valid:
            sys.exit(1)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="V2+ console 管理 CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("init-db")

    p = sub.add_parser("create-principal")
    p.add_argument("--display-name", required=True)
    p.add_argument("--platform-username")
    p.add_argument("--platform-password")
    p.add_argument("--platform-operator", action="store_true",
                    help="授予 platform_operator（Control Plane 權限，不隱含任何 Environment 資料存取）")

    p = sub.add_parser("create-environment")
    p.add_argument("--slug", required=True)
    p.add_argument("--name", required=True)

    p = sub.add_parser("create-managed-tenant")
    p.add_argument("--environment", required=True, help="Environment slug")
    p.add_argument("--entra-tenant-id", required=True)
    p.add_argument("--display-name", required=True)

    p = sub.add_parser("add-membership")
    p.add_argument("--environment", required=True, help="Environment slug")
    p.add_argument("--username", required=True, help="platform local login username")
    p.add_argument("--role", required=True, help="environment role code")
    p.add_argument("--all-tenants", action="store_true")
    p.add_argument("--tenant", action="append", help="managed_tenant_id（可重複；--all-tenants 時忽略）")

    sub.add_parser("seed-demo")

    p = sub.add_parser("run-worker")
    p.add_argument("--once", action="store_true", help="執行一輪 claim 後退出")
    p.add_argument("--worker-id", help="Worker lease owner ID（預設 hostname-pid）")
    p.add_argument("--lease-seconds", type=int, default=300)
    p.add_argument("--poll-seconds", type=float, default=2.0)
    p.add_argument("--metrics-stdout", action="store_true", help="每輪輸出 JSON metrics")

    p = sub.add_parser("write-audit-anchor")
    p.add_argument("--environment", required=True, help="Environment slug")

    p = sub.add_parser("verify-audit-chain")
    p.add_argument("--environment", required=True, help="Environment slug")
    p.add_argument("--anchor", action="store_true", help="額外比對最新 anchor 檢查點（需先跑過 write-audit-anchor）")

    return parser


COMMANDS = {
    "init-db": cmd_init_db,
    "create-principal": cmd_create_principal,
    "create-environment": cmd_create_environment,
    "create-managed-tenant": cmd_create_managed_tenant,
    "add-membership": cmd_add_membership,
    "seed-demo": cmd_seed_demo,
    "run-worker": cmd_run_worker,
    "write-audit-anchor": cmd_write_audit_anchor,
    "verify-audit-chain": cmd_verify_audit_chain,
}


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    app = create_app()
    COMMANDS[args.command](app, args)


if __name__ == "__main__":
    main()
