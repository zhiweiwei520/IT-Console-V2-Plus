# Capability Manifest — V2+ console（V2-P0 + V2-P2 spike）

> 對應 `../06-migration-roadmap.md` §2 Phase 0／2 與 `../08-decision-log-and-backlog.md` §5
> 前置 Spike 驗收清單。本文件是「這個 spike 實際做了什麼／刻意沒做什麼」的權威清單，
> 供下一階段（Phase 3 起）或審查者快速對齊範圍，避免誤以為某項已完成。
>
> 另見 [`roadmap.md`](roadmap.md)（往前的階段規劃）與 [`SESSION_LOG.md`](SESSION_LOG.md)
> （逐次開發歷程，append-only）。三份文件搭配使用：本檔是「現況快照」，roadmap 是
> 「計畫」，SESSION_LOG 是「歷史」。

## 1. 範圍與定位

獨立新專案，位於 `console/`，與原 IT Console V2 主專案根目錄 `app/`、`config.py`、`manage.py`、
資料庫**完全無關聯**（不 import、不共用 DB、不共用 port 8000）。分支：`v2plus-foundation`。

目的：驗證 08 §5 spike 驗收條件的可行性子集——

- [x] Accounts 垂直切片可在同一產品內切兩個獨立 Environment。
- [x] A1 測試 Entra Tenant／App Registration 已由使用者確認在 Claude 接續開發期間完成基本驗證；細部 endpoint evidence 仍須由對應 Session Log 補登，不視為本輪重新執行。
- [x] 另一 Environment 使用者無法以任何 route／ID／DB query 讀到該資料（repository 層，SQLite 已驗證；RLS 層見下方已知落差）。
- [ ] Provider App bundle 兩個全域唯一 Tenant 完成 consent／撤銷 —— `HttpGraphClient`／`MsalTokenBroker`／`TenantGraphClientFactory` 機制、BYO app 自助連接 web UI 與單元測試已完成，且**失敗路徑已用真實 Microsoft OIDC discovery 端到端驗證過**（瀏覽器實測填入不存在的 tenant id，「測試連線」正確回報失敗、不 500、狀態維持 pending）；**成功路徑仍未跑過**（缺真實 Entra Tenant + 有效 App Registration，見 §3）。Provider App bundle（多租戶單一 App）與跨環境全域唯一 claim（04 §4）本身也還沒做，目前只有 BYO app（客戶自建 App）一種模式。
- [ ] Service Bus 重送／Worker crash 不重複寫資料 —— PostgreSQL queue、lease recovery、handler checkpoint／冪等與 graceful drain 已驗證；Service Bus adapter 尚未做（Phase 5）。
- [x] pooled RLS 與 dedicated DB 共用同一 repository API（`ScopedRepository`／`TenantScopedRepository` 不依賴連線模式）。

## 2. 已完成

| 項目 | 位置 | 對應文件 |
|---|---|---|
| 租戶核心 schema（Principal／ManagementEnvironment／EnvironmentMembership／EnvironmentRole／RoleAssignment／ManagedTenant／MembershipTenantGrant／EnvironmentLocalLogin／PlatformLocalLogin／PlatformRoleAssignment／ExternalLogin） | `app/platform/models.py`、`app/microsoft/models.py` | 03 §3 |
| 框架無關 `TenantContext` | `app/storage/tenant_context.py` | 03 §6、09 §2、ADR-007 §4.3 |
| Scoped repository（禁止無 scope `all()`/`get(id)`） | `app/storage/repository.py` | 09 §2 |
| PostgreSQL RLS policy（environment-only ＋ tenant-grant subquery 兩種樣式） | `migrations/versions/0001_tenancy_kernel.py` | 03 §7 |
| Alembic migration（禁用 `db.create_all()` 於 production 路徑） | `migrations/` | 09 §7 |
| 本地登入（platform break-glass + environment-local） | `app/web/auth/` | 04 §3（SSO 替代路徑）、05 §2 |
| Session 式環境切換 + membership version 重新驗證；單一目前 Tenant session scope（功能頁不可由 query/form 覆寫，環境切換／登出／授權失效自動清除） | `app/web/context.py`、`app/web/environments/`、`app/web/microsoft/routes.py` | 03 §6、03 §9、D-20 |
| accounts capability 垂直切片（models/repository/service/routes/templates） | `app/capabilities/accounts/`、`app/web/capabilities/accounts/` | 08 §5 |
| devices capability 垂直切片（Intune `/deviceManagement/managedDevices`；roadmap Phase B2「形狀不同」模組：多數欄位可為空、只 `id` 必填、`deviceName` 缺值退回 source id）；含 dispatcher／handler／分頁 checkpoint／full-sync finalize，與 accounts 平行 | `app/capabilities/devices/`、`app/web/capabilities/devices/` | roadmap Phase B2 |
| signin_logs capability 垂直切片（Entra `/auditLogs/signIns`；roadmap Phase B3 差異最大模組：**watermark 增量**＋`$filter=createdDateTime ge` 時間區間＋初始 24h 視窗控量＋**append-only 不刪除**；`ge`＋冪等 upsert 邊界不漏不重；ISO→naive UTC 解析）；checkpoint 多 `window_start`，resume 沿用不重算 | `app/capabilities/signin_logs/`、`app/web/capabilities/signin_logs/` | roadmap Phase B3 |
| licenses／MFA 稽核（`/subscribedSkus` + `userRegistrationDetails` 雙階段 durable sync、checkpoint resume、Tenant-scoped models/repository、route/sidebar/RBAC、0008 migration + PostgreSQL RLS policy）；專屬 worker、單一 Tenant 防竄改與 migration 測試完成，整合 evidence 持續補登 | `app/capabilities/licenses/`、`app/web/capabilities/licenses/`、`tests/test_licenses_capability.py` | roadmap Phase C1（程式完成） |
| app_audit（`/applications` + `/servicePrincipals` 雙階段 durable sync；App Registration 憑證到期、sign-in audience 與 Enterprise App 啟用／類型快取；Tenant-scoped repository、RBAC/sidebar、0009 migration + RLS）；專屬 worker、防竄改與 migration 測試完成，owners／permissions 下鑽及整合 evidence 持續補登 | `app/capabilities/app_audit/`、`app/web/capabilities/app_audit/`、`tests/test_app_audit_capability.py` | roadmap Phase C2（程式完成） |
| software（Graph v1.0 `/deviceManagement/detectedApps` 全量分頁同步；名稱／版本／發行者／平台／大小／裝置數；Tenant-scoped repository、RBAC/sidebar、0010 migration + RLS）；專屬 worker、防竄改與 migration 測試完成 | `app/capabilities/software/`、`app/web/capabilities/software/`、`tests/test_software_capability.py` | roadmap Phase C3（程式完成） |
| teams 快速同步骨架（groups/team、channels、members、owners、installedApps；五維度快取中活躍度明確標記 `not_collected`；Tenant-scoped repository、RBAC/sidebar、0011 migration + RLS）；專屬 worker、單一 Tenant 防竄改與 migration 測試完成並通過（專屬＋migration 4 passed，全套 195 passed／3 skipped）；真實 Teams/Graph evidence 待補 | `app/capabilities/teams/`、`app/web/capabilities/teams/`、`tests/test_teams_capability.py` | roadmap Phase C4（程式／測試完成） |
| sharepoint 網站快速同步（v1.0 `/sites?search=*` 分頁列舉＋逐站 `/drives` 補文件庫數與容量；外部共享／活躍度明確標記 `not_collected`；Tenant-scoped repository、RBAC/sidebar、0012 migration + RLS）；專屬 worker、單一 Tenant 防竄改與 migration 測試完成並通過（專屬＋migration 4 passed，全套 197 passed／3 skipped）；真實 SharePoint/Graph evidence 待補 | `app/capabilities/sharepoint/`、`app/web/capabilities/sharepoint/`、`tests/test_sharepoint_capability.py` | roadmap Phase C5（程式／測試完成） |
| defender 告警快速同步（v1.0 `/security/alerts_v2`；形狀最接近 signin_logs：**watermark 增量**＋`$filter=createdDateTime ge` 時間區間＋初始 30 天視窗＋**append-only 不刪除**，狀態可變故重抓時 upsert 更新；首個用 Security 類權限 `SecurityAlert.Read.All` 而非 Directory/Sites 類；Tenant-scoped repository、RBAC/sidebar、0013 migration + RLS）；專屬 worker（含 watermark $filter 斷言）、單一 Tenant 防竄改與 migration 測試完成並通過（專屬＋migration 4 passed，全套 199 passed／3 skipped）；真實 Defender/Graph evidence 待補 | `app/capabilities/defender/`、`app/web/capabilities/defender/`、`tests/test_defender_capability.py` | roadmap Phase C6（程式／測試完成） |
| sentinel 資安事件快速同步（v1.0 `/security/incidents`；使用者拍板以 Graph incidents 取代原列 Azure Monitor／Log Analytics，與 C6 共用 client/token 基礎、零安全邊界變更；同 defender 形狀：**watermark 增量**＋初始 30 天視窗＋**append-only 不刪除**，狀態可變故重抓時 upsert 更新；需 `SecurityIncident.Read.All`；Tenant-scoped repository、RBAC/sidebar、0014 migration + RLS）；專屬 worker（含 watermark $filter 斷言）、單一 Tenant 防竄改與 migration 測試完成並通過（專屬＋migration 4 passed，全套 201 passed／3 skipped）；真實 Graph evidence 待補 | `app/capabilities/sentinel/`、`app/web/capabilities/sentinel/`、`tests/test_sentinel_capability.py` | roadmap Phase C7（程式／測試完成） |
| 顯示層時區鐵則落實（root CLAUDE.md B2）：`to_taipei_str`（naive UTC datetime／Graph ISO 字串 → UTC+8；None→"—"；無法解析原樣回傳不 500）＋Jinja filter `datetime_local`；signin_logs／defender／sentinel／sharepoint 模板改用、標頭改「(UTC+8)」——清償 B3 交接掛號的顯示層時區債；Taipei 固定 +8 無 DST 故用固定位移、不引入 tzdata | `app/storage/time_utils.py`、`app/__init__.py`、四個 list.html、`tests/test_time_display.py` | B2 鐵則（含瀏覽器實測 evidence，見 SESSION_LOG 2026-07-12） |
| Entra SSO 使用者登入機制（Phase D：`EntraAuthBroker` 委由 MSAL `initiate/acquire_token_by_auth_code_flow`——內建 state/nonce/PKCE/id_token 驗證，**不自刻 JWT 驗證**；authority 僅允許 `login.microsoftonline.com` 並轉譯 MSAL 建構子 ValueError（§4 坑）；身分繫結固定 `(iss, sub)`、缺一即拒、**禁 email/UPN fallback**；`/auth/entra/{login,link,callback}`——未綁定登入 fail-closed 不自動開帳號、已綁他人拒絕重綁、SSO 未設定一律 404；預設關閉，`V2PLUS_ENTRA_*` 環境變數啟用；`ExternalLogin` model 既有故無新 migration）；mocked-IdP 測試 16 passed（全套 219 passed／3 skipped）；**真實 IdP 端到端（D1/D4）待 A1 Login App** | `app/microsoft/sso.py`、`app/web/auth/routes.py`、`config.py`、`tests/test_entra_sso.py` | roadmap Phase D（D2/D3 程式／測試完成） |
| CI/CD skeleton（Phase A4／EPIC-09 起步：GitHub Actions——`test` job 跑 pytest（sqlite in-memory，RLS opt-in 維持 skip）＋`audit` job 跑 pip-audit 鎖版掃描；paths 過濾只涵蓋 `console/**`；**repo 尚無 git remote，屬 dormant skeleton**，push 上 GitHub 即生效，屆時設 required checks） | `.github/workflows/v2plus-console-ci.yml`（repo 根目錄） | roadmap Phase A4（skeleton 完成） |
| dashboard 跨模組唯讀 KPI 聚合（十個 capability 的 per-Tenant 計數卡；**後端依權限條件查詢**——無 `<ns>.view` 的模組根本不查、不進 context，template 不可能洩漏數字，符合 root CLAUDE.md Issue #5；計數借用 `_ScopedCount(TenantScopedRepository)` 沿用單一目前 Tenant fail-closed scoping；無自己的 model/sync/migration，theme.css append `.v2c-kpi-*`）；service 權限 gating 與 web 唯讀測試完成並通過（dashboard 2 passed，全套 203 passed／3 skipped） | `app/capabilities/dashboard/`、`app/web/capabilities/dashboard/`、`tests/test_dashboard.py` | roadmap Phase C8（程式／測試完成） |
| Append-only Environment audit + 每 Environment SHA-256 hash chain／chain head／驗證器 | `app/platform/audit.py`、`app/platform/models.py::EnvironmentAuditLog` | 05 §5、09 §9 |
| Per-Environment audit signing key（HMAC-SHA256 從單一 master key 派生，不需逐一 provision）+ chain head 簽章 + 本機檔案 anchor writer/verifier（`write-audit-anchor`／`verify-audit-chain --anchor`），可偵測「內部自洽但整條被重算」的竄改與 rewind | `app/platform/audit_signing.py`、`app/platform/audit_anchor.py`、`manage.py` | 05 §5 |
| Environment-scoped `PgJobQueue`（冪等 enqueue、SKIP LOCKED claim、lease／heartbeat、延遲 retry、DLQ） | `app/jobs/models.py`、`app/jobs/queue.py` | 09 §6、11 §3.3 |
| accounts.sync Dispatcher／Worker handler（scope/permission 重驗證、Graph 分頁 checkpoint、冪等 upsert、crash resume） | `app/jobs/dispatcher.py`、`app/jobs/worker.py`、`app/capabilities/accounts/handler.py` | 02 §6、07 §4 |
| Worker production lifecycle（跨 Environment fair polling、SIGTERM/SIGINT drain、JSON metrics、factory bootstrap） | `app/jobs/process.py`、`app/jobs/bootstrap.py`、`manage.py run-worker` | 05 §8、11 §3.3 |
| 內嵌背景 worker（單機自架 web-only：`wsgi.py` 啟動時於 daemon thread 跑 `WorkerProcess.run_forever()`，網頁排入的 job 自動處理，不必另開 CLI；預設開、`V2PLUS_EMBEDDED_WORKER=false` 停用改跑獨立 worker；只由 web 入口啟動，不影響 manage.py／pytest） | `app/jobs/embedded.py`、`wsgi.py` | 使用者需求：所有操作在 web 完成 |
| `HttpGraphClient`（v1.0-only endpoint allowlist、429/5xx/401/403 分類、Retry-After 解析與 clamp、`@odata.nextLink` 分頁） | `app/microsoft/graph_client.py` | 04 §7、09 §8 |
| `MsalTokenBroker`（cache key = credential_profile_id+version+entra_tenant_id+cloud+resource+scope hash、cloud/resource allowlist、MSAL 錯誤碼映射） | `app/microsoft/token_broker.py` | 04 §6 |
| `EnvironmentCredentialProvider`（`env:V2PLUS_*` allowlist，Key Vault 前的 dev/self-host 過渡方案） | `app/microsoft/credentials.py` | 11 §3.2、04 §2 |
| `TenantGraphClientFactory` + 開箱即用 `default_graph_client_factory`（`V2PLUS_GRAPH_CLIENT_FACTORY` 預設值，token broker 跨呼叫單例） | `app/microsoft/factory.py` | 04 §6 |
| accounts.sync handler 正確轉譯 `GraphRetryableError`／`GraphTerminalError`（尊重真實 Retry-After、401/403 立即 dead-letter 並將 TenantConnection 降級 degraded） | `app/capabilities/accounts/handler.py` | 04 §7 |
| GraphClient／TokenBroker／CredentialProvider／Factory 單元測試（httpx MockTransport、mocked MSAL app，零真實網路） | `tests/test_graph_client.py`、`tests/test_token_broker.py`、`tests/test_credentials.py`、`tests/test_graph_client_factory.py` | 07 §2 Contract |
| Audit signing／anchor 測試（key 派生、簽章竄改偵測、「內部自洽但整條重算」攻擊偵測、rewind 偵測） | `tests/test_audit_anchor.py` | 07 §2 |
| 隔離測試（SQLite repository 層 + Web 層 IDOR/session 竄改/membership version） | `tests/test_repository_isolation.py`、`tests/test_auth_flow.py` | 07 §3（子集） |
| Migration↔Model 漂移防護測試 | `tests/test_migration_sqlite.py` | 09 §7 |
| IT Console V2 同型左側階層 sidebar（查詢功能 → M365）、行動版開合、permission gating；Anti-Slop 前端規範（`.v2c-*`、單一 theme.css、dark/light） | `app/static/css/theme.css`、`app/static/js/theme.js`、`app/templates/base.html` | 11 §3.5、D-20 |
| Control Plane service 層（`create_principal`／`create_environment`／`add_membership`，CLI 與 web 路由共用同一份邏輯） | `app/control_plane/service.py` | 09 §1、11 §7 |
| 平台管理者 Web UI（`/platform/`：開設 Principal、Environment、指派 Membership／角色；`require_platform_operator` 守門，不隱含任何 Environment 資料存取） | `app/web/platform/` | 05 §3、11 §7 |
| Managed Tenant BYO app 自助連接 Web UI（`/microsoft/managed-tenants/`：新增 Tenant 表單、測試連線） | `app/microsoft/onboarding_service.py`、`app/web/microsoft/` | 04 §2、04 §4（簡化版） |
| BYO app client secret 加密存 DB（Fernet，`V2PLUS_ENCRYPTION_KEY`）+ `DatabaseEncryptedCredentialProvider`／`CompositeCredentialProvider`（env: / db: 兩種 scheme），使用者可透過網頁表單自助輸入，不需維運人員先手動設 OS 環境變數 | `app/microsoft/encryption.py`、`app/microsoft/credentials.py`、`migrations/versions/0005_*` | 11 §3.2、04 §2 |
| `TenantGraphClientFactory.include_pending`：「測試連線」這個動作本身要驗證一個還沒被信任的連線，需要明確繞過「只信任 active 連線」的 fail-closed 預設 | `app/microsoft/factory.py` | 09 §2 |
| Tenant 清單「進入管理」鎖定單一 session Tenant；accounts／devices／signin_logs 清單與同步只使用該 Tenant，repository 缺 active Tenant 直接 fail-closed，pending 一律拒絕 | `app/web/context.py`、`app/storage/repository.py`、`app/web/microsoft/routes.py`、`app/web/capabilities/*` | 03 §6、08 §5、D-20 |
| 手動端到端驗收：`manage.py seed-demo` 建兩個 Environment，實際瀏覽器登入驗證彼此不可見 | 見 README | 08 §5 |
| 手動端到端驗收（全新場景）：平台操作者登入 → 開新 Environment → 開新 Principal → 指派 membership/角色 → 該使用者登入並看到新環境 → 新增 BYO Managed Tenant → 測試連線（對真實 Microsoft OIDC discovery 端點，非 mock）→ Tenant 清單「進入管理」→ 帳號頁同步；pending tenant 正確拒絕進入 | 見本文件 §4 | 使用者需求：「平台管理者可以開設用戶⋯開設用戶環境後，用戶可以輸入相關設定並進入 Tenant 進行相關管理查詢」 |

## 3. 刻意未實作（已知落差，非遺漏）

| 缺口 | 原因 | 恢復路徑 |
|---|---|---|
| Entra SSO **真實 IdP 驗證**（使用者登入 V2+） | 機制（Auth Broker、`/auth/entra/{login,link,callback}`、`ExternalLogin` 綁定）已完成並有 mocked-IdP 測試（見 §2）；缺的是真實 Platform Login App 註冊與端到端登入 evidence——這是「使用者登入 V2+ 這個平台」，與「Worker／連線測試呼叫 Graph」是完全不同的機制，兩者都叫「Entra 整合」容易混淆 | 註冊 Login App（`.env.example` 已載明步驟）→ 設 `V2PLUS_ENTRA_*` → 真實瀏覽器跑 login/link/callback（roadmap D1/D4） |
| Admin Consent 互動導轉流程（04 §4 完整版：導向 Microsoft 頁面同意、callback 帶 tenant id 回來） | 已改走更簡單的 BYO app 自助輸入版（見 §2：使用者自己在 Entra 建 App Registration，直接貼 tenant id／client id／secret），不需要 Provider App bundle 也能端到端測試；Admin Consent 版本需要一個已註冊的多租戶 Provider App 才能測試 | 取得 Provider App 與測試 Tenant 後另外實作；兩種模式未來會並存（04 §2「雙模式」） |
| Microsoft Graph 真實呼叫（對真實 Entra Tenant **成功**驗證） | `HttpGraphClient`／`MsalTokenBroker`／`TenantGraphClientFactory`／BYO app web UI 已是 concrete 實作；**失敗路徑**已用瀏覽器對真實 Microsoft OIDC discovery 端點端到端驗證（見 §2 最後一行），**成功路徑**（真正拿到 token、查到真實 organization）仍未跑過 | 取得測試 Tenant：建立 App Registration、透過 `/microsoft/managed-tenants/new` 網頁表單輸入、按「測試連線」驗證 |
| PostgreSQL RLS 實際執行驗證 | AGENTS.md sandbox 規則：測試預設僅能用 `sqlite:///:memory:`，未經核准不得碰任何 Postgres | `tests/test_rls_postgres.py` 已寫好、opt-in（`V2PLUS_TEST_DATABASE_URL`），人工於拋棄式 DB 執行 |
| Audit signing key／anchor 的**生產基礎設施**（Key Vault key scope、專用 chain writer DB role、immutable Blob） | 簽章與 anchor 的「形狀」與可驗證性（HMAC 派生、chain head 簽章、竄改/rewind 偵測）已完成並有測試；本機 JSON Lines 檔是 dev/self-host 過渡實作，且 master key 與一般 app 程式碼跑在同一權限邊界內，威脅模型效益有限（見 `audit_signing.py` docstring 說明） | 正式部署：master key 搬進 Key Vault、anchor 改寫 immutable Blob、建立無 UPDATE 權限的 chain writer DB role（09 §7） |
| `principal_environment_index`（Catalog projection） | Catalog／Stamp DB 未分離，直接查 `environment_memberships` 更誠實、更少狀態要同步 | Phase 5 Catalog 分離時再建 |
| Host resolver（`<slug>.app.domain`）／Front Door | MVP cut Δ3：session 式環境切換取代 | Phase 5 依 02 §5 加上；host→environment 綁定模型不變 |
| Control Plane（環境生命週期 API、Stamp placement、Bicep） | Gate B（商業訊號確認）後才啟動，11 §2.4 | `app/control_plane/` 為占位 package |
| `/api/v2` JSON API（pydantic DTO、OpenAPI） | 本 spike 僅 SSR；尚無需要獨立 API 的消費端 | ADR-007 §4.3 定義路徑，Phase 2 後半再補 |
| Redis／Service Bus | MVP cut Δ1／Δ2：OAuth state／鎖／queue 皆走 PostgreSQL | 效能實測不足時依 adapter 邊界升級 |
| 應用 DB role（非 owner、無 BYPASSRLS）建立腳本 | 屬 IaC／DBA 範疇，非 migration 職責（09 §7：migration role 與 app role 分離） | 部署前另立 `scripts/postgres_app_role.sql` 或 Bicep/Terraform |

## 4. 實測踩坑記錄（供下一階段避雷）

- **環境變數命名衝突**：本機 shell 已匯出 `DATABASE_URL`（指向現行系統 Postgres）。若本專案沿用同名變數，會在**無任何錯誤提示的情況下**連到現行系統資料庫，因 schema 不同而整批查詢失敗（`UndefinedTable`）。已改用專屬變數 `V2PLUS_DATABASE_URL`。**教訓：獨立新專案的環境變數一律加專屬前綴，不能假設同名變數必然對應自己的 `.env`。**
- **Flask-Migrate 的 `alembic.ini` 必須放在 `migrations/` 目錄內**（`<directory>/alembic.ini`），不是專案根目錄——與純 Alembic 慣例不同；`Migrate._get_config()` 會強制以 `directory` 覆寫 `script_location`。
- **瀏覽器自動化工具的 `preview_click` 對同頁多個 `<form>` 的 `button[type="submit"]` 選擇器可能命中非預期表單**（本頁同時有登出表單與切換表單）；改用 `element.closest('form').requestSubmit()` 較可靠。
- **多個殘留 dev server process 搶同一個 port**：手動啟動的 `python wsgi.py`（尤其搭配 debug reloader 會多開一層子行程）若沒有正常關閉，會在同一 port 疊出好幾個互不相關的 process，之後的請求可能打到狀態不一致的舊 process，出現「密碼明明對卻登入失敗」這類難以復現的假性 bug。**教訓：只用同一種方式啟動 server（本專案固定走 preview 工具或 `manage.py`），懷疑登入異常時先查 `Get-NetTCPConnection` 對應的 PID 是否唯一。**
- **例外類別對不上，導致錯誤分類全部退化成「未知例外」的通用處理**：`AccountsSyncHandler` 原本 catch `app.jobs.worker.RetryableJobError`／`TerminalJobError`，但 `HttpGraphClient` 實際拋的是 `app.microsoft.graph_client.GraphRetryableError`／`GraphTerminalError`（不同類別、無繼承關係），導致所有 Graph 錯誤都落入 `except Exception` 通用分支，變成固定 30 秒重試——429 的真實 `Retry-After` 被蓋掉、401/403 這種永久性錯誤也被當成可重試（浪費 retry 次數且延誤「connection 該降級」的訊號）。**教訓：跨模組的例外轉譯要逐一寫測試斷言「特定例外類別」而非只測「有沒有 raise」，否則 catch 到錯的類別完全不會報錯，測試也會綠燈通過。**（已修正，見 `app/capabilities/accounts/handler.py` 與 `tests/test_accounts_worker.py` 新增案例）
- **`.env.example` 裡的「範例值」如果是活動設定（不是註解），會被複製貼上直接帶進 `.env`，重現同一個 bug**：`.env.example` 原本把 `V2PLUS_DATABASE_URL=sqlite:///instance/v2plus_console.db`（相對路徑）當成活動範例值；建立真的 `.env` 做端到端瀏覽器測試時，`manage.py init-db` 立刻炸「unable to open database file」——因為 `manage.py` 執行時的 cwd 與相對路徑解析結果對不上（即使兩者字面上看起來是同一個目錄）。config.py 原本設計的安全預設值（用 `BASE_DIR` 算出的絕對路徑）因為 `.env` 裡寫了值而完全沒用到。**教訓：`.env.example` 裡任何「有安全預設值可以不用設」的變數，範例值就該用註解掉的方式呈現，不能直接寫成活動值——不然範例本身就是陷阱。**（已修正：改成註解 + 絕對路徑說明）
- **MSAL 建構 `ConfidentialClientApplication` 時會同步呼叫網路做 OIDC discovery，失敗丟的是原生 `ValueError`，不是任何我們自訂的例外類別**：瀏覽器實測「新增 Managed Tenant → 測試連線」，填一個格式正確但不存在的 tenant id，`MsalTokenBroker.acquire_token()` 內部 `self.application_factory(...)` 直接讓 `ValueError` 逃出去，`onboarding_service.test_tenant_connection()` 的 `except TokenAcquisitionError` 完全接不到，變成 Flask debug 500 頁面（`tests/test_token_broker.py` 原本全部用 mocked MSAL app，從未真的建構 `ConfidentialClientApplication`，測試綠燈但實際會炸）。**教訓：跟外部 SDK／函式庫整合時，光靠介面型別（Protocol／mocked callable）測試不夠——SDK 建構子本身可能有副作用（這裡是網路呼叫），需要至少一次不用 mock、蓄意給錯資料的整合測試或手動驗證才抓得到。**（已修正：`MsalTokenBroker` 對 application_factory 呼叫與 `acquire_token_for_client` 都補上 `except ValueError` 轉譯為 `TokenAcquisitionError`；`test_tenant_connection()` 額外加一層 `except Exception` 最後防線，確保使用者觸發的「測試連線」按鈕不管什麼例外都不會 500）
- **只有一個 capability 時寫死的常數，加第二個模組才會現形**：`WorkerRunner._revalidate_scope` 原本寫死檢查 `"accounts.sync" in membership.permission_codes`。單一模組時看不出問題，但加 devices.sync 後，devices job 會被拿 accounts.sync 權限重驗證——若某成員只被授 devices.sync 而無 accounts.sync，其 devices job 會被誤判 `membership_no_longer_authorized` 而 dead-letter。已改為 `envelope["job_type"]`（慣例：sync job 的 job_type 與所需權限 code 同名）。**教訓：spike 只做一個垂直切片時，任何「剛好只有一個值」的地方（權限 code、job_type、路由）都可能藏著寫死假設；加第二個「形狀不同」模組正是為了逼出這類問題——這也是 roadmap 堅持 Phase B 先做 2–3 個模組才批量的理由。**（已修正，見 `app/jobs/worker.py` 與 `tests/test_devices_worker.py`）

## 5. 下一步（依 11-final-architecture.md §2.4 Gate A 清單）

1. D-01／D-02／D-03 三項決策正式定案（本 spike 為求可執行，D-03 暫以「保留 environment-local 帳號」為預設，未經產品核准）。
2. 取得至少 1 個非 production 測試 Entra Tenant + App Registration：
   - 透過 `/microsoft/managed-tenants/new` 網頁表單輸入真實憑證，按「測試連線」驗證**成功路徑**
     （失敗路徑已端到端驗證過，見 §4）；成功後跑一次 `manage.py run-worker --once` 驗證
     `accounts.sync` 真的能寫入真實 Entra 帳號資料。
   - 實作 Entra SSO 使用者登入（Login App、Auth Broker、`/auth/entra/callback`），目前平台
     管理者與一般使用者都只能用本地帳號登入。
   - 若要支援 Provider-owned App bundle 模式（04 §2 的另一種連線方式），需另外註冊多租戶
     Provider App 並實作 04 §4 完整 Admin Consent 導轉流程；BYO app 模式已可用且已端到端驗證。
3. 在拋棄式 Postgres 執行 `tests/test_rls_postgres.py`，取得 RLS 實測 evidence。
4. Audit signing key／anchor 機制與測試已完成（見 §2）；正式部署前把 master key 搬進 Key
   Vault、anchor 改寫 immutable Blob、建立無 UPDATE 權限的 chain writer DB role。
5. Phase 5：Control Plane 獨立服務化（目前是 MVP 內建 web UI + service 層，見 §2）、
   Service Bus adapter、Front Door／host resolver（Worker lifecycle、graceful drain、
   metrics、durable queue 已在 Phase 4 完成）。
