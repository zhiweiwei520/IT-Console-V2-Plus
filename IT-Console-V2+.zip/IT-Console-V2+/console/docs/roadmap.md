# V2+ console 開發路線圖

> ⚠️ **任何新 session（Claude 或 Codex）開始開發前，必須依序讀完**：
> 1. 本檔（規劃與階段定義）
> 2. [`capability-manifest.md`](capability-manifest.md)（目前完成／未完成的權威清單）
> 3. [`SESSION_LOG.md`](SESSION_LOG.md) 最新 3～5 筆記錄（最近做了什麼、卡在哪裡）
>
> 開發到一個段落（無論是完成一個任務、遇到阻塞、或對話即將結束）**必須**依
> `SESSION_LOG.md` 的範本補一筆記錄，不得省略。這是唯一讓下一個 session（不管是
> 誰、用什麼工具）能接手的方式——沒有記錄等於這次工作對後續不存在。

## 現況一句話總結

Phase 0–2 的租戶核心（Environment／RBAC／RLS 設計／TenantContext）與 Phase 4 的
durable job queue／Microsoft Graph client 機制已完成並有測試；平台管理者 Web UI 與
Managed Tenant BYO app 自助連接也已完成並對真實 Microsoft 端點做過端到端驗證（失敗
路徑）。**Phase B 三個驗證模組的程式碼與單元測試皆完成**：`accounts`（全量）、`devices`
（大量分頁＋多空欄位）、`signin_logs`（watermark 增量、append-only）；**真實 Tenant 成功
路徑由使用者確認已在 Claude 接續開發期間進行驗證；各 endpoint evidence 仍以 Session Log 持續補登。詳細清單見 capability-manifest.md。

全階段共同 UI／隔離規則：一個 Environment 可納管多個 Tenant，但登入工作階段一次只允許
一個目前 Tenant；切換必須回 Tenant 選擇頁，任何 capability 不得提供頁內 Tenant 下拉或跨
Tenant 管理。所有現有與後續模組使用 IT Console V2 左側階層式 sidebar。

## 為什麼分這幾個階段

已實測證明：mock 測試會漏掉「跨模組例外類別對不上」「SDK 建構子有副作用（同步網路
呼叫）」這類問題（見 capability-manifest.md §4 踩坑記錄）。因此策略是**先用 2–3 個
「形狀不同」的模組把 Graph 整合模式榨乾驗證過，再批量複製**，而不是全部模組寫完才
做第一次真實驗證——避免系統性問題被複製 N 次才發現。

---

## Phase A — 獨立於模組開發的前置工作（現在就能開始）

跟模組開發順序無關，越早處理越好。

| # | 工作 | 誰做 | 狀態 | 產出／備註 |
|---|---|---|---|---|
| A1 | 提供測試 Entra Tenant + App Registration | **使用者／Claude** | ✅ 使用者確認已驗證 | 驗證於 Claude 接續開發期間進行；細部 evidence 依 Session Log 補登 |
| A2 | D-01／D-02／D-03 決策拍板（或確認沿用預設值） | **使用者** | ⬜ 待確認 | 目前預設：pooled+RLS／provider-owned bundles 起步／保留 environment-local 帳號 |
| A3 | 提供拋棄式 Postgres（或核准建立一個） | **使用者** | ⬜ 待提供 | 解鎖 RLS 實測；AGENTS.md sandbox 規則要求明確核准 |
| A4 | CI/CD skeleton（lockfile 掃描、PR 跑 pytest、基本 pipeline） | Claude/Codex | 🟨 skeleton 完成（dormant） | `.github/workflows/v2plus-console-ci.yml`（repo 根目錄）：PR/push 觸發 pytest（sqlite in-memory、RLS opt-in 維持 skip）＋ pip-audit 鎖版掃描；**repo 尚無 git remote，push 上 GitHub 即生效**，屆時把兩個 job 設 required checks |
| A5 | RLS 在真實 Postgres 上實測 | Claude/Codex | ⬜ 未開始（待 A3） | `tests/test_rls_postgres.py` 已寫好，opt-in |

---

## Phase B — 用 2–3 個形狀不同的模組驗證 Graph 整合模式（關鍵路徑）

目的不是模組本身的完整功能，是榨出系統性問題。**B 沒過，Phase C 批量開發的風險就還在。**

| # | 模組 | 為什麼選它 | 驗證重點 | 狀態 |
|---|---|---|---|---|
| B1 | accounts 成功路徑（已建好） | 零額外開發，直接用 Tenant 驗證現有程式碼 | token 真的拿得到、`/users` 分頁正確 | 🟨 A1 已解除；待補完整 endpoint evidence |
| B2 | devices（Intune） | 不同 permission scope、資料量通常大很多 | 大量分頁、不同權限錯誤情境 | 🟨 程式碼＋單元測試完成；真實 Tenant 成功路徑待 A1（榨出並修正 worker 寫死 accounts.sync 的 bug，見 manifest §4） |
| B3 | signin_logs | 時間區間查詢、高頻資料，不適合全量同步 | 時間篩選、delta/增量策略、資料量控制 | 🟨 程式碼＋單元測試完成（watermark 增量、$filter 時間區間、初始 24h 視窗控量、append-only 不刪、ISO→UTC 解析）；真實 Tenant 成功路徑待 A1 |

**Exit gate**：B1–B3 全部端到端跑過、不再冒出系統性 bug 後，把最終確認的「模組開發
模板」（model／migration／repository／service／handler／route／template／RBAC／測試
checklist）寫進 capability-manifest.md，作為 Phase C 施工標準。

---

## Phase C — 批量開發剩餘模組

依 `../01-current-state-and-scope.md` §2 處置矩陣，扣掉 B 階段已做的 accounts/devices/signin_logs：

| 順序 | 模組 | 備註 | 狀態 |
|---|---|---|---|
| C1 | licenses（M365 授權／MFA 稽核） | 形狀接近 accounts | 🟨 程式、migration、RLS policy、專屬測試完成；整合 evidence 持續補登 |
| C2 | app_audit（App Registration／Enterprise App 稽核） | 形狀接近 accounts | 🟨 程式、migration、RLS policy、專屬測試完成；整合 evidence 持續補登 |
| C3 | software（Intune 偵測到的應用程式） | 跟 devices 配對 | 🟨 程式、v1.0 endpoint、migration/RLS、專屬測試完成；真實 Intune evidence 待補 |
| C4 | teams | V1 是 5 維度資料，較複雜 | 🟨 快速同步程式、0011 migration/RLS、專屬測試完成並全數通過（專屬＋migration 4 passed，全套 195 passed／3 skipped）；真實 Teams/Graph evidence 待補 |
| C5 | sharepoint | 跟 teams 類似複雜度 | 🟨 快速同步程式（v1.0 `/sites?search=*` 列舉＋逐站 `/drives` 補文件庫數與容量）、0012 migration/RLS、專屬測試完成並全數通過（專屬＋migration 4 passed，全套 197 passed／3 skipped）；外部共享／活躍度標 `not_collected`，真實 SharePoint/Graph evidence 待補 |
| C6 | defender（Security alerts） | 需要 `SecurityAlert.Read.All` | 🟨 快速同步程式（v1.0 `/security/alerts_v2` watermark 增量、append-only、初始 30 天視窗）、0013 migration/RLS、專屬測試完成並全數通過（專屬＋migration 4 passed，全套 199 passed／3 skipped）；真實 Defender/Graph evidence 待補 |
| C7 | Sentinel/M365D incidents（Graph）；原列 Azure Monitor／Log Analytics | 使用者拍板走 Graph `/security/incidents`（與 C6 共用 client/token 基礎），真實 Log Analytics 查詢版本另評估 | 🟨 快速同步程式（v1.0 `/security/incidents` watermark 增量、append-only、初始 30 天視窗，需 `SecurityIncident.Read.All`）、0014 migration/RLS、專屬測試完成並全數通過（專屬＋migration 4 passed，全套 201 passed／3 skipped）；真實 Graph evidence 待補 |
| C8 | dashboard（跨模組聚合） | 必須排在 C1–C7 之後 | 🟨 跨模組唯讀 KPI 聚合（十模組 per-Tenant 計數，**後端依權限條件查詢** Issue #5，沿用 `TenantScopedRepository` fail-closed）；專屬測試（含權限 gating）完成並全數通過（dashboard 2 passed，全套 203 passed／3 skipped）；無新表/migration，僅 theme.css append `.v2c-kpi-*` |
| C9 | data_management | **卡在 D-04（HR 資料範圍決策），可能整個排除** | ⬜ 待決策 |

執行方式：不用每個模組都做完整 Tenant 驗證，每 2–3 個模組抽測一次；任何「權限 scope
明顯不同」的模組（例如 C6/C7 用 Security 類權限而非 Directory 類）額外驗證一次。

---

## Phase D — Entra SSO 使用者登入（跟 Phase C 平行，互不依賴）

SSO 機制（Auth Broker／callback／綁定）已完成並有測試；預設關閉（`V2PLUS_ENTRA_SSO_ENABLED`），
未設定 Login App 前所有 SSO route 回 404，本地登入不受影響。

| # | 工作 | 狀態 |
|---|---|---|
| D1 | 註冊 Platform Login App（delegated：`openid profile email User.Read`，固定 callback） | ⬜ 待 A1（維運動作；`.env.example` 已載明步驟與 `V2PLUS_ENTRA_*` 變數） |
| D2 | Auth Broker：授權碼流程、state/nonce、ID token 驗證（audience／issuer／簽章） | 🟨 程式／測試完成——委由 MSAL `initiate/acquire_token_by_auth_code_flow`（內建 state/nonce/PKCE/id_token 驗證，不自刻 JWT）；authority 白名單＋建構子 ValueError 轉譯（manifest §4 坑）；專屬 16 passed，全套 219 passed／3 skipped |
| D3 | `/auth/entra/callback` route + `ExternalLogin` 綁定（`(canonical_issuer, subject)`，禁 email/UPN fallback） | 🟨 程式／測試完成——未綁定登入 fail-closed 不自動開帳號；`/auth/entra/link` 供已登入者綁定，已綁他人一律拒絕；缺 iss/sub 即拒、明確測試斷言不退回 email/UPN |
| D4 | 端到端用測試 Tenant 驗證登入 | ⬜ 待 D1（真實 IdP evidence，與 C1–C8 同標準） |

可在 Phase B 之後、跟 Phase C 同時進行。

---

## Phase E — 收尾與 Gate A 正式達標

| # | 工作 | 狀態 |
|---|---|---|
| E1 | Audit anchor 從本機檔案接 Key Vault、chain writer DB role 分離 | ⬜ |
| E2 | Provider App bundle 模式（加分項，非必要項） | ⬜ |
| E3 | capability-manifest.md／README 全面更新，對照 `../10-requirement-traceability.md` R-01～R-12 逐項打勾 | ⬜ |
| E4 | 依 `../11-final-architecture.md` §2.4 正式宣告 Gate B 觸發點（Phase 0–4 完整達標） | ⬜ |

Gate B 之後（Control Plane／計費／Phase 5–6）是商業決策，不在本路線圖範圍內。

---

## 狀態圖示說明

`⬜ 未開始` `🟨 進行中` `✅ 完成` `🚫 阻塞（見備註）`
