# Session Log（開發歷程記錄，append-only）

> **規則（強制）**：
> - 新的一筆永遠加在「## 記錄範本」下方、最新記錄的**上面**（新到舊排序，最新的在最上面）。
> - 不得刪除或改寫舊記錄；發現舊記錄有錯，用新記錄註記更正，不要回頭改。
> - 每次開發到一個段落（完成任務／遇到阻塞／對話即將結束）都要補一筆，不管執行者是
>   Claude、Codex 還是人工手動改的。沒有記錄 = 這次工作對下一個 session 不存在。
> - 開始任何開發前，先看這份文件最新 3～5 筆，搞清楚上一個 session 停在哪、卡在哪。

## 記錄範本

```markdown
## YYYY-MM-DD — <一句話標題>（執行者：Claude／Codex／人工）

**做了什麼**：
- ...

**修改／新增檔案**：
- ...

**發現或修正的 bug**（若無則寫「無」）：
- ...

**測試結果**：`pytest` X passed, Y skipped（或說明為何沒跑）

**對應 roadmap.md 階段**：Phase X — 狀態變化

**下一步／交接事項**：
- ...
```

---

## 2026-07-12 — B2 時區顯示債清償 ＋ dev DB 升級 0014 ＋ C1–C8 瀏覽器實測（執行者：Claude）

**做了什麼**：
- **清償 B3 交接掛號的顯示層時區債**（root CLAUDE.md B2 鐵則）：`app/storage/time_utils.py` 新增
  `to_taipei_str`（naive UTC datetime 或 Graph ISO 字串 → UTC+8 格式化；None／空 → "—"；無法解析
  的字串**原樣回傳不 raise**——顯示 filter 不得讓整頁 500；Taipei 固定 +8 無 DST 故用固定位移，
  不為顯示引入 tzdata 依賴）；`create_app` 註冊 Jinja filter `datetime_local`。
- 模板套用：signin_logs（含秒）／defender／sentinel（datetime 欄位）／sharepoint（ISO 字串欄位），
  標頭一律改「(UTC+8)」，副標移除「時間為 UTC」。teams 清單無時間欄不涉及。
- **dev instance DB 升級**：備份 `instance/v2plus_console.db.bak-0007` 後 `manage.py init-db`
  （alembic 0007→0014＋權限同步到 22 個，既有 demo 環境的 admin/viewer 角色自動獲得新模組權限）。
- **瀏覽器端到端實測（preview server, port 8100）**：demo-a 登入 → 切環境 → Tenant 選擇 →
  sidebar 十模組＋總覽儀表板全數呈現 → dashboard 十張 KPI 卡（ZhiLAB 真實 tenant 帳號=7，其餘 0，
  深色主題截圖 OK）→ signin_logs 插入已知 UTC 02:03:04 展示列，頁面顯示 **10:03:04（UTC+8）** ✓
  → defender 頁渲染＋(UTC+8) 標頭 ✓。登入頁 SSO 按鈕在未啟用時正確隱藏 ✓。

**修改／新增檔案**：`app/storage/time_utils.py`、`app/__init__.py`、
`app/templates/capabilities/{signin_logs,defender,sentinel,sharepoint}/list.html`、
`tests/test_time_display.py`、capability-manifest／本 Session Log；dev DB 升級至 0014
（含備份 .bak-0007）、Demo Tenant A 插入展示列 `tz-demo-1`。

**發現或修正的 bug**：
- **殘留 dev server 疊 port 8100 造成 500**（manifest §4 既有坑再次命中）：昨日 19:53 手動啟動的
  `V2+/console/wsgi.py`（PID 17868）仍存活——它啟動於 stash 還原**之前**、記憶體舊 ORM 對上已升
  0014 的 DB，瀏覽器流量打到它而非 preview server（證據：我們的 server log 完全沒有 request 行）。
  清除該 process 後一切正常。**教訓再確認：懷疑 500／行為不一致，先查 port 的 PID 是否唯一。**
- 驗證過程誤觸排入一個 Demo Tenant A 的 signin sync job；demo tenant 無 TenantConnection，
  依既有行為自動 dead-letter，無害（SESSION_LOG 既有記載的行為）。

**測試結果**：時區專屬＋受影響四模組 `20 passed`；全套 `225 passed, 3 skipped`（219＋6 個
時區測試，3 skipped 為既有 opt-in）。瀏覽器實測如上（UTC+8 轉換、dashboard、sidebar gating、
新模組頁）。`FLASK_ENV=testing` + `sqlite:///:memory:`。

**對應 roadmap.md 階段**：不屬 A–E 單一項；為 B2 規範債清償＋C1–C8 的 UI 驗證 evidence
（程式層面 evidence，真實 Graph 資料 evidence 仍待 A1 各 endpoint 補登）。

**下一步／交接事項**：
- dev DB 已在 0014，`python wsgi.py`（或 preview 工具）即可瀏覽全部模組；demo-a／demo-b 密碼
  `DemoPass!12345`。**啟動前先確認 8100 無殘留 process**。
- 剩餘 roadmap 項目全數卡決策／外部資源：A2、A3/A5、C9（D-04）、Phase E、D1/D4 真實 IdP。

---

## 2026-07-12 — Phase D Entra SSO 使用者登入 ＋ A4 CI/CD skeleton（執行者：Claude）

**做了什麼**：
- **Phase D（使用者拍板選定）**：新增 `app/microsoft/sso.py` `EntraAuthBroker`——授權碼流程
  **委由 MSAL** `initiate_auth_code_flow`／`acquire_token_by_auth_code_flow`（內建 state／nonce／
  PKCE／id_token 驗證 audience/issuer/簽章/exp，**刻意不自刻 JWT 驗證**）；authority 僅允許
  `https://login.microsoftonline.com/`；MSAL 建構子 OIDC discovery 丟原生 ValueError 的既知坑
  （manifest §4）已轉譯 `SsoError`。
- 身分繫結鐵則：canonical key 固定 `(iss, sub)`，缺一即拒，**禁 email/UPN/preferred_username
  fallback**（測試明確斷言）。三個 route：`/auth/entra/login`（**未綁定 fail-closed**，不自動開
  帳號）、`/auth/entra/link`（已登入者綁定；同一 `(iss,sub)` 已綁他人一律拒絕，防帳號接管）、
  `/auth/entra/callback`（session flow 一次性用畢即丟）。SSO 未設定時全部 404，不洩漏原因。
- 設定：`V2PLUS_ENTRA_SSO_ENABLED`（預設關閉）＋`V2PLUS_ENTRA_LOGIN_{CLIENT_ID,TENANT,
  CREDENTIAL_REF,REDIRECT_URI}`；secret 走既有 CredentialProvider（env: scheme）。
  `ExternalLogin` model 0001 起就緒 → **無新 migration**。登入頁在啟用時顯示 SSO 按鈕。
  測試注入 `app.config["ENTRA_AUTH_BROKER"]` 假 broker，零真實網路。
- **A4 CI/CD skeleton**：新增 repo 根目錄 `.github/workflows/v2plus-console-ci.yml`——
  `test` job（pytest，sqlite in-memory，RLS opt-in 維持 skip）＋`audit` job（pip-audit 掃
  全鎖版 requirements）；paths 過濾只涵蓋 `V2+/console/**`；YAML 語法已本機驗證。
  **repo 尚無 git remote → dormant skeleton**，push 上 GitHub 即生效，屆時設 required checks。

**修改／新增檔案**：`app/microsoft/sso.py`、`app/web/auth/routes.py`、`app/__init__.py`
（sso flag context processor）、`app/templates/auth/login.html`、`config.py`、`.env.example`、
`tests/test_entra_sso.py`、`.github/workflows/v2plus-console-ci.yml`（repo 根目錄）、
roadmap／capability-manifest／README／本 Session Log。

**發現或修正的 bug**：無（新程式）。設計上把 manifest §4 兩個既知坑（MSAL 建構子副作用、
例外類別要具體斷言）直接內建進實作與測試。

**測試結果**：Phase D 專屬 `16 passed`；全套 `219 passed, 3 skipped`（3 skipped 為既有 opt-in）。
CI workflow 無法本機執行（無 remote），僅驗證 YAML 語法——**不視為 pipeline 已驗證**。

**對應 roadmap.md 階段**：Phase D2/D3 程式／測試完成（D1 註冊 Login App、D4 真實 IdP 端到端
待 A1）；Phase A4 skeleton 完成（dormant）。

**下一步／交接事項**：
- 真實 SSO 端到端（D1/D4）：依 `.env.example` 註冊 Login App → 設 `V2PLUS_ENTRA_*` → 瀏覽器
  實測 login/link/callback；單一租戶建議 `V2PLUS_ENTRA_LOGIN_TENANT=<tenant id>`（issuer 才固定）。
- roadmap 剩餘：A2（D-01/02/03 決策）、A3/A5（拋棄式 Postgres → RLS 實測）、C9（卡 D-04）、
  Phase E（E1 Key Vault、E3 traceability 對照、E4 Gate A 宣告——多數卡真實 evidence）。
- CI 生效條件：建立 GitHub remote 並 push（含 V2+ 目前未追蹤的檔案需先 commit——依規範由
  使用者決定何時 commit）。

---

## 2026-07-11 — Phase C8 跨模組總覽儀表板（執行者：Claude）

**做了什麼**：
- roadmap C8 dashboard（跨模組聚合），前置 C1–C7 已全部到位故解除。唯讀頁面，聚合十個
  capability（accounts／devices／signin_logs／licenses／app_audit／software／teams／sharepoint／
  defender／sentinel）的 per-Tenant 計數卡。
- **安全鐵則落實（root CLAUDE.md Issue #5）**：KPI 由**後端 route 依權限條件查詢**——
  `DashboardService.kpis()` 逐一檢查 `context.has_permission("<ns>.view")`，無權限的模組
  **根本不查、不進 context**，template 不可能洩漏數字（不是只靠 `{% if %}` 藏）。
- 計數借用 `_ScopedCount(TenantScopedRepository)`：動態注入 model、沿用 environment + 單一
  目前 Tenant 的 fail-closed scoping（缺 active tenant 直接拒絕）。無自己的 model/sync/migration；
  theme.css 依 B1 append module 前綴 `.v2c-kpi-*`（auto-fit grid，色值全走 `var(--*)`，未寫死色碼）。
- nav 置於「查詢功能」群組頂端（繼承群組 OR-of-all-view gating）；route required_permission=None
  但各 KPI 個別 gate。

**修改／新增檔案**：`app/capabilities/dashboard/`、`app/web/capabilities/dashboard/`、
`app/templates/capabilities/dashboard/index.html`、`app/__init__.py`、`app/templates/base.html`、
`app/static/css/theme.css`（append `.v2c-kpi-*`）、`tests/test_dashboard.py`、
roadmap／capability-manifest／README／本 Session Log。

**發現或修正的 bug**：無。

**測試結果**：dashboard 專屬 `2 passed`（含「只回傳有權限的 KPI」後端 gating 斷言與 web 唯讀
render／未選 Tenant redirect）；全套 `203 passed, 3 skipped`。`FLASK_ENV=testing` + `sqlite:///:memory:`。

**驗證方式**：功能面以 web test client 端到端 render 驗證（登入→切環境→切 Tenant→GET /dashboard
→ 200＋KPI 內容＋未選 Tenant redirect）。**未做瀏覽器截圖**：dev instance DB 目前停在 migration
0007（落後 C1–C7 全部資料表），要截圖須先把 dev DB 升到 0014＋seed-demo，屬未經請求的 dev DB
變更，故不擅自進行；新增 CSS 為 15 行標準 grid/card、走既有 theme token，風險低。需真實截圖時
再升 dev DB 補做。

**對應 roadmap.md 階段**：Phase C8 程式／測試完成。**Phase C 至此 C1–C8 全部到位**，僅剩
C9 data_management 卡 D-04 決策（可能整個排除）。

**下一步／交接事項**：
- **Phase C 實質收官**（C9 待使用者對 D-04 HR 資料範圍決策，或確認排除）。建議下一步轉向
  roadmap **Phase D（Entra SSO 使用者登入）** 或 **Phase E（收尾／Gate A：真實 Tenant evidence 補登、
  Key Vault、RLS 實測、requirement-traceability R-01～R-12 逐項打勾）**，兩者與 Phase C 平行、互不依賴。
- 所有 C1–C8 模組的**真實 Graph evidence 仍統一待補**（需測試 Entra Tenant）；這是 Phase E3/E4
  Gate A 正式達標的主要缺口，非程式缺口。
- dev instance DB 升級：`FLASK_ENV=development` 下 `flask db upgrade`（或 `manage.py init-db`）到 0014
  後 `manage.py seed-demo`，即可用瀏覽器實際操作 C1–C8 各頁。

---

## 2026-07-11 — Phase C7 資安事件（Sentinel/M365D incidents，Graph）增量同步（執行者：Claude）

**做了什麼**：
- roadmap C7 原列「Azure Monitor／Log Analytics」。開工前確認 `MsalTokenBroker.acquire_token`
  與 `HttpGraphClient` 皆**硬限制 `graph.microsoft.com`**，真實 Log Analytics（`api.loganalytics.io`）
  需擴充 token broker resource allowlist（安全邊界）＋新查詢 client＋每 Tenant workspace 設定，
  屬架構級新增且無真實 workspace 可驗。**經使用者拍板**改走 Graph v1.0 `/security/incidents`
  （Sentinel/M365D 統一 incidents，需 `SecurityIncident.Read.All`），與 C6 alerts_v2 共用既有
  client/token 基礎、零安全邊界變更（roadmap 亦提示「與 C6 共用查詢基礎」）。
- 程式為 C6 defender 的孿生：**watermark 增量**（`$filter=createdDateTime ge`＋`$orderby`＋
  `$top=200`）、初始 30 天視窗、**append-only**（incidents 狀態可變故重抓時 upsert 更新，不
  finalize 刪除）。durable handler/checkpoint（window_start resume 不重算）、401/403 降級、
  Retry-After 尊重、Tenant-scoped repository、RBAC、單一 Tenant route/sidebar、0014 migration
  + PostgreSQL FORCE RLS（含 watermark 複合索引）。新增 worker（含 $filter 斷言）與 web 防竄改測試。

**修改／新增檔案**：`app/capabilities/sentinel/`、`app/web/capabilities/sentinel/`、
`app/templates/capabilities/sentinel/list.html`、`app/jobs/{dispatcher,bootstrap}.py`、
`app/platform/permissions.py`、`app/__init__.py`、`app/templates/base.html`、
`migrations/versions/0014_sentinel_capability.py`、`tests/test_sentinel_capability.py`、
roadmap／capability-manifest／README／本 Session Log。

**發現或修正的 bug**：無（新程式）。關鍵決策：不動 token broker 安全邊界，以 Graph incidents
達成 SOC incidents 聚合。

**測試結果**：C7 專屬＋migration `4 passed`；全套 `201 passed, 3 skipped`。`FLASK_ENV=testing`
+ `sqlite:///:memory:`。

**對應 roadmap.md 階段**：Phase C7 程式／測試完成（真實 Graph evidence 待補，維持 🟨）；
原「真實 Log Analytics 查詢」版本標記為後續另評估項（需擴充 resource allowlist 與 workspace 設定）。

**下一步／交接事項**：
- Phase C1–C7 capability 皆已到位，**下一項為 C8 dashboard（跨模組聚合）**，roadmap 要求排在
  C1–C7 之後、現已解除前置。dashboard 為唯讀跨模組 KPI 聚合，務必**後端 route 依權限條件查詢**
  （root CLAUDE.md Issue #5：只在 `has_permission` 時才算該 KPI，否則 HTML source 洩漏數字），
  沿用單一目前 Tenant scope 與 `TenantScopedRepository` fail-closed。
- C9 data_management 仍卡 D-04（HR 資料範圍決策），可能整個排除，待使用者決策。
- 真實 Log Analytics 查詢版本若要做：需 `api.loganalytics.io` resource + 新 query client +
  ManagedTenant 加 workspace_id + KQL；屬架構級工作，建議有真實 workspace 再啟動。

---

## 2026-07-11 — Phase C6 Defender 告警增量同步（執行者：Claude）

**做了什麼**：
- 接續 roadmap Phase C6 defender。形狀選定最接近 signin_logs（高頻時序）而非 software（全量
  finalize）：v1.0 `/security/alerts_v2`（**GraphClient 禁 beta**，alerts_v2 為 v1.0 GA）、
  **watermark 增量**（`$filter=createdDateTime ge <window_start>`＋`$orderby`＋`$top=200`）、
  首次同步初始 30 天視窗控量、**append-only 不刪除**（告警是歷史事件；狀態可變故重抓時
  upsert 更新，刻意不做 finalize 刪除）。
- 這是第一個用 **Security 類權限 `SecurityAlert.Read.All`** 而非 Directory/Sites 類的模組。
  durable handler/checkpoint（window_start resume 不重算）/heartbeat、401/403 降級連線、
  Retry-After 尊重、Tenant-scoped repository、RBAC、單一 Tenant route/sidebar、0013 migration
  + PostgreSQL FORCE RLS（含 `(managed_tenant_id, created_datetime)` watermark 複合索引）。
- 新增 worker 測試（含「首次同步初始視窗 watermark 帶進 `$filter`」斷言）與 web 防竄改測試。

**修改／新增檔案**：`app/capabilities/defender/`、`app/web/capabilities/defender/`、
`app/templates/capabilities/defender/list.html`、`app/jobs/{dispatcher,bootstrap}.py`、
`app/platform/permissions.py`、`app/__init__.py`、`app/templates/base.html`、
`migrations/versions/0013_defender_capability.py`、`tests/test_defender_capability.py`、
roadmap／capability-manifest／README／本 Session Log。

**發現或修正的 bug**：無（新程式）。確認 token broker 與 GraphClient 皆硬限制
`graph.microsoft.com`，故 defender 沿用既有 Graph 基礎、無須動安全邊界。

**測試結果**：C6 專屬＋migration `4 passed`；全套 `199 passed, 3 skipped`（3 skipped 為既有
opt-in PostgreSQL RLS／外部整合測試）。`FLASK_ENV=testing` + `sqlite:///:memory:`。

**對應 roadmap.md 階段**：Phase C6 程式／測試完成（真實 Defender evidence 待補，維持 🟨）。

**下一步／交接事項**：
- 使用者已拍板 C7 走 **Sentinel incidents（Graph `/security/incidents`，需 `SecurityIncident.Read.All`）**，
  與 C6 alerts_v2 同一 client/token 基礎、零安全邊界變更（不走真實 Log Analytics 查詢，
  避免動 token broker resource allowlist 與新增 workspace 設定）。
- defender 真實 evidence：取得測試 Tenant 後驗 `SecurityAlert.Read.All` consent 與
  `/security/alerts_v2` 的 `$filter`／`$orderby`／`$select` 成功路徑；watermark 只涵蓋
  `createdDateTime >= 上界`，舊告警的後續狀態變更不會回補（與 signin_logs 同樣的增量取捨，
  完整狀態對帳屬後續 governance 範疇）。

---

## 2026-07-11 — 解除 C4 測試阻塞並標記完成 ＋ Phase C5 SharePoint 快速同步（執行者：Claude）

**做了什麼**：
- **接手 Codex C4 交接**：先發現整包 V2+ 未提交工作（含全部 `.py` 原始碼）被切分支時的
  `git stash -u` 收進 `stash@{0}`（"pre-switch from v2plus-foundation"），工作樹只剩被 gitignore
  的 `.pyc`；用 `git stash apply` 非破壞性還原，確認 143 個 `.py` 全回來（無資料遺失）。
- **執行 Codex 因額度未跑的 C4 測試**：`tests/test_teams_capability.py tests/test_migration_sqlite.py`
  4 passed；全套 195 passed／3 skipped。逐檔審 teams 程式，確認已吸收前階段所有 §4 踩坑
  （例外類別對齊 GraphRetryableError/GraphTerminalError、401/403 降級連線、finalize 用
  `IS NULL OR !=`、活躍度標 `not_collected`）、三層 gating（權限／sidebar 群組 OR／route＋
  dispatcher 窄權限）齊備 → 標記 C4 程式／測試完成（維持 🟨，真實 Graph evidence 與 C1–C3
  同樣待補）。
- **接續 Phase C5 SharePoint**：比照 teams 結構新增 sharepoint capability。列舉走 v1.0
  `/sites?search=*`（GraphClient 禁 beta，`getAllSites` 是 beta 故不可用），逐站 `/sites/{id}/drives`
  補文件庫數與容量（取首個具 quota 的 drive 的 used/total，缺則 None 不偽造）；外部共享與
  活躍度明確標 `not_collected`。durable handler/checkpoint/heartbeat/resume、finalize
  `IS NULL OR !=`、Tenant-scoped repository、RBAC、單一 Tenant route/sidebar、0012 migration
  + PostgreSQL FORCE RLS；新增 worker 與 web 防竄改測試。

**修改／新增檔案**：`app/capabilities/sharepoint/`、`app/web/capabilities/sharepoint/`、
`app/templates/capabilities/sharepoint/list.html`、`app/jobs/{dispatcher,bootstrap}.py`、
`app/platform/permissions.py`、`app/__init__.py`、`app/templates/base.html`、
`migrations/versions/0012_sharepoint_capability.py`、`tests/test_sharepoint_capability.py`、
roadmap／capability-manifest／README／本 Session Log。

**發現或修正的 bug**：無（新程式）。過程中的關鍵發現是 V2+ 原始碼被 stash 收走、只剩 `.pyc`
的假性「資料遺失」——實際在 `stash@{0}`，已還原。

**測試結果**：C4 專屬＋migration `4 passed`；C5 專屬＋migration `4 passed`；全套 `197 passed,
3 skipped`（3 skipped 為既有 opt-in PostgreSQL RLS／外部整合測試）。使用 `FLASK_ENV=testing`
+ `sqlite:///:memory:`。

**對應 roadmap.md 階段**：Phase C4 🟨→程式／測試完成；Phase C5 程式／測試完成（真實 evidence 待補）。

**下一步／交接事項**：
- 下一施工項目為 Phase C6 defender（Security alerts，需 `SecurityAlert.Read.All`）——這是第一個
  用 Security 類權限而非 Directory/Sites 類的模組，依 roadmap 應在此額外做一次真實 Tenant 驗證。
- SharePoint 真實 evidence：取得測試 Tenant 後驗 `Sites.Read.All` consent 與 `/sites?search=*`＋
  `/sites/{id}/drives` 成功路徑；drive `quota` 的 used/total 語意（站台集合層級 vs 文件庫層級）
  需以真實回應核對，必要時調整 `_storage()` 聚合方式。
- 已還原的 stash `stash@{0}` 尚未 drop（保留為備份）；確認工作樹無誤後可由使用者決定是否
  `git stash drop`。目前 V2+ 全部檔案仍為未追蹤／未提交狀態（root CLAUDE.md 規範不主動 commit）。

---

## 2026-07-11 — Phase C4 Teams 快速同步建立、測試受工具額度阻塞（執行者：Codex）

**做了什麼**：
- 依交接流程讀取三份文件後開始 C4；對照 V1 五維度，建立 groups/team、channels、members、owners、installedApps 快速同步。
- 基礎屬性、頻道、成員、安全合規保存 Tenant-scoped 快取；活躍度未掃訊息時顯式保存 `status=not_collected`，不偽造統計。
- 完成 durable handler/dispatcher/checkpoint、RBAC、單一 Tenant route/sidebar、0011 migration 與 PostgreSQL FORCE RLS；新增 worker、防竄改與 migration 測試檔。

**修改／新增檔案**：`app/capabilities/teams/`、`app/web/capabilities/teams/`、`app/templates/capabilities/teams/list.html`、`app/jobs/{dispatcher,bootstrap}.py`、`app/platform/permissions.py`、`app/__init__.py`、`app/web/microsoft/routes.py`、`app/templates/base.html`、`migrations/versions/0011_teams_capability.py`、`tests/test_teams_capability.py`、roadmap／manifest／Session Log。

**發現或修正的 bug**：無法確認；測試尚未執行。設計上刻意避免把未掃描的訊息活躍度顯示為 0。

**測試結果**：未執行。測試命令在啟動前被 Codex 使用額度限制拒絕（非 pytest failure），依指示未嘗試繞過。

**對應 roadmap.md 階段**：Phase C4 🟨 待測試，不得宣告完成。

**下一步／交接事項**：額度恢復後先執行 `tests/test_teams_capability.py tests/test_migration_sqlite.py -q`，修正後再跑全套；全綠後才更新 README 與標記程式／測試完成。完整模式的 messages／tabs／drive 留待真實 Tenant evidence。

---

## 2026-07-11 — A1 狀態確認 + Phase C3 Intune 軟體清冊（執行者：Codex）

**做了什麼**：
- 使用者確認 A1 已在 Claude 接續開發期間進行基本驗證；roadmap 更新為已解除前置阻塞，但未捏造本輪未重跑的 endpoint evidence。
- 官方文件確認 detectedApps 已有 Graph v1.0，維持 V2+ 禁止 beta 的安全邊界。
- 完成 `/deviceManagement/detectedApps` 分頁全量同步、checkpoint、Tenant-scoped repository/service、RBAC、單一 Tenant route/sidebar、0010 migration 與 PostgreSQL FORCE RLS。
- 新增 worker、未選 Tenant、偽造 foreign tenant form、migration/model 漂移測試。

**修改／新增檔案**：`app/capabilities/software/`、`app/web/capabilities/software/`、`app/templates/capabilities/software/list.html`、`app/jobs/{dispatcher,bootstrap}.py`、`app/platform/permissions.py`、`app/__init__.py`、`app/web/microsoft/routes.py`、`app/templates/base.html`、`migrations/versions/0010_software_capability.py`、`tests/test_software_capability.py`、README 與三份交接文件。

**發現或修正的 bug**：現行 V1 使用 beta detectedApps，但 Microsoft 已提供 v1.0；C3 改走 v1.0，無需繞過 GraphClient beta allowlist。

**測試結果**：專屬＋migration `4 passed`；全套 `193 passed, 3 skipped`。使用 `FLASK_ENV=testing` + `sqlite:///:memory:`。

**對應 roadmap.md 階段**：A1 ✅（使用者確認）；Phase C3 程式／測試完成，整合 evidence 待補。

**下一步／交接事項**：接續 Phase C4 Teams；A1 各真實 endpoint 結果由實際執行者在新 Session Log 補 evidence。

---

## 2026-07-11 — Phase C2 應用程式稽核程式與測試完成（執行者：Codex）

**做了什麼**：
- 依交接流程讀取 roadmap、capability manifest 與最新 Session Log 後接續 C2。
- 新增 `/applications`、`/servicePrincipals` 雙階段 durable sync 與 checkpoint；App Registration 保存 sign-in audience、publisher domain、憑證數與最近到期日，Enterprise App 保存啟用、類型與 owner organization。
- 完成 Tenant-scoped repository/service、RBAC、單一 Tenant route、sidebar、0009 migration 與 PostgreSQL FORCE RLS policy。
- 新增雙階段 worker、未選 Tenant、偽造 foreign tenant form、migration/model 漂移測試。

**修改／新增檔案**：
- `app/capabilities/app_audit/`、`app/web/capabilities/app_audit/`、`app/templates/capabilities/app_audit/list.html`
- `app/jobs/{dispatcher,bootstrap}.py`、`app/platform/permissions.py`、`app/__init__.py`、`app/web/microsoft/routes.py`、`app/templates/base.html`
- `migrations/versions/0009_app_audit_capability.py`、`tests/test_app_audit_capability.py`
- `README.md`、`docs/{roadmap,capability-manifest,SESSION_LOG}.md`

**發現或修正的 bug**：
- C2 新權限若未加入 Tenant 選擇與 sidebar 父層 OR gating，app_audit-only 使用者會看不到入口；已同步補齊。

**測試結果**：專屬＋migration `4 passed`；全套 `191 passed, 3 skipped`。3 skipped 為既有 opt-in 測試；使用 `FLASK_ENV=testing` + `sqlite:///:memory:`。

**對應 roadmap.md 階段**：Phase C2 程式／測試完成；真實 Microsoft 成功路徑待 A1，維持 🟨。

**下一步／交接事項**：
- 真實 Tenant 到位後驗證 `Application.Read.All`／`Directory.Read.All` consent，並依實測加入 owners、appRoleAssignments、oauth2PermissionGrants 下鑽。
- 下一個施工項目為 Phase C3 software（Intune detected apps），繼續沿用單一目前 Tenant 與 sidebar 規範。

---

## 2026-07-11 — Phase C1 授權／MFA 稽核程式與測試完成（執行者：Codex）

**做了什麼**：
- 依交接機制重讀 roadmap → capability manifest → Session Log 後，接續上一筆 C1 骨架。
- 完成 `/subscribedSkus` 與 `/reports/authenticationMethods/userRegistrationDetails` 雙階段 durable sync、checkpoint、full-sync finalize、單一 Tenant route／repository、RBAC 與 sidebar。
- 0008 migration 補上三張表的 PostgreSQL `ENABLE/FORCE RLS` 與單一 Tenant `USING/WITH CHECK` policy。
- 新增 worker、Web 未選 Tenant、偽造 foreign tenant form、migration/model 漂移測試。

**修改／新增檔案**：
- `app/capabilities/licenses/{handler,service}.py`、`app/jobs/dispatcher.py`
- `app/web/capabilities/licenses/routes.py`、`app/web/microsoft/routes.py`、`app/templates/base.html`
- `migrations/versions/0008_license_mfa_capability.py`、`tests/test_licenses_capability.py`
- `README.md`、`docs/{roadmap,capability-manifest,SESSION_LOG}.md`

**發現或修正的 bug**：
- `finalize()` 原用 `last_seen_sync_id != sync_id`，SQL 不會命中 NULL，舊資料可能殘留；改為 `IS NULL OR !=`。
- licenses handler 遇 Graph 401/403 未降級 TenantConnection；已比照 accounts/devices 修正。
- `@odata.nextLink` 未驗證型別；已補 terminal guard。dispatcher 對 grant 越界改回 PermissionError。

**測試結果**：專屬＋migration `5 passed`；全套 `189 passed, 3 skipped`。3 skipped 為既有 opt-in PostgreSQL／外部整合測試；使用 `FLASK_ENV=testing` + `sqlite:///:memory:`。

**對應 roadmap.md 階段**：Phase C1 程式／測試完成；真實 Microsoft 成功路徑仍待 A1，因此維持 🟨。

**下一步／交接事項**：
- 取得測試 Tenant 後驗證 `Organization.Read.All`、`User.Read.All`、`UserAuthenticationMethod.Read.All` 實際 consent 與兩個 Graph endpoint 成功路徑。
- 可接續 Phase C2 app_audit；仍須遵守單一目前 Tenant 與左側 sidebar 規則。

---

## 2026-07-11 — Phase C1 授權／MFA 稽核骨架（執行者：Codex）

**做了什麼**：新增 Tenant-scoped 授權 SKU、MFA 註冊資料與 checkpoint；接上 `/subscribedSkus`、`userRegistrationDetails` 雙階段 durable handler、dispatcher、權限、route、sidebar 與 0008 migration。

**修改／新增檔案**：`app/capabilities/licenses/`、`app/web/capabilities/licenses/`、`app/jobs/`、`app/platform/permissions.py`、`app/templates/base.html`、`migrations/versions/0008_*`、roadmap／manifest。

**發現或修正的 bug**：補上 licenses-only 權限使用者的 Tenant 選擇入口 gating。

**測試結果**：migration／基本回歸 `14 passed`。

**對應 roadmap.md 階段**：Phase C1 🟨 進行中。

**下一步／交接事項**：補 licenses 專屬 service/worker/隔離測試、PostgreSQL RLS policy 與真實 Tenant 驗證後才能標完成；目前不可宣告 C1 完成。

---

## 2026-07-11 — 單一目前 Tenant 隔離 + IT Console V2 左側選單（執行者：Codex）

**做了什麼**：
- 將目前 Managed Tenant 從各功能頁的 query/form 下拉選擇，改為 server-side session 唯一
  `active_managed_tenant_id`；Tenant 清單以「進入管理」切換，Environment 切換、登出、membership
  version 失效或 Tenant 狀態失效時一律清除。
- accounts／devices／signin_logs 的清單與同步 route 強制要求單一目前 Tenant；同步忽略偽造的
  `managed_tenant_id` 表單值。`TenantScopedRepository` 缺少目前 Tenant 時直接 fail-closed，禁止一般
  管理畫面跨 Tenant 聚合。
- Tenant 清單依 membership grants 過濾；viewer 可選擇被授權 Tenant，但看不到新增／測試連線操作。
- 頂部平鋪導覽改為 IT Console V2 同型左側階層式 sidebar（查詢功能 → M365），含權限 gating、
  active 項目、目前 Environment／Tenant 顯示與行動版開合。
- 更新架構、開發規範、測試策略、README、roadmap、capability manifest 與 CHANGELOG；明定後續所有
  capability 沿用單一 Tenant session 與 sidebar，不得自行新增頁內 Tenant 下拉。

**修改／新增檔案**：
- `app/web/context.py`、`app/storage/repository.py`、`app/web/{auth,environments,microsoft}/routes.py`
- `app/web/capabilities/{accounts,devices,signin_logs}/routes.py`
- `app/templates/base.html`、`app/templates/microsoft/managed_tenants/list.html`、三個 capability 清單模板
- `app/static/css/theme.css`、`app/static/js/theme.js`
- `tests/test_{auth_flow,repository_isolation,managed_tenant_routes,accounts_capability,devices_capability,signin_logs_capability}.py`
- `README.md`、`docs/{roadmap,capability-manifest,SESSION_LOG}.md`、上層 V2+ 架構／規範／測試文件與根 `CHANGELOG.md`

**發現或修正的 bug**：
- 舊功能頁允許 `?managed_tenant_id=`／POST 欄位決定 scope，且空值會查同 Environment 全部 Tenant；
  已改為 session 單一 scope，並補偽造參數與同 Environment 雙 Tenant 反向測試。
- 舊 Managed Tenant 清單未套 membership tenant grants；已補過濾，避免 subset grant 使用者看到未授權 Tenant。

**測試結果**：`pytest` 186 passed, 3 skipped；其中 Tenant／選單針對性回歸 41 passed。
3 skipped 為既有 opt-in 測試，未新增 skip；全程 `FLASK_ENV=testing` + `sqlite:///:memory:`。

**對應 roadmap.md 階段**：跨 Phase UI／Tenant isolation 基線完成；B1–B3 真實 Tenant 成功路徑仍待 A1。

**下一步／交接事項**：
- Phase C 任何新模組 route 使用 `require_tenant_context(..., require_active_tenant=True)`；template 不再提供 Tenant 下拉。
- 合法跨 Tenant 報表需獨立 service／route，顯式驗證完整 grants，不得放寬一般 capability repository。

---

## 2026-07-11 — 內嵌背景 worker（web-only 同步 UX）+ dev server 對外綁定（執行者：Claude）

**做了什麼**：
- 使用者回饋：網頁按「立即同步」後只 enqueue，還要另開 `manage.py run-worker` CLI，體驗不佳，
  希望所有操作都在 web 上。新增**內嵌背景 worker**（`app/jobs/embedded.py`）：`wsgi.py` 啟動時
  在 daemon thread 跑 `WorkerProcess.run_forever()`，網頁排入的 job 自動被處理，不必另開 CLI。
- 刻意**只由 `wsgi.py`（web 入口）啟動，不放進 `create_app()`**——否則 `manage.py`
  （init-db／run-worker／seed-demo）與 pytest 都會被連帶啟動一個背景 worker（run-worker 變雙
  worker、測試背景執行緒亂寫 in-memory DB）。守門：TESTING／`V2PLUS_EMBEDDED_WORKER=false`／
  未設 factory 一律不啟動；debug reloader 只在服務子 process 啟動（`WERKZEUG_RUN_MAIN`）避免雙 worker。
- 定位：單機自架用內嵌 worker（預設開）；水平擴充改 `V2PLUS_EMBEDDED_WORKER=false` + 獨立
  `run-worker`。durable queue 的 lease／idempotency／SKIP LOCKED 對兩種模式皆成立，內嵌不降可靠性。
- 三個 sync route flash 改為「背景 worker 會自動處理，稍候重新整理即可看到結果」。
- 另：`wsgi.py` 的 host/port/debug 改為 env 可控（`V2PLUS_HOST`/`V2PLUS_PORT`/`V2PLUS_DEBUG`），
  解決「其他裝置連不到 VM」——原本綁死 127.0.0.1。`.env` 已加 `V2PLUS_HOST=0.0.0.0`+`V2PLUS_DEBUG=false`
  （防火牆需使用者自行開 TCP 8100）。

**修改／新增檔案**：
- 新增 `app/jobs/embedded.py`、`tests/test_embedded_worker.py`
- 修改 `wsgi.py`、`app/web/capabilities/{accounts,devices,signin_logs}/routes.py`（flash）、
  `.env.example`、`.env`、`README.md`

**發現或修正的 bug**：無。（實測附帶觀察：租戶無 `TenantConnection` 時，factory 失敗落入
run_once 的通用 except → abandon delay=0 → 幾秒內燒完 5 次 attempt 直接 dead_letter；這是既有
行為、且會自限不會 spin，非本次改動引入。真實租戶有 active connection 時不會發生。）

**測試結果**：`pytest` 183 passed, 3 skipped（新增 3 個 embedded guard 測試）。另做**執行緒實測**：
enqueue 一個 accounts.sync 後啟動內嵌 worker，job 於 ~2s 內從 queued 被自動撿走處理（demo 租戶
無憑證故 dead_letter，但證明 web-only 自動處理可行），驗證 job 已清理。`py_compile` 全過。

**對應 roadmap.md 階段**：不直接對應 A–E；屬部署／UX 基礎設施（讓 Phase B 端到端驗證可全程在 web 完成）。

**下一步／交接事項**：
- 使用者現在 `python wsgi.py` 即可：登入 demo-a → Managed Tenant 新增真實 Tenant → 測試連線 →
  帳號/裝置/登入記錄頁按同步 → **內嵌 worker 自動處理**，重新整理看結果。不用再開 run-worker。
- 內嵌 worker 目前只在 `wsgi.py` 的 `__main__`/import 路徑啟動；未來若改用 waitress 部署，
  waitress import `wsgi:app` 時 module-level 的 `start_embedded_worker` 仍會啟動（非 debug → 直接起）。
- SQLite 下 web 與 worker 併發寫可能偶發 lock；正式改 Postgres 無此問題（設計本就目標 Postgres）。

---

## 2026-07-11 — signin_logs（Entra 登入記錄）垂直切片：Phase B3（執行者：Claude）

**做了什麼**：
- 依 roadmap Phase B3 建立 `signin_logs` capability，這是三個驗證模組裡「形狀差異最大」的一個：
  Graph `/auditLogs/signIns`（需 `AuditLog.Read.All`），改用 **watermark 增量**而非全量同步。
- 增量策略：checkpoint 建立時算一次 watermark（`MAX(created_datetime)` per tenant）並釘進
  `window_start`；首頁 `$filter=createdDateTime ge <window_start>` + `$orderby` + `$top=200`。
  首次同步無資料時退回「最近 24h」初始視窗控制資料量。resume 時沿用 `window_start` 不重算
  （否則 watermark 會隨已 commit 資料前移、跳過邊界）。用 `ge` + (tenant,id) 冪等 upsert，
  邊界同秒事件重抓也不漏不重。
- **append-only**：handler 完成後不做 finalize/刪除，service 也刻意沒有 `finalize_full_sync`、
  model 沒有 `last_seen_sync_id`——這正是要驗證「模組模板」不能對 full-sync 過度擬合。
- createdDateTime（ISO 8601，可能帶 Z 與 7 位小數）→ naive UTC 存 DB（CLAUDE.md B2）；
  `parse_graph_datetime` 統一截小數到 6 位、轉 UTC，並有單元測試。
- 三層 gating（permissions／nav／route＋dispatcher 窄權限）、seed-demo 示範資料齊備。

**修改／新增檔案**：
- 新增 `app/capabilities/signin_logs/{__init__,models,repository,service,handler}.py`、
  `app/web/capabilities/signin_logs/{__init__,routes}.py`、
  `app/templates/capabilities/signin_logs/list.html`、
  `migrations/versions/0007_signin_logs_capability.py`、
  `tests/test_signin_logs_{capability,worker}.py`
- 修改 `app/platform/permissions.py`、`app/jobs/{dispatcher,bootstrap}.py`、`app/__init__.py`、
  `app/templates/base.html`、`manage.py`

**發現或修正的 bug**：無（worker `_revalidate_scope` 已於 B2 泛化為 `envelope["job_type"]`，
signin_logs.sync 直接受益，未再踩雷）。

**測試結果**：`pytest` 180 passed, 3 skipped（新增 19 個 signin_logs 測試，含 watermark 增量、
初始視窗、append-only 不刪、ISO 解析、checkpoint resume 保留 window_start、清單頁 render）；
`py_compile` 全過；migration↔model 漂移測試涵蓋新表。

**對應 roadmap.md 階段**：Phase B3 程式碼完成（單元測試層）。**B1–B3 三個「形狀不同」的模組
（accounts 全量／devices 大量分頁＋多空欄位／signin_logs 增量 append-only）程式碼與測試皆已到位。**

**下一步／交接事項**：
- **Phase B exit gate 尚未達成**：gate 要求「B1–B3 端到端跑過、不再冒系統性 bug」，而端到端仍卡
  A1（真實 Entra Tenant，含 Intune 與 AuditLog 授權）。取得 Tenant 後依序 `run-worker --once`
  驗證三個模組成功路徑，再把「模組開發模板」寫進 capability-manifest，才進 Phase C 批量。
- **共用 base 抽取的時機到了但刻意還沒做**：三個 dispatcher／handler 目前平行複製，差異已收斂到
  （job_type、permission、Graph 資源、$select、是否 finalize、是否增量）。抽 base 前建議先過
  A1 端到端，確認沒有第四類系統性差異，避免抽錯（這也是 exit gate 把抽模板排在端到端之後的原因）。
- 顯示層時間：signin_logs 清單頁目前直接顯示 naive UTC 並標「(UTC)」——console spike 尚無
  UTC+8 顯示 helper（accounts/devices 存字串未涉及）。正式化時應補 `datetime_local` 等值 filter
  再改標「(UTC+8)」（CLAUDE.md B2）。

---

## 2026-07-11 — devices（Intune 受管裝置）垂直切片：Phase B2（執行者：Claude）

**做了什麼**：
- 依 roadmap Phase B2 建立 `devices` capability，沿用 accounts 垂直切片結構
  （models/repository/service/handler + web routes/template + migration + 測試）。
- Graph 資源 `/deviceManagement/managedDevices`（需 `DeviceManagementManagedDevices.Read.All`），
  刻意選一個「形狀不同」的模組：多數欄位（OS／UPN／序號／合規狀態）可為空，upsert 只把
  `id` 當必要欄位；`deviceName` 缺值退回 source id 以免破 NOT NULL——這正是 B 階段要榨出的
  差異（accounts 是「每欄位皆必填」）。
- 泛化 `WorkerRunner._revalidate_scope`：原本寫死 `"accounts.sync"`，改用 `envelope["job_type"]`
  （慣例：sync job 的 job_type 與所需權限 code 同名）。否則 devices.sync job 會拿 accounts.sync
  權限重驗證——這是新增第二個模組才會現形的既有 bug。
- 三層 gating 落實：permissions（devices.view/devices.sync + environment_admin/viewer 授權）→
  base.html nav → route `require_tenant_context` + dispatcher 窄權限。
- `seed-demo` 一併寫入示範裝置（含缺值裝置）供瀏覽器手動驗收。

**修改／新增檔案**：
- 新增 `app/capabilities/devices/{__init__,models,repository,service,handler}.py`、
  `app/web/capabilities/devices/{__init__,routes}.py`、
  `app/templates/capabilities/devices/list.html`、
  `migrations/versions/0006_devices_capability.py`、
  `tests/test_devices_{capability,worker}.py`
- 修改 `app/platform/permissions.py`、`app/jobs/{dispatcher,bootstrap,worker}.py`、
  `app/__init__.py`、`app/templates/base.html`、`manage.py`

**發現或修正的 bug**：
- `WorkerRunner._revalidate_scope` 寫死 `"accounts.sync"`：多 capability worker 下，
  devices.sync job 會被 accounts.sync 權限重驗證。已改為 `envelope["job_type"]`。

**測試結果**：`pytest` 160 passed, 3 skipped（新增 14 個 devices 測試，含清單頁完整 render
smoke test）；`py_compile` 全過。migration↔model 漂移測試涵蓋新表。

**對應 roadmap.md 階段**：Phase B2 程式碼完成（單元測試層）；**真實 Tenant 端到端驗證仍卡在
A1**（成功路徑需真實 Entra Tenant + Intune 授權，尚未取得）。

**下一步／交接事項**：
- Phase B3（signin_logs，時間區間查詢／delta）是最後一個「形狀不同」的驗證模組；B1–B3 全部
  端到端跑過後才依 exit gate 抽「模組開發模板」，再進 Phase C 批量。
- dispatcher／handler 目前是 accounts↔devices 平行複製（僅字串差異），**刻意暫不抽 base**——
  依 roadmap Phase B exit gate，待 signin_logs 這個差異最大的模組進來後一起抽，避免抽錯抽象。
- devices 的「成功路徑」與 accounts 同樣待 A1 測試 Tenant；屆時一起用 `run-worker --once` 驗證。

---

## 2026-07-11 — 建立 roadmap.md 與 SESSION_LOG.md 開發流程文件（執行者：Claude）

**做了什麼**：
- 依使用者要求，把先前討論定案的 Phase A–E 規劃寫成 `docs/roadmap.md`。
- 建立本檔案（`SESSION_LOG.md`）作為強制、append-only 的開發歷程記錄。
- 在 `V2+/console/CLAUDE.md` 新增規則，要求任何新 session 開工前先讀 roadmap.md +
  capability-manifest.md + 本檔最新記錄；結束前必須補一筆記錄。
- 更新 `README.md` 置頂連結指向這兩份文件。

**修改／新增檔案**：
- 新增 `docs/roadmap.md`、`docs/SESSION_LOG.md`、`CLAUDE.md`
- 修改 `README.md`

**發現或修正的 bug**：無（純文件工作）

**測試結果**：未跑（無程式碼異動）

**對應 roadmap.md 階段**：跨階段的流程基礎設施，不屬於 A–E 任一項

**下一步／交接事項**：
- 等待使用者回覆 Phase A1（測試 Entra Tenant）／A2（決策拍板）／A3（拋棄式 Postgres）。
- 在使用者回覆前，可以先做 A4（CI/CD skeleton）——不依賴外部資源，見 roadmap.md。

---

## 2026-07-11 — 平台管理者 Web UI + Managed Tenant BYO app 自助連接（執行者：Claude）

**做了什麼**：
- 新增 `app/control_plane/service.py`：把 CLI 的 create_principal/create_environment/
  add_membership 邏輯抽成共用函式，CLI 與 web 路由共用同一份邏輯。
- 新增平台管理者 Web UI（`/platform/`）：開設 Principal、Environment、指派 Membership／
  角色；`require_platform_operator` 守門，不隱含任何 Environment 資料存取。
- 新增 BYO app client secret 加密存 DB（Fernet，`V2PLUS_ENCRYPTION_KEY`）+
  `DatabaseEncryptedCredentialProvider` / `CompositeCredentialProvider`（env: / db: 兩種
  scheme），migration 0005。
- 新增 Managed Tenant 自助連接 Web UI（`/microsoft/managed-tenants/`）：BYO app 表單、
  測試連線（呼叫真實 Graph `/organization`，比對回傳 tenant id 防混淆攻擊）。
- 帳號頁加 Managed Tenant 下拉選擇器 + 「立即同步」按鈕。
- **用瀏覽器做了一次完整端到端測試**：平台操作者登入 → 開新環境 → 開新使用者 → 指派
  membership → 該使用者登入 → 連接 BYO Managed Tenant → 測試連線 → 帳號頁。

**修改／新增檔案**：
- 新增 `app/control_plane/service.py`、`app/web/platform/`、`app/web/microsoft/`、
  `app/microsoft/onboarding_service.py`、`app/microsoft/encryption.py`、
  `migrations/versions/0005_tenant_connection_encrypted_secret.py`
- 新增 9 個測試檔（`test_control_plane_service.py`、`test_platform_admin.py`、
  `test_managed_tenant_routes.py`、`test_onboarding_service.py`、`test_encryption.py` 等）
- 修改 `app/capabilities/accounts/routes.py`、`app/templates/capabilities/accounts/list.html`、
  `app/static/css/theme.css`、`app/__init__.py`、`app/templates/base.html`

**發現或修正的 bug**：
1. **MSAL 建構 `ConfidentialClientApplication` 時同步呼叫網路做 OIDC discovery**，失敗丟
   原生 `ValueError`（不是 `TokenAcquisitionError`），導致「測試連線」在真實測試中變成
   500——純 mock 測試完全測不出來，只有真的打一次網路才現形。已修正：`MsalTokenBroker`
   補 `except ValueError` 轉譯；`test_tenant_connection()` 額外加 `except Exception` 最後
   防線。
2. `.env.example` 把 `V2PLUS_DATABASE_URL` 相對路徑當活動範例值，複製到 `.env` 後
   `manage.py init-db` 直接炸「unable to open database file」——重現了先前記錄過的同一類
   問題。已修正為註解 + 說明留空即用安全的絕對路徑預設值。

**測試結果**：`pytest` 147 passed, 3 skipped；`py_compile` 全過；瀏覽器端到端驗證全部
步驟成功（含對真實 Microsoft OIDC 端點的失敗路徑驗證）。

**對應 roadmap.md 階段**：不直接對應 A–E（這是 Gate A 完成前的必要基礎設施：沒有平台
管理 UI 就無法自助開環境，沒有 Managed Tenant 連接 UI 就無法測試任何 Phase B 模組）。

**下一步／交接事項**：
- Managed Tenant「測試連線」目前只驗證過失敗路徑；成功路徑需要真實 Entra Tenant（roadmap Phase B）。
- accounts capability 是唯一做出來的模組；Phase B/C 待啟動。

---

## 2026-07-11 — Audit chain 簽章金鑰與 anchor 機制（執行者：Claude）

**做了什麼**：
- 新增每 Environment 獨立 signing key（HMAC-SHA256 從單一 `V2PLUS_AUDIT_MASTER_KEY` 派生）。
- 新增本機檔案 anchor writer/verifier（`instance/audit_anchors/<slug>.jsonl`），可偵測
  「內部自洽但整條被重算」的竄改與 rewind（純 hash chain 自洽性測不出這種攻擊）。
- 新增 CLI：`write-audit-anchor`、`verify-audit-chain --anchor`。

**修改／新增檔案**：
- 新增 `app/platform/audit_signing.py`、`app/platform/audit_anchor.py`、`tests/test_audit_anchor.py`
- 修改 `app/platform/audit.py`（新增 `verify_chain_against_anchor`）、`manage.py`

**發現或修正的 bug**：無

**測試結果**：`pytest` 92 passed, 3 skipped

**對應 roadmap.md 階段**：Phase E1（尚未完成——本次只做本機檔案版，Key Vault／immutable
Blob／chain writer role 分離仍是缺口）

**下一步／交接事項**：正式部署前需把 master key 搬進 Key Vault。

---

## 2026-07-11 — Graph 例外轉譯 bug 修正 + GraphClient／TokenBroker 測試補齊（執行者：Claude）

**做了什麼**：
- 修正 `AccountsSyncHandler` 錯誤 catch 了 `app.jobs.worker.RetryableJobError`/
  `TerminalJobError`，但 `HttpGraphClient` 實際拋的是 `app.microsoft.graph_client.
  GraphRetryableError`/`GraphTerminalError`（不同類別），導致所有 Graph 錯誤退化成固定
  30 秒重試——429 的真實 `Retry-After` 被蓋掉、401/403 被當可重試。
- 401/403（`graph_authorization_failed`）現在會立即 dead-letter 並把 TenantConnection
  降級為 `degraded`。
- 補齊 `HttpGraphClient`／`MsalTokenBroker`／`EnvironmentCredentialProvider`／
  `TenantGraphClientFactory` 的單元測試（httpx MockTransport、mocked MSAL app，零真實網路）——
  這幾個模組先前零測試覆蓋。
- 新增 `default_graph_client_factory`（`app/microsoft/factory.py`），讓
  `V2PLUS_GRAPH_CLIENT_FACTORY` 有開箱即用的預設值，不用自己寫 glue code。

**修改／新增檔案**：
- 修改 `app/capabilities/accounts/handler.py`、`app/microsoft/factory.py`
- 新增 `tests/test_graph_client.py`、`tests/test_token_broker.py`、`tests/test_credentials.py`、
  `tests/test_graph_client_factory.py`；`tests/test_accounts_worker.py` 加 3 個案例

**發現或修正的 bug**：見上方「做了什麼」第一點（例外類別對不上）。

**測試結果**：`pytest` 81 passed, 3 skipped

**對應 roadmap.md 階段**：Phase B 的前提工作（Graph client 機制要先打好底才能驗證真實模組）

**下一步／交接事項**：機制完成，等待 Phase B 的真實 Tenant 驗證。

---

## 2026-07-11 — 除錯：登入失敗問題（多個殘留 dev server process）（執行者：Claude）

**做了什麼**：
- 使用者回報 demo-a/demo-b 登入失敗。排查發現 port 8100 上疊了多個非透過工具啟動的
  殘留 `wsgi.py` process（其中牽涉 Flask debug reloader 多開子行程），推測使用者打到
  狀態不一致的舊 process。
- 取得使用者授權後清除殘留 process，補跑 Codex 新增的 migration（0002–0004），重新驗證
  登入與隔離皆正常。

**修改／新增檔案**：無程式碼異動

**發現或修正的 bug**：**多個殘留 dev server process 搶同一個 port** 會導致「密碼明明對
卻登入失敗」這類難以復現的假性 bug。教訓：只用同一種方式啟動 server（固定走 preview
工具或 `manage.py`），懷疑登入異常時先查 `Get-NetTCPConnection` 對應的 PID 是否唯一。

**測試結果**：手動瀏覽器驗證 demo-a／demo-b 登入與隔離正常

**對應 roadmap.md 階段**：N/A（維運排錯，非開發）

**下一步／交接事項**：無（已解決）

---

## 2026-07-11 — Codex 貢獻：Phase 4 durable jobs + audit hash chain + Graph client 機制（執行者：Codex）

> 本筆為回溯記錄（Claude 於後續 session 讀程式碼後補記，非 Codex 本人撰寫）。

**做了什麼**（依程式碼與 git 狀態推斷）：
- 新增 audit hash chain（`environment_audit_logs.chain_sequence`／`previous_hash`／
  `entry_hash`，`environment_audit_chain_heads`），migration 0002。
- 新增 `PgJobQueue`（`app/jobs/queue.py`／`models.py`）：冪等 enqueue、`SELECT ... FOR
  UPDATE SKIP LOCKED` claim、lease／heartbeat、delayed retry、DLQ，migration 0003。
- 新增 `AccountsSyncDispatcher`／`AccountsSyncHandler`／`WorkerRunner`／`WorkerProcess`：
  accounts.sync job 的完整 dispatch/worker 生命週期，含 scope 重驗證、Graph 分頁
  checkpoint、crash resume，migration 0004。
- 新增 `HttpGraphClient`（endpoint allowlist、429/5xx/401 分類、Retry-After 解析、分頁）、
  `MsalTokenBroker`（token cache key、cloud/resource allowlist）、
  `EnvironmentCredentialProvider`（`env:V2PLUS_*` allowlist）、`TenantGraphClientFactory`。
- 新增 `manage.py run-worker` 指令。

**修改／新增檔案**：`app/jobs/*`、`app/capabilities/accounts/handler.py`、
`app/microsoft/{graph_client,token_broker,credentials,factory}.py`、
`migrations/versions/000{2,3,4}_*`、對應測試檔

**發現或修正的 bug**：無記錄（回溯記錄，細節不明）

**測試結果**：Claude 接手時執行 `pytest` 39 passed, 3 skipped

**對應 roadmap.md 階段**：Phase 4（durable execution）主體，及 Phase B 的 Graph client 前提

**下一步／交接事項**：交接給 Claude 繼續（見上方「Graph 例外轉譯 bug 修正」記錄，發現
並修正了這批程式碼中的一個例外分類 bug）。

---

## 2026-07-10 — V2-P0 + V2-P2 spike：租戶核心骨架建立（執行者：Claude）

**做了什麼**：
- 依 `V2+/01`–`V2+/11` 開發文件，建立全新獨立專案 `V2+/console/`（不 import 現行系統
  `app/`，不共用 DB／port），分支 `v2plus-foundation`。
- 建立租戶核心 schema（Principal／ManagementEnvironment／EnvironmentMembership／
  EnvironmentRole／ManagedTenant／MembershipTenantGrant 等）。
- 建立框架無關 `TenantContext` + scoped repository（`ScopedRepository`／
  `TenantScopedRepository`）+ PostgreSQL RLS policy（migration 0001，environment-only ＋
  tenant-grant subquery 兩種樣式）。
- 建立本地登入（platform break-glass + environment-local）+ session 式環境切換 +
  membership version 重新驗證。
- 建立 `accounts` capability 垂直切片（stub 資料，未接 Graph）示範完整模式。
- 建立 `manage.py` CLI（init-db／create-principal／create-environment／add-membership／
  seed-demo）。
- Anti-Slop 前端反模板（`.v2c-*`、單一 theme.css、dark/light）。

**修改／新增檔案**：整個 `V2+/console/` 專案骨架（約 50 個檔案）；`.claude/launch.json`
新增 `v2plus-console`（port 8100）server 設定（原有 `it-console` port 8000 未動）。

**發現或修正的 bug**：
- 環境變數命名衝突：本機 shell 已匯出 `DATABASE_URL` 指向現行系統 Postgres，沿用同名
  變數會無提示接錯資料庫。改用專屬變數 `V2PLUS_DATABASE_URL`。
- Flask-Migrate 的 `alembic.ini` 必須放在 `migrations/` 目錄內，不是專案根目錄。

**測試結果**：`pytest` 19 passed, 3 skipped；瀏覽器手動驗證 `seed-demo` 建立的 demo-a／
demo-b 兩個環境彼此隔離。

**對應 roadmap.md 階段**：Phase 0–2（Baseline、Tenancy foundation）主體

**下一步／交接事項**：Phase 3（Microsoft connection）機制尚未開始（後續由 Codex 接手，
見上一筆記錄）。
