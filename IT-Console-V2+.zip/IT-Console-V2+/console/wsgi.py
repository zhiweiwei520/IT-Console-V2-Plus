"""V2+ console 開發入口。生產部署另見 README（未定案，見 capability-manifest 部署章節）。"""
import os

from app import create_app
from app.jobs.embedded import start_embedded_worker

app = create_app()

# 綁 127.0.0.1（只收本機）；要讓其他裝置連進來時設 V2PLUS_HOST=0.0.0.0。
# ⚠️ 綁 0.0.0.0 會把 dev server 暴露到網路；此時建議一併設 V2PLUS_DEBUG=false，
#    避免 Werkzeug 互動式 debugger 對外開放（也順便關掉 reloader 的雙 process）。
_HOST = os.environ.get("V2PLUS_HOST", "127.0.0.1")
_PORT = int(os.environ.get("V2PLUS_PORT", "8100"))
_DEBUG = os.environ.get("V2PLUS_DEBUG", str(app.config.get("DEBUG", False))).lower() in (
    "1", "true", "yes", "on",
)

# 內嵌背景 worker：讓網頁「立即同步」後自動執行，不必另開 CLI（見 app/jobs/embedded.py）。
# 只在真正服務的 process 啟動——debug reloader 開啟時，父監督 process 沒有 WERKZEUG_RUN_MAIN，
# 只有實際服務的子 process 有，藉此避免雙 worker。非 reloader（waitress 或 debug=false）則直接啟動。
if not _DEBUG or os.environ.get("WERKZEUG_RUN_MAIN") == "true":
    start_embedded_worker(app)

if __name__ == "__main__":
    app.run(host=_HOST, port=_PORT, debug=_DEBUG)
