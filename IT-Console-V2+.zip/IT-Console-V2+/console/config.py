"""
config.py
══════════════════════════════════════════════════════════════
V2+ console 組態。獨立於 repo 根目錄 config.py，不共用任何設定或資料庫。

環境由 FLASK_ENV 控制：development / testing / production。
"""
from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass


class BaseConfig:
    SECRET_KEY = os.environ.get("SECRET_KEY") or ""
    SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "false").lower() == "true"
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 8  # 8 hr，比照現行系統閒置逾時基線

    # 刻意用 V2PLUS_DATABASE_URL 而非 DATABASE_URL：本機 shell／原專案 .env 常已匯出
    # DATABASE_URL 指向現行系統的 Postgres，若沿用同一變數名稱，這個獨立新專案會在
    # 未察覺的情況下連到現行系統資料庫並因 schema 不同而整批查詢失敗（已實測命中此坑）。
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "V2PLUS_DATABASE_URL",
        f"sqlite:///{BASE_DIR / 'instance' / 'v2plus_console.db'}",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_recycle": 3600,
    }
    if SQLALCHEMY_DATABASE_URI.startswith(("postgresql://", "postgresql+")):
        SQLALCHEMY_ENGINE_OPTIONS.update({
            "pool_size": int(os.environ.get("V2PLUS_DB_POOL_SIZE", "5")),
            "max_overflow": int(os.environ.get("V2PLUS_DB_MAX_OVERFLOW", "10")),
            "connect_args": {"connect_timeout": int(os.environ.get("V2PLUS_DB_CONNECT_TIMEOUT", "10"))},
        })

    BASE_DIR = BASE_DIR
    INSTANCE_DIR = BASE_DIR / "instance"

    WTF_CSRF_TIME_LIMIT = 60 * 60 * 4

    # 03-tenancy-identity-data.md §9：environment suspend／membership revoke 暫定 p95 ≤ 60 秒失效目標。
    # MVP 以「每次敏感操作重新比對 membership.version」逼近，非背景輪詢。
    MEMBERSHIP_REVALIDATION_ENFORCED = True

    DEFAULT_PLATFORM_USERNAME = os.environ.get("DEFAULT_PLATFORM_USERNAME", "platform-admin")

    # Entra SSO 使用者登入（Phase D）。預設關閉；啟用需維運人員先註冊 Platform Login App
    # （delegated：openid profile email User.Read，固定 redirect callback）並設定下列變數。
    # 身分繫結固定 (canonical_issuer, subject)，禁 email/UPN fallback（見 app/microsoft/sso.py）。
    ENTRA_SSO_ENABLED = os.environ.get("V2PLUS_ENTRA_SSO_ENABLED", "false").lower() == "true"
    ENTRA_LOGIN_CLIENT_ID = os.environ.get("V2PLUS_ENTRA_LOGIN_CLIENT_ID", "")
    # 單一租戶請設具體 tenant id（issuer 才確定）；"organizations" 允許任何工作/學校帳號。
    ENTRA_LOGIN_TENANT = os.environ.get("V2PLUS_ENTRA_LOGIN_TENANT", "organizations")
    ENTRA_LOGIN_CREDENTIAL_REF = os.environ.get(
        "V2PLUS_ENTRA_LOGIN_CREDENTIAL_REF", "env:V2PLUS_ENTRA_LOGIN_CLIENT_SECRET",
    )
    # 留空則由 url_for('auth.entra_callback', _external=True) 動態產生（須與 App 註冊的 redirect 一致）。
    ENTRA_LOGIN_REDIRECT_URI = os.environ.get("V2PLUS_ENTRA_LOGIN_REDIRECT_URI", "")


class DevelopmentConfig(BaseConfig):
    DEBUG = True
    TEMPLATES_AUTO_RELOAD = True


class TestingConfig(BaseConfig):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_recycle": 3600,
    }
    WTF_CSRF_ENABLED = False


class ProductionConfig(BaseConfig):
    DEBUG = False
    SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "true").lower() == "true"


CONFIG_MAP = {
    "development": DevelopmentConfig,
    "testing": TestingConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig,
}


def get_config():
    env = os.environ.get("FLASK_ENV", "development").lower()
    return CONFIG_MAP.get(env, DevelopmentConfig)
