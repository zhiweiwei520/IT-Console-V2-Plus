"""Fernet 加解密 helper：BYO app client secret 存 DB 前的加密層。"""
from __future__ import annotations

import pytest
from cryptography.fernet import Fernet

from app.microsoft.encryption import EncryptionKeyUnavailable, decrypt_secret, encrypt_secret


@pytest.fixture(autouse=True)
def _encryption_key(monkeypatch):
    monkeypatch.setenv("V2PLUS_ENCRYPTION_KEY", Fernet.generate_key().decode("utf-8"))


def test_encrypt_decrypt_roundtrip():
    ciphertext = encrypt_secret("my-client-secret")
    assert ciphertext != "my-client-secret"
    assert decrypt_secret(ciphertext) == "my-client-secret"


def test_missing_key_fails_loud(monkeypatch):
    monkeypatch.delenv("V2PLUS_ENCRYPTION_KEY", raising=False)
    with pytest.raises(EncryptionKeyUnavailable):
        encrypt_secret("x")


def test_invalid_key_format_fails_loud(monkeypatch):
    monkeypatch.setenv("V2PLUS_ENCRYPTION_KEY", "not-a-valid-fernet-key")
    with pytest.raises(EncryptionKeyUnavailable):
        encrypt_secret("x")


def test_decrypt_with_wrong_key_fails_loud(monkeypatch):
    ciphertext = encrypt_secret("my-client-secret")
    monkeypatch.setenv("V2PLUS_ENCRYPTION_KEY", Fernet.generate_key().decode("utf-8"))
    with pytest.raises(EncryptionKeyUnavailable):
        decrypt_secret(ciphertext)


def test_decrypt_tampered_ciphertext_fails_loud():
    ciphertext = encrypt_secret("my-client-secret")
    tampered = ciphertext[:-4] + ("0000" if ciphertext[-4:] != "0000" else "1111")
    with pytest.raises(EncryptionKeyUnavailable):
        decrypt_secret(tampered)
