"""devices capability：權限缺口與 service 層防線、web route 三層 gating。

結構比照 test_accounts_capability.py。"""
from __future__ import annotations

import pytest

from app.capabilities.devices.service import DeviceService
from app.extensions import db as _db
from app.storage.tenant_context import TenantContext


def test_service_raises_without_devices_view_permission(two_environments):
    env_a, _env_b = two_environments
    ctx = TenantContext(
        principal_id=env_a.principal.id,
        environment_id=env_a.environment.id,
        membership_id=env_a.membership.id,
        allowed_managed_tenant_ids=None,
        active_managed_tenant_id=None,
        permission_codes=frozenset(),  # 沒有 devices.view
        correlation_id="no-perm",
    )
    service = DeviceService(_db.session, ctx)
    with pytest.raises(PermissionError):
        service.list_devices()


def test_web_route_returns_403_when_role_lacks_devices_view(client, two_environments, app):
    env_a, _env_b = two_environments
    from app.platform.models import EnvironmentRole, RoleAssignment
    from app.storage.time_utils import utc_now_naive

    with app.app_context():
        bare_role = EnvironmentRole(environment_id=env_a.environment.id, code="bare", label="Bare", is_builtin=False)
        _db.session.add(bare_role)
        _db.session.flush()
        RoleAssignment.query.filter_by(membership_id=env_a.membership.id).delete()
        _db.session.add(RoleAssignment(
            environment_id=env_a.environment.id, membership_id=env_a.membership.id,
            role_id=bare_role.id, granted_at=utc_now_naive(),
        ))
        _db.session.commit()

    client.post("/auth/login", data={
        "environment_slug": "", "username": "user-a", "password": "TestPass!12345",
    })
    client.post(f"/environments/{env_a.environment.id}/switch")

    resp = client.get("/capabilities/devices/")
    assert resp.status_code == 403


def _login_and_switch(client, env_a):
    client.post("/auth/login", data={
        "environment_slug": "", "username": "user-a", "password": "TestPass!12345",
    })
    client.post(f"/environments/{env_a.environment.id}/switch")
    client.post(f"/microsoft/managed-tenants/{env_a.tenant.id}/switch")


def test_list_page_renders_seeded_devices(client, two_environments, app):
    """GET 清單頁的完整 render path（template + url_for）；驗證缺值欄位以「—」呈現不炸。"""
    from app.capabilities.devices.service import seed_demo_devices

    env_a, _env_b = two_environments
    with app.app_context():
        seed_demo_devices(_db.session, environment_id=env_a.environment.id, managed_tenant_id=env_a.tenant.id)
        _db.session.commit()

    _login_and_switch(client, env_a)
    resp = client.get("/capabilities/devices/")
    body = resp.get_data(as_text=True)
    assert resp.status_code == 200
    assert "DEMO-PC-01" in body
    assert "裝置清單" in body


def test_sync_route_enqueues_job_for_authorized_tenant(client, two_environments, app):
    from app.jobs.models import DurableJob

    env_a, _env_b = two_environments
    _login_and_switch(client, env_a)

    resp = client.post("/capabilities/devices/sync", data={
        "managed_tenant_id": str(env_a.tenant.id),
    }, follow_redirects=False)
    assert resp.status_code == 302

    with app.app_context():
        assert DurableJob.query.filter_by(
            environment_id=env_a.environment.id, managed_tenant_id=env_a.tenant.id, job_type="devices.sync",
        ).count() == 1


def test_sync_route_ignores_forged_foreign_tenant_form_value(client, two_environments, app):
    env_a, env_b = two_environments
    _login_and_switch(client, env_a)

    resp = client.post("/capabilities/devices/sync", data={
        "managed_tenant_id": str(env_b.tenant.id),
    }, follow_redirects=True)
    assert resp.status_code == 200  # 停留在裝置頁並顯示錯誤，不是 500

    with app.app_context():
        from app.jobs.models import DurableJob
        assert DurableJob.query.filter_by(managed_tenant_id=env_b.tenant.id).count() == 0
        assert DurableJob.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 1


def test_sync_route_requires_devices_sync_permission(client, two_environments, app):
    from app.platform.models import EnvironmentRole, RoleAssignment
    from app.storage.time_utils import utc_now_naive

    env_a, _env_b = two_environments
    with app.app_context():
        # viewer 角色有 devices.view 但無 devices.sync，驗證動作端點窄權限不被清單權限放寬。
        viewer_role = EnvironmentRole.query.filter_by(
            environment_id=env_a.environment.id, code="viewer",
        ).one()
        RoleAssignment.query.filter_by(membership_id=env_a.membership.id).delete()
        _db.session.add(RoleAssignment(
            environment_id=env_a.environment.id, membership_id=env_a.membership.id,
            role_id=viewer_role.id, granted_at=utc_now_naive(),
        ))
        _db.session.commit()

    _login_and_switch(client, env_a)
    resp = client.post("/capabilities/devices/sync", data={"managed_tenant_id": str(env_a.tenant.id)})
    assert resp.status_code == 403
