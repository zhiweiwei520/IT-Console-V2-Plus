"""純邏輯測試：TenantContext 不依賴 DB 或 Flask（ADR-007 邊界規則）。"""
from __future__ import annotations

import uuid

import pytest

from app.storage.tenant_context import TenantContext


def _ctx(**overrides) -> TenantContext:
    defaults = dict(
        principal_id=uuid.uuid4(),
        environment_id=uuid.uuid4(),
        membership_id=uuid.uuid4(),
        permission_codes=frozenset({"accounts.view"}),
        correlation_id="corr-1",
    )
    defaults.update(overrides)
    return TenantContext(**defaults)


def test_has_permission_true_and_false():
    ctx = _ctx(permission_codes=frozenset({"accounts.view"}))
    assert ctx.has_permission("accounts.view") is True
    assert ctx.has_permission("accounts.manage") is False


def test_all_tenant_grant_allows_any_tenant():
    ctx = _ctx(allowed_managed_tenant_ids=None)
    assert ctx.can_access_tenant(uuid.uuid4()) is True


def test_explicit_grant_restricts_to_subset():
    allowed = uuid.uuid4()
    other = uuid.uuid4()
    ctx = _ctx(allowed_managed_tenant_ids=frozenset({allowed}))
    assert ctx.can_access_tenant(allowed) is True
    assert ctx.can_access_tenant(other) is False


def test_narrowed_to_tenant_rejects_out_of_grant():
    allowed = uuid.uuid4()
    other = uuid.uuid4()
    ctx = _ctx(allowed_managed_tenant_ids=frozenset({allowed}))
    narrowed = ctx.narrowed_to_tenant(allowed)
    assert narrowed.active_managed_tenant_id == allowed

    with pytest.raises(PermissionError):
        ctx.narrowed_to_tenant(other)


def test_context_is_frozen():
    ctx = _ctx()
    with pytest.raises(Exception):
        ctx.environment_id = uuid.uuid4()
