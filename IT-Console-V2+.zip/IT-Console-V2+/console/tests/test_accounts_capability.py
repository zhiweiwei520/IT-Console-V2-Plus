"""accounts capability：權限缺口與 service 層防線。"""
from __future__ import annotations

import uuid

import pytest

from app.capabilities.accounts.service import AccountService
from app.extensions import db as _db
from app.storage.tenant_context import TenantContext


def test_service_raises_without_accounts_view_permission(two_environments):
    env_a, _env_b = two_environments
    ctx = TenantContext(
        principal_id=env_a.principal.id,
        environment_id=env_a.environment.id,
        membership_id=env_a.membership.id,
        allowed_managed_tenant_ids=None,
        active_managed_tenant_id=None,
        permission_codes=frozenset(),  # 沒有 accounts.view
        correlation_id="no-perm",
    )
    service = AccountService(_db.session, ctx)
    with pytest.raises(PermissionError):
        service.list_accounts()


def test_web_route_returns_403_when_role_lacks_accounts_view(client, two_environments, app):
    env_a, _env_b = two_environments
    from app.platform.models import EnvironmentRole, RoleAssignment
    from app.storage.time_utils import utc_now_naive

    with app.app_context():
        bare_role = EnvironmentRole(environment_id=env_a.environment.id, code="bare", label="Bare", is_builtin=False)
        _db.session.add(bare_role)
        _db.session.flush()
        # 移除既有的 environment_admin 指派，只留下無任何權限的 bare 角色
        RoleAssignment.query.filter_by(membership_id=env_a.membership.id).delete()
        _db.session.add(RoleAssignment(
            environment_id=env_a.environment.id, membership_id=env_a.membership.id,
            role_id=bare_role.id, granted_at=utc_now_naive(),
        ))
        _db.session.commit()

    client.post("/auth/login", data={
        "environment_slug": "", "username": "user-a", "password": "TestPass!12345",
    })
    client.post(f"/environments/{env_a.environment.id}/switch")

    resp = client.get("/capabilities/accounts/")
    assert resp.status_code == 403


def _login_and_switch(client, env_a):
    client.post("/auth/login", data={
        "environment_slug": "", "username": "user-a", "password": "TestPass!12345",
    })
    client.post(f"/environments/{env_a.environment.id}/switch")
    client.post(f"/microsoft/managed-tenants/{env_a.tenant.id}/switch")


def test_sync_route_enqueues_job_for_authorized_tenant(client, two_environments, app):
    from app.jobs.models import DurableJob
    from app.microsoft.models import ManagedTenant

    env_a, _env_b = two_environments
    _login_and_switch(client, env_a)

    resp = client.post("/capabilities/accounts/sync", data={
        "managed_tenant_id": str(env_a.tenant.id),
    }, follow_redirects=False)
    assert resp.status_code == 302

    with app.app_context():
        assert DurableJob.query.filter_by(
            environment_id=env_a.environment.id, managed_tenant_id=env_a.tenant.id, job_type="accounts.sync",
        ).count() == 1


def test_sync_route_ignores_forged_foreign_tenant_form_value(client, two_environments, app):
    env_a, env_b = two_environments
    _login_and_switch(client, env_a)

    resp = client.post("/capabilities/accounts/sync", data={
        "managed_tenant_id": str(env_b.tenant.id),
    }, follow_redirects=False)
    assert resp.status_code == 302

    with app.app_context():
        from app.jobs.models import DurableJob
        assert DurableJob.query.filter_by(managed_tenant_id=env_b.tenant.id).count() == 0
        assert DurableJob.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 1


def test_sync_route_requires_accounts_sync_permission(client, two_environments, app):
    from app.platform.models import EnvironmentRole, RoleAssignment
    from app.storage.time_utils import utc_now_naive

    env_a, _env_b = two_environments
    with app.app_context():
        viewer_role = EnvironmentRole.query.filter_by(
            environment_id=env_a.environment.id, code="viewer",
        ).one()
        RoleAssignment.query.filter_by(membership_id=env_a.membership.id).delete()
        _db.session.add(RoleAssignment(
            environment_id=env_a.environment.id, membership_id=env_a.membership.id,
            role_id=viewer_role.id, granted_at=utc_now_naive(),
        ))
        _db.session.commit()

    _login_and_switch(client, env_a)
    resp = client.post("/capabilities/accounts/sync", data={"managed_tenant_id": str(env_a.tenant.id)})
    assert resp.status_code == 403


def test_selected_tenant_is_the_only_visible_and_query_string_cannot_switch(client, two_environments, app):
    from app.capabilities.accounts.service import seed_demo_accounts
    from app.microsoft.models import ManagedTenant

    env_a, _env_b = two_environments
    with app.app_context():
        second = ManagedTenant(
            environment_id=env_a.environment.id,
            entra_tenant_id=str(uuid.uuid4()),
            display_name="env-a-second",
            status="active",
        )
        _db.session.add(second)
        _db.session.flush()
        seed_demo_accounts(
            _db.session, environment_id=env_a.environment.id,
            managed_tenant_id=env_a.tenant.id, count=1,
        )[0].display_name = "Only First Tenant"
        seed_demo_accounts(
            _db.session, environment_id=env_a.environment.id,
            managed_tenant_id=second.id, count=1,
        )[0].display_name = "Only Second Tenant"
        second_id = second.id
        _db.session.commit()

    _login_and_switch(client, env_a)
    first_page = client.get(f"/capabilities/accounts/?managed_tenant_id={second_id}")
    first_body = first_page.get_data(as_text=True)
    assert "Only First Tenant" in first_body
    assert "Only Second Tenant" not in first_body

    client.post(f"/microsoft/managed-tenants/{second_id}/switch")
    second_page = client.get("/capabilities/accounts/")
    second_body = second_page.get_data(as_text=True)
    assert "Only First Tenant" not in second_body
    assert "Only Second Tenant" in second_body
