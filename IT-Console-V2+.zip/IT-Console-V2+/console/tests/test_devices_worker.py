"""devices.sync Dispatcher/Worker：Intune 分頁、checkpoint、重送與授權重驗證。

結構比照 test_accounts_worker.py；額外驗證 devices 特有的「形狀差異」——多數欄位可為空
（未指派使用者、未回報序號的裝置），upsert 不得因此失敗（只有缺 id 才算永久錯誤）。
"""
from __future__ import annotations

import asyncio
from datetime import timedelta
import uuid

from app.capabilities.devices.handler import DevicesSyncHandler
from app.capabilities.devices.models import Device, DeviceSyncCheckpoint
from app.extensions import db as _db
from app.jobs.dispatcher import DevicesSyncDispatcher
from app.jobs.models import DurableJob, JobDeadLetter
from app.jobs.worker import WorkerRunner
from app.microsoft.graph_client import GraphRetryableError, GraphTerminalError
from app.microsoft.models import TenantConnection
from app.storage.tenant_context import TenantContext
from app.storage.time_utils import utc_now_naive

_DEVICES = "/deviceManagement/managedDevices"
_DEVICES_P2 = "/deviceManagement/managedDevices?page=2"


class FakeGraphClient:
    def __init__(self, pages, *, fail_once_on=None):
        self.pages = pages
        self.fail_once_on = fail_once_on
        self.failed = False
        self.calls = []

    async def get(self, resource, *, params=None):
        self.calls.append(resource)
        if resource == self.fail_once_on and not self.failed:
            self.failed = True
            raise TimeoutError("simulated crash")
        return self.pages[resource]


class RaisingGraphClient:
    def __init__(self, exc: Exception) -> None:
        self.exc = exc
        self.calls: list[str] = []

    async def get(self, resource, *, params=None):
        self.calls.append(resource)
        raise self.exc


def _context(fixture) -> TenantContext:
    return TenantContext(
        principal_id=fixture.principal.id,
        environment_id=fixture.environment.id,
        membership_id=fixture.membership.id,
        allowed_managed_tenant_ids=None,
        active_managed_tenant_id=None,
        permission_codes=frozenset(fixture.membership.permission_codes),
        correlation_id=str(uuid.uuid4()),
    )


def _dispatch(fixture) -> str:
    dispatcher = DevicesSyncDispatcher(_db.session, _context(fixture))
    message_id = dispatcher.enqueue(fixture.tenant.id, operation_id=uuid.uuid4())
    _db.session.commit()
    return message_id


def _runner(fixture, client, *, worker_id="worker-1"):
    handler = DevicesSyncHandler(_db.session, lambda _env, _tenant: client)
    return WorkerRunner(
        _db.session, {"devices.sync": handler}, worker_id=worker_id, lease_seconds=60,
    )


def _pages():
    return {
        _DEVICES: {
            "value": [{
                "id": "device-1", "deviceName": "PC-01", "operatingSystem": "Windows",
                "osVersion": "10.0.22631", "complianceState": "compliant",
                "managedDeviceOwnerType": "company",
                "userPrincipalName": "one@example.com", "serialNumber": "SN-1",
                "lastSyncDateTime": "2026-07-11T00:00:00Z",
            }],
            "@odata.nextLink": _DEVICES_P2,
        },
        # 第二頁刻意缺 UPN／序號／OS（未指派、共享裝置）——驗證 nullable 欄位不會讓 upsert 失敗。
        _DEVICES_P2: {
            "value": [{
                "id": "device-2", "deviceName": "KIOSK-02",
                "complianceState": "noncompliant",
            }],
        },
    }


def test_worker_syncs_intune_pages_and_completes_job(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = FakeGraphClient(_pages())

    assert asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    job = _db.session.get(DurableJob, message_id)
    checkpoint = DeviceSyncCheckpoint.query.filter_by(job_id=job.id).one()
    devices = Device.query.filter_by(managed_tenant_id=env_a.tenant.id).order_by(Device.source_object_id).all()
    assert job.status == "completed"
    assert checkpoint.status == "completed"
    assert checkpoint.processed_count == 2
    assert [d.source_object_id for d in devices] == ["device-1", "device-2"]
    # 第二個裝置缺值欄位落成 None，deviceName 有值不退回 id。
    assert devices[1].device_name == "KIOSK-02"
    assert devices[1].user_principal_name is None
    assert devices[1].serial_number is None
    assert devices[1].operating_system is None
    assert devices[1].compliance_state == "noncompliant"


def test_device_missing_name_falls_back_to_source_id(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = FakeGraphClient({
        _DEVICES: {"value": [{"id": "device-x", "complianceState": "compliant"}]},
    })

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    assert _db.session.get(DurableJob, message_id).status == "completed"
    device = Device.query.filter_by(managed_tenant_id=env_a.tenant.id).one()
    assert device.device_name == "device-x"  # deviceName 缺值退回 source id，不破 NOT NULL


def test_device_missing_id_is_terminal(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = FakeGraphClient({
        _DEVICES: {"value": [{"deviceName": "no-id-device"}]},
    })

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    job = _db.session.get(DurableJob, message_id)
    assert job.status == "dead_letter"
    assert JobDeadLetter.query.filter_by(job_id=uuid.UUID(message_id)).one().reason == "graph_device_invalid"
    assert Device.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 0


def test_retry_resumes_from_committed_page_checkpoint(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = FakeGraphClient(_pages(), fail_once_on=_DEVICES_P2)
    runner = _runner(env_a, client)

    asyncio.run(runner.run_once(env_a.environment.id))
    checkpoint = DeviceSyncCheckpoint.query.filter_by(job_id=uuid.UUID(message_id)).one()
    assert checkpoint.next_resource == _DEVICES_P2
    assert checkpoint.processed_count == 1
    assert Device.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 1

    job = _db.session.get(DurableJob, message_id)
    job.available_at = utc_now_naive() - timedelta(seconds=1)
    _db.session.commit()
    asyncio.run(runner.run_once(env_a.environment.id))

    assert _db.session.get(DurableJob, message_id).status == "completed"
    assert Device.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 2
    assert client.calls == [_DEVICES, _DEVICES_P2, _DEVICES_P2]


def test_completed_checkpoint_makes_redelivery_idempotent(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = FakeGraphClient(_pages())
    runner = _runner(env_a, client)
    asyncio.run(runner.run_once(env_a.environment.id))
    calls_after_completion = list(client.calls)

    job = _db.session.get(DurableJob, message_id)
    job.status = "leased"
    job.lease_owner = "crashed-worker"
    job.lease_expires_at = utc_now_naive() - timedelta(seconds=1)
    job.completed_at = None
    _db.session.commit()

    asyncio.run(_runner(env_a, client, worker_id="recovery-worker").run_once(env_a.environment.id))
    assert _db.session.get(DurableJob, message_id).status == "completed"
    assert client.calls == calls_after_completion


def test_worker_dead_letters_job_after_membership_revocation(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    env_a.membership.status = "suspended"
    _db.session.commit()
    client = FakeGraphClient(_pages())

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    assert _db.session.get(DurableJob, message_id).status == "dead_letter"
    assert JobDeadLetter.query.filter_by(job_id=uuid.UUID(message_id)).one().reason == (
        "membership_no_longer_authorized"
    )
    assert client.calls == []


def test_worker_requeues_using_graph_retry_after_not_fixed_delay(two_environments):
    """04 §7：429 必須遵守 Retry-After，不能被 handler 蓋成寫死的 30 秒。"""
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = RaisingGraphClient(GraphRetryableError("graph_throttled", retry_after=91, status_code=429))
    before = utc_now_naive()

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    job = _db.session.get(DurableJob, message_id)
    assert job.status == "queued"
    assert job.last_error == "graph_throttled"
    delay = (job.available_at - before).total_seconds()
    assert 85 <= delay <= 95, f"expected ~91s delay from Retry-After, got {delay}s"


def test_worker_dead_letters_immediately_and_degrades_connection_on_401(two_environments):
    """401/403 是永久性錯誤，必須立刻 dead-letter 且降級 connection。"""
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    connection = TenantConnection(
        environment_id=env_a.environment.id,
        managed_tenant_id=env_a.tenant.id,
        client_id="client-abc",
        credential_ref="env:V2PLUS_TEST_SECRET",
        status="active",
    )
    _db.session.add(connection)
    _db.session.commit()

    client = RaisingGraphClient(GraphTerminalError("graph_authorization_failed", status_code=403))
    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    job = _db.session.get(DurableJob, message_id)
    assert job.status == "dead_letter"
    assert job.attempt == 1
    assert JobDeadLetter.query.filter_by(job_id=uuid.UUID(message_id)).one().reason == (
        "graph_authorization_failed"
    )
    assert _db.session.get(TenantConnection, connection.id).status == "degraded"
