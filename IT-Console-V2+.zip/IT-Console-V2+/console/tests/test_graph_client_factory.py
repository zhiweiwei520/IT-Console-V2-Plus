"""TenantGraphClientFactory：resolve ManagedTenant + TenantConnection with environment scope."""
from __future__ import annotations

from app.extensions import db as _db
from app.microsoft.factory import (
    GraphClientFactoryError,
    TenantGraphClientFactory,
    default_graph_client_factory,
)
from app.microsoft.graph_client import HttpGraphClient
from app.microsoft.models import TenantConnection


class FakeTokenBroker:
    def acquire_token(self, tenant, connection, *, resource="https://graph.microsoft.com"):
        return "unused"


def _add_connection(fixture, *, status="active") -> TenantConnection:
    connection = TenantConnection(
        environment_id=fixture.environment.id,
        managed_tenant_id=fixture.tenant.id,
        auth_mode="provider_bundle",
        client_id="client-abc",
        credential_ref="env:V2PLUS_TEST_SECRET",
        status=status,
    )
    _db.session.add(connection)
    _db.session.commit()
    return connection


def test_builds_http_graph_client_when_tenant_and_connection_are_active(two_environments):
    env_a, _env_b = two_environments
    _add_connection(env_a)
    factory = TenantGraphClientFactory(_db.session, FakeTokenBroker())

    client = factory(env_a.environment.id, env_a.tenant.id)

    assert isinstance(client, HttpGraphClient)
    assert client.tenant.id == env_a.tenant.id
    assert client.connection.status == "active"


def test_rejects_when_managed_tenant_belongs_to_other_environment(two_environments):
    env_a, env_b = two_environments
    _add_connection(env_a)
    factory = TenantGraphClientFactory(_db.session, FakeTokenBroker())

    try:
        factory(env_b.environment.id, env_a.tenant.id)
        assert False, "should have raised"
    except GraphClientFactoryError as exc:
        assert str(exc) == "managed_tenant_unavailable"


def test_rejects_when_tenant_connection_missing(two_environments):
    env_a, _env_b = two_environments
    factory = TenantGraphClientFactory(_db.session, FakeTokenBroker())

    try:
        factory(env_a.environment.id, env_a.tenant.id)
        assert False, "should have raised"
    except GraphClientFactoryError as exc:
        assert str(exc) == "tenant_connection_unavailable"


def test_rejects_when_connection_is_revoked(two_environments):
    env_a, _env_b = two_environments
    _add_connection(env_a, status="revoked")
    factory = TenantGraphClientFactory(_db.session, FakeTokenBroker())

    try:
        factory(env_a.environment.id, env_a.tenant.id)
        assert False, "should have raised"
    except GraphClientFactoryError as exc:
        assert str(exc) == "tenant_connection_unavailable"


def test_default_factory_wiring_reuses_token_broker_singleton(app, two_environments):
    """V2PLUS_GRAPH_CLIENT_FACTORY=app.microsoft.factory:default_graph_client_factory 的開箱即用路徑；
    MsalTokenBroker 必須是跨呼叫存活的單例（見 factory.py 註解），否則失去 token cache 意義。"""
    env_a, _env_b = two_environments
    _add_connection(env_a)

    with app.app_context():
        first = default_graph_client_factory(env_a.environment.id, env_a.tenant.id)
        second = default_graph_client_factory(env_a.environment.id, env_a.tenant.id)

    assert isinstance(first, HttpGraphClient)
    assert first.token_broker is second.token_broker
