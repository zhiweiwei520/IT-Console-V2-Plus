import asyncio
import uuid

from app.capabilities.licenses.handler import LicenseAuditSyncHandler
from app.capabilities.licenses.models import LicenseAuditCheckpoint, LicenseSku, MfaRegistration
from app.extensions import db
from app.jobs.dispatcher import LicenseAuditSyncDispatcher
from app.jobs.models import DurableJob
from app.jobs.worker import WorkerRunner
from app.storage.tenant_context import TenantContext


class FakeGraph:
    def __init__(self):
        self.calls = []

    async def get(self, resource, *, params=None):
        self.calls.append(resource)
        if resource == "/subscribedSkus":
            return {"value": [{"skuId": "sku-1", "skuPartNumber": "ENTERPRISEPACK", "capabilityStatus": "Enabled", "consumedUnits": 8, "prepaidUnits": {"enabled": 10, "warning": 1, "suspended": 0}}]}
        return {"value": [{"id": "user-1", "userPrincipalName": "one@example.com", "userDisplayName": "One", "isMfaRegistered": True, "isMfaCapable": True, "methodsRegistered": ["mobilePhone"]}]}


def _context(fixture):
    return TenantContext(principal_id=fixture.principal.id, environment_id=fixture.environment.id,
        membership_id=fixture.membership.id, allowed_managed_tenant_ids=None,
        active_managed_tenant_id=fixture.tenant.id,
        permission_codes=frozenset(fixture.membership.permission_codes), correlation_id="licenses-test")


def _login_select(client, fixture):
    client.post("/auth/login", data={"environment_slug": "", "username": "user-a", "password": "TestPass!12345"})
    client.post(f"/environments/{fixture.environment.id}/switch")
    client.post(f"/microsoft/managed-tenants/{fixture.tenant.id}/switch")


def test_worker_syncs_license_and_mfa_phases(two_environments):
    env_a, _ = two_environments
    message_id = LicenseAuditSyncDispatcher(db.session, _context(env_a)).enqueue(env_a.tenant.id, operation_id=uuid.uuid4())
    db.session.commit()
    graph = FakeGraph()
    runner = WorkerRunner(db.session, {"licenses.sync": LicenseAuditSyncHandler(db.session, lambda _e, _t: graph)}, worker_id="licenses-worker", lease_seconds=60)
    assert asyncio.run(runner.run_once(env_a.environment.id))
    assert db.session.get(DurableJob, message_id).status == "completed"
    assert LicenseAuditCheckpoint.query.filter_by(job_id=uuid.UUID(message_id)).one().status == "completed"
    assert LicenseSku.query.filter_by(managed_tenant_id=env_a.tenant.id).one().consumed_units == 8
    assert MfaRegistration.query.filter_by(managed_tenant_id=env_a.tenant.id).one().is_mfa_registered
    assert graph.calls == ["/subscribedSkus", "/reports/authenticationMethods/userRegistrationDetails"]


def test_web_page_requires_selected_tenant_and_renders_results(client, two_environments):
    env_a, _ = two_environments
    client.post("/auth/login", data={"environment_slug": "", "username": "user-a", "password": "TestPass!12345"})
    client.post(f"/environments/{env_a.environment.id}/switch")
    assert "/microsoft/managed-tenants/" in client.get("/capabilities/licenses/").headers["Location"]
    client.post(f"/microsoft/managed-tenants/{env_a.tenant.id}/switch")
    response = client.get("/capabilities/licenses/")
    assert response.status_code == 200
    assert "授權與 MFA 稽核" in response.get_data(as_text=True)


def test_sync_ignores_forged_tenant_form_value(client, two_environments):
    env_a, env_b = two_environments
    _login_select(client, env_a)
    client.post("/capabilities/licenses/sync", data={"managed_tenant_id": str(env_b.tenant.id)})
    assert DurableJob.query.filter_by(managed_tenant_id=env_a.tenant.id, job_type="licenses.sync").count() == 1
    assert DurableJob.query.filter_by(managed_tenant_id=env_b.tenant.id, job_type="licenses.sync").count() == 0
