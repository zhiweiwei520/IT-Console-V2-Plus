import asyncio,json,uuid
from app.capabilities.teams.handler import TeamsSyncHandler
from app.capabilities.teams.models import TeamAudit
from app.extensions import db
from app.jobs.dispatcher import TeamsSyncDispatcher
from app.jobs.models import DurableJob
from app.jobs.worker import WorkerRunner
from app.storage.tenant_context import TenantContext
class Graph:
    async def get(self,r,*,params=None):
        values={"/groups":[{"id":"t1","displayName":"SOC Team","visibility":"Private"}],"/teams/t1":{"isArchived":False},"/teams/t1/channels":{"value":[{"id":"c1","displayName":"General","membershipType":"standard"}]},"/groups/t1/members":{"value":[{"id":"u1","displayName":"Guest","userType":"Guest"}]},"/groups/t1/owners":{"value":[]},"/teams/t1/installedApps":{"value":[{"id":"ia1"}]}}
        value=values[r]; return {"value":value} if isinstance(value,list) else value
def context(f): return TenantContext(principal_id=f.principal.id,environment_id=f.environment.id,membership_id=f.membership.id,allowed_managed_tenant_ids=None,active_managed_tenant_id=f.tenant.id,permission_codes=frozenset(f.membership.permission_codes),correlation_id="teams-test")
def test_worker_syncs_five_dimension_quick_cache(two_environments):
    f,_=two_environments; mid=TeamsSyncDispatcher(db.session,context(f)).enqueue(f.tenant.id,operation_id=uuid.uuid4()); db.session.commit(); runner=WorkerRunner(db.session,{"teams.sync":TeamsSyncHandler(db.session,lambda _e,_t:Graph())},worker_id="teams",lease_seconds=60)
    assert asyncio.run(runner.run_once(f.environment.id)); assert db.session.get(DurableJob,mid).status=="completed"
    row=TeamAudit.query.one(); assert (row.channel_count,row.member_count,row.owner_count,row.guest_count,row.installed_app_count)==(1,1,0,1,1); assert json.loads(row.engagement_json)["status"]=="not_collected"; assert json.loads(row.security_json)["ownerless"]
def test_web_requires_tenant_and_ignores_forged_form(client,two_environments):
    f,other=two_environments; client.post("/auth/login",data={"environment_slug":"","username":"user-a","password":"TestPass!12345"}); client.post(f"/environments/{f.environment.id}/switch"); assert "/microsoft/managed-tenants/" in client.get("/capabilities/teams/").headers["Location"]
    client.post(f"/microsoft/managed-tenants/{f.tenant.id}/switch"); assert client.get("/capabilities/teams/").status_code==200; client.post("/capabilities/teams/sync",data={"managed_tenant_id":str(other.tenant.id)}); assert DurableJob.query.filter_by(job_type="teams.sync",managed_tenant_id=f.tenant.id).count()==1
