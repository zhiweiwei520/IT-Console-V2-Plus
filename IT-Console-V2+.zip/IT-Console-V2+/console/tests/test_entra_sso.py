"""Entra SSO 使用者登入（Phase D）。

驗證重點（對照 manifest §4 踩坑）：
- canonical key 固定 (iss, sub)，缺一即拒，**不**退回 email/UPN/preferred_username。
- MSAL 建構子做 OIDC discovery 丟原生 ValueError → 必須轉譯 SsoError，不得逃成 500。
- 未綁定的 Entra 身分登入 fail-closed（不自動開帳號）；已綁他人的身分不得重複綁定。
- SSO 未設定時三個 route 一律 404（不洩漏未設定原因）。
真實 IdP evidence 待 A1 測試 Tenant（與 C1–C8 同標準）。
"""
import pytest

from app.extensions import db
from app.microsoft.sso import EntraAuthBroker, SsoError, SsoNotConfigured, build_auth_broker, canonical_identity
from app.platform.models import ExternalLogin

IDENTITY = {
    "canonical_issuer": "https://login.microsoftonline.com/11111111-1111-1111-1111-111111111111/v2.0",
    "subject": "sub-0001",
    "issuer_tenant_id": "11111111-1111-1111-1111-111111111111",
    "object_id": "oid-0001",
}


class FakeBroker:
    def __init__(self, identity=None, error=None):
        self.identity, self.error = identity, error
    def begin(self, *, redirect_uri):
        return {"auth_uri": "https://login.microsoftonline.com/organizations/oauth2/v2.0/authorize?state=s", "state": "s"}
    def complete(self, flow, auth_response):
        if self.error:
            raise self.error
        return self.identity


class FakeMsalApp:
    def __init__(self, result=None, raise_on_acquire=None):
        self.result, self.raise_on_acquire = result, raise_on_acquire
    def initiate_auth_code_flow(self, scopes, redirect_uri):
        return {"auth_uri": "https://login.microsoftonline.com/x/authorize", "state": "s", "redirect_uri": redirect_uri, "scope": scopes}
    def acquire_token_by_auth_code_flow(self, flow, auth_response):
        if self.raise_on_acquire:
            raise self.raise_on_acquire
        return self.result


def _broker(msal_app):
    return EntraAuthBroker(
        client_id="cid", client_credential="secret",
        authority="https://login.microsoftonline.com/organizations",
        application_factory=lambda client_id, client_credential, authority: msal_app,
    )


# ── canonical identity：(iss, sub) 鐵則 ─────────────────────────────────────

def test_canonical_identity_requires_iss_and_sub():
    with pytest.raises(SsoError):
        canonical_identity({"sub": "s"})
    with pytest.raises(SsoError):
        canonical_identity({"iss": "https://login.microsoftonline.com/t/v2.0"})


def test_canonical_identity_never_falls_back_to_email_or_upn():
    claims = {"email": "a@b.com", "preferred_username": "a@b.com", "upn": "a@b.com", "iss": "https://login.microsoftonline.com/t/v2.0"}
    with pytest.raises(SsoError):  # 有 email/UPN 但缺 sub → 仍拒絕
        canonical_identity(claims)


def test_canonical_identity_extracts_optional_tid_oid():
    got = canonical_identity({"iss": "https://login.microsoftonline.com/t/v2.0", "sub": "s1", "tid": "t", "oid": "o"})
    assert (got["canonical_issuer"], got["subject"], got["issuer_tenant_id"], got["object_id"]) == (
        "https://login.microsoftonline.com/t/v2.0", "s1", "t", "o")


# ── broker：授權碼流程與錯誤轉譯 ────────────────────────────────────────────

def test_broker_rejects_non_microsoft_authority():
    with pytest.raises(SsoError) as exc:
        EntraAuthBroker(client_id="c", client_credential="s", authority="https://evil.example.com/organizations",
                        application_factory=lambda **_: FakeMsalApp())
    assert exc.value.code == "authority_not_allowed"


def test_broker_wraps_msal_constructor_valueerror():
    def factory(client_id, client_credential, authority):
        raise ValueError("oidc discovery failed")  # MSAL 建構子副作用（manifest §4）
    with pytest.raises(SsoError) as exc:
        EntraAuthBroker(client_id="c", client_credential="s",
                        authority="https://login.microsoftonline.com/organizations", application_factory=factory)
    assert exc.value.code == "authority_validation_failed"


def test_broker_complete_success_returns_canonical_identity():
    broker = _broker(FakeMsalApp(result={"access_token": "at", "id_token_claims": {
        "iss": IDENTITY["canonical_issuer"], "sub": IDENTITY["subject"], "tid": IDENTITY["issuer_tenant_id"], "oid": IDENTITY["object_id"]}}))
    assert broker.complete({"state": "s"}, {"state": "s", "code": "c"}) == IDENTITY


def test_broker_complete_maps_msal_valueerror_and_error_dict_and_missing_claims():
    with pytest.raises(SsoError) as exc:  # state 不符等 → MSAL ValueError
        _broker(FakeMsalApp(raise_on_acquire=ValueError("state mismatch"))).complete({}, {})
    assert exc.value.code == "auth_response_invalid"
    with pytest.raises(SsoError) as exc:
        _broker(FakeMsalApp(result={"error": "invalid_grant"})).complete({}, {})
    assert exc.value.code == "invalid_grant"
    with pytest.raises(SsoError) as exc:  # 有 token 但缺已驗證 claims → 拒絕
        _broker(FakeMsalApp(result={"access_token": "at"})).complete({}, {})
    assert exc.value.code == "id_token_claims_missing"


def test_build_auth_broker_disabled_or_incomplete_raises_not_configured():
    with pytest.raises(SsoNotConfigured):
        build_auth_broker({"ENTRA_SSO_ENABLED": False})
    with pytest.raises(SsoNotConfigured):
        build_auth_broker({"ENTRA_SSO_ENABLED": True, "ENTRA_LOGIN_CLIENT_ID": "", "ENTRA_LOGIN_CREDENTIAL_REF": "env:X"})


# ── web routes ──────────────────────────────────────────────────────────────

def test_sso_routes_404_when_not_configured(client, two_environments):
    assert client.get("/auth/entra/login").status_code == 404
    assert client.get("/auth/entra/callback").status_code == 404


def test_login_redirects_to_idp_and_stores_flow(client, two_environments):
    client.application.config["ENTRA_AUTH_BROKER"] = FakeBroker(identity=IDENTITY)
    resp = client.get("/auth/entra/login")
    assert resp.status_code == 302 and resp.headers["Location"].startswith("https://login.microsoftonline.com/")
    with client.session_transaction() as sess:
        assert sess["entra_auth_flow"]["state"] == "s" and sess["entra_flow_mode"] == "login"


def test_callback_without_flow_redirects_to_login(client, two_environments):
    client.application.config["ENTRA_AUTH_BROKER"] = FakeBroker(identity=IDENTITY)
    resp = client.get("/auth/entra/callback")
    assert resp.status_code == 302 and "/auth/login" in resp.headers["Location"]


def test_unbound_identity_login_is_fail_closed(client, two_environments):
    client.application.config["ENTRA_AUTH_BROKER"] = FakeBroker(identity=IDENTITY)
    client.get("/auth/entra/login")
    resp = client.get("/auth/entra/callback?code=c&state=s")
    assert "/auth/login" in resp.headers["Location"]  # 未綁定 → 不開帳號、退回登入頁
    assert ExternalLogin.query.count() == 0
    assert client.get("/environments/").status_code in (302, 401)  # 未登入


def test_sso_error_during_callback_redirects_to_login(client, two_environments):
    client.application.config["ENTRA_AUTH_BROKER"] = FakeBroker(error=SsoError("invalid_grant"))
    client.get("/auth/entra/login")
    resp = client.get("/auth/entra/callback?code=c&state=s")
    assert "/auth/login" in resp.headers["Location"]
    with client.session_transaction() as sess:
        assert "entra_auth_flow" not in sess  # flow 一次性，用畢即丟


def test_bound_identity_logs_in(client, two_environments):
    f, _ = two_environments
    db.session.add(ExternalLogin(principal_id=f.principal.id, canonical_issuer=IDENTITY["canonical_issuer"], subject=IDENTITY["subject"]))
    db.session.commit()
    client.application.config["ENTRA_AUTH_BROKER"] = FakeBroker(identity=IDENTITY)
    client.get("/auth/entra/login")
    resp = client.get("/auth/entra/callback?code=c&state=s")
    assert "/environments/" in resp.headers["Location"]
    assert client.get("/environments/").status_code == 200  # 已登入


def test_link_binds_identity_to_current_principal(client, two_environments):
    f, _ = two_environments
    client.application.config["ENTRA_AUTH_BROKER"] = FakeBroker(identity=IDENTITY)
    client.post("/auth/login", data={"environment_slug": "", "username": "user-a", "password": "TestPass!12345"})
    client.get("/auth/entra/link")
    client.get("/auth/entra/callback?code=c&state=s")
    row = ExternalLogin.query.one()
    assert row.principal_id == f.principal.id and row.subject == IDENTITY["subject"]


def test_link_rejects_identity_already_bound_to_other_principal(client, two_environments):
    f, other = two_environments
    db.session.add(ExternalLogin(principal_id=other.principal.id, canonical_issuer=IDENTITY["canonical_issuer"], subject=IDENTITY["subject"]))
    db.session.commit()
    client.application.config["ENTRA_AUTH_BROKER"] = FakeBroker(identity=IDENTITY)
    client.post("/auth/login", data={"environment_slug": "", "username": "user-a", "password": "TestPass!12345"})
    client.get("/auth/entra/link")
    client.get("/auth/entra/callback?code=c&state=s")
    row = ExternalLogin.query.one()  # 沒有第二筆；仍綁在原 Principal
    assert row.principal_id == other.principal.id
