"""
測試固定 SQLite in-memory（AGENTS.md sandbox 規則：不得觸碰 live database）。
db.metadata.create_all() 用於單元測試快速建表，來源與 Alembic migration 一致
（見 tests/test_migration_sqlite.py 交叉驗證兩者不漂移）；不代表 production 可用
db.create_all()（09-development-standards.md §7 仍要求 production 只由 Alembic 管理）。
"""
from __future__ import annotations

import os
import uuid

os.environ["FLASK_ENV"] = "testing"

import pytest

from app import create_app
from app.extensions import db as _db


@pytest.fixture()
def app():
    application = create_app()
    with application.app_context():
        _db.metadata.create_all(bind=_db.engine)
        yield application
        _db.session.remove()
        _db.metadata.drop_all(bind=_db.engine)


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def db_session(app):
    return _db.session


class EnvironmentFixture:
    """一組 Environment + 一個 Managed Tenant + 一位使用者（含 platform local login）。"""

    def __init__(self, environment, tenant, principal, login_row, membership, role):
        self.environment = environment
        self.tenant = tenant
        self.principal = principal
        self.login = login_row
        self.membership = membership
        self.role = role


def _build_environment(slug: str, username: str) -> EnvironmentFixture:
    from app.microsoft.models import ManagedTenant
    from app.platform.models import (
        EnvironmentMembership, ManagementEnvironment, Principal,
        PlatformLocalLogin, RoleAssignment,
    )
    from app.platform.permissions import ensure_builtin_permissions, ensure_environment_builtin_roles
    from app.platform.security import hash_password
    from app.storage.time_utils import utc_now_naive

    ensure_builtin_permissions()

    env = ManagementEnvironment(slug=slug, name=slug, status="active")
    _db.session.add(env)
    _db.session.commit()

    roles = ensure_environment_builtin_roles(env.id)

    principal = Principal(display_name=username)
    _db.session.add(principal)
    _db.session.flush()

    login_row = PlatformLocalLogin(
        principal_id=principal.id,
        normalized_username=username,
        password_hash=hash_password("TestPass!12345"),
    )
    _db.session.add(login_row)
    _db.session.flush()

    membership = EnvironmentMembership(
        environment_id=env.id, principal_id=principal.id, all_managed_tenants=True,
    )
    _db.session.add(membership)
    _db.session.flush()

    _db.session.add(RoleAssignment(
        environment_id=env.id, membership_id=membership.id,
        role_id=roles["environment_admin"].id, granted_at=utc_now_naive(),
    ))

    tenant = ManagedTenant(
        environment_id=env.id, entra_tenant_id=str(uuid.uuid4()),
        display_name=f"{slug}-tenant", status="active",
    )
    _db.session.add(tenant)
    _db.session.commit()

    return EnvironmentFixture(env, tenant, principal, login_row, membership, roles["environment_admin"])


@pytest.fixture()
def two_environments(app):
    """Environment A／B，各自獨立 Tenant 與使用者，故意用相同 display_name／username 樣式命名。"""
    env_a = _build_environment("env-a", "user-a")
    env_b = _build_environment("env-b", "user-b")
    return env_a, env_b
