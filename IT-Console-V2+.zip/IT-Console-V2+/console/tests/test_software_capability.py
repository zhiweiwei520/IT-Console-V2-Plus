import asyncio,uuid
from app.capabilities.software.handler import SoftwareSyncHandler
from app.capabilities.software.models import DetectedSoftware
from app.extensions import db
from app.jobs.dispatcher import SoftwareSyncDispatcher
from app.jobs.models import DurableJob
from app.jobs.worker import WorkerRunner
from app.storage.tenant_context import TenantContext
class Graph:
    async def get(self,resource,*,params=None): return {"value":[{"id":"app-1","displayName":"Contoso Agent","version":"2.1","publisher":"Contoso","platform":"windows","sizeInByte":2048,"deviceCount":4}]}
def context(f): return TenantContext(principal_id=f.principal.id,environment_id=f.environment.id,membership_id=f.membership.id,allowed_managed_tenant_ids=None,active_managed_tenant_id=f.tenant.id,permission_codes=frozenset(f.membership.permission_codes),correlation_id="software-test")
def test_worker_syncs_detected_apps(two_environments):
    f,_=two_environments; mid=SoftwareSyncDispatcher(db.session,context(f)).enqueue(f.tenant.id,operation_id=uuid.uuid4()); db.session.commit()
    runner=WorkerRunner(db.session,{"software.sync":SoftwareSyncHandler(db.session,lambda _e,_t:Graph())},worker_id="software",lease_seconds=60)
    assert asyncio.run(runner.run_once(f.environment.id)); assert db.session.get(DurableJob,mid).status=="completed"
    row=DetectedSoftware.query.one(); assert row.display_name=="Contoso Agent" and row.device_count==4
def test_web_requires_tenant_and_ignores_forged_form(client,two_environments):
    f,other=two_environments; client.post("/auth/login",data={"environment_slug":"","username":"user-a","password":"TestPass!12345"}); client.post(f"/environments/{f.environment.id}/switch")
    assert "/microsoft/managed-tenants/" in client.get("/capabilities/software/").headers["Location"]
    client.post(f"/microsoft/managed-tenants/{f.tenant.id}/switch"); assert client.get("/capabilities/software/").status_code==200
    client.post("/capabilities/software/sync",data={"managed_tenant_id":str(other.tenant.id)})
    assert DurableJob.query.filter_by(job_type="software.sync",managed_tenant_id=f.tenant.id).count()==1
