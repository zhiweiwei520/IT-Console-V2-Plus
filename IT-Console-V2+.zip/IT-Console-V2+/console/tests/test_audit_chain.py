"""Environment audit hash chain：每環境獨立排序、鏈頭一致與竄改偵測。"""
from __future__ import annotations

import uuid

import pytest
from sqlalchemy import update

from app.extensions import db as _db
from app.platform.audit import GENESIS_HASH, record_audit, verify_audit_chain
from app.platform.models import EnvironmentAuditLog


def _record(fixture, action: str) -> EnvironmentAuditLog:
    return record_audit(
        environment_id=fixture.environment.id,
        actor_principal_id=fixture.principal.id,
        action=action,
        target_type="principal",
        target_id=fixture.principal.id,
    )


def test_each_environment_has_an_independent_chain(two_environments):
    env_a, env_b = two_environments
    a1 = _record(env_a, "test.a1")
    b1 = _record(env_b, "test.b1")
    a2 = _record(env_a, "test.a2")
    _db.session.commit()

    assert (a1.chain_sequence, a2.chain_sequence) == (1, 2)
    assert b1.chain_sequence == 1
    assert a1.previous_hash == GENESIS_HASH
    assert a2.previous_hash == a1.entry_hash
    assert b1.previous_hash == GENESIS_HASH
    assert verify_audit_chain(env_a.environment.id).valid
    assert verify_audit_chain(env_b.environment.id).valid


def test_verification_detects_payload_tampering(two_environments):
    env_a, _env_b = two_environments
    entry = _record(env_a, "settings.update")
    _db.session.commit()
    assert verify_audit_chain(env_a.environment.id).valid

    # 模擬繞過 ORM append-only event 的資料庫層竄改。
    _db.session.execute(
        update(EnvironmentAuditLog)
        .where(EnvironmentAuditLog.id == entry.id)
        .values(action="settings.tampered")
    )
    _db.session.commit()

    result = verify_audit_chain(env_a.environment.id)
    assert not result.valid
    assert result.error == "entry hash mismatch"


def test_audit_rows_remain_append_only(two_environments):
    env_a, _env_b = two_environments
    entry = _record(env_a, "accounts.read")
    _db.session.commit()

    entry.reason = "changed"
    with pytest.raises(RuntimeError, match="append-only"):
        _db.session.commit()
    _db.session.rollback()


def test_unknown_environment_cannot_start_chain(app):
    with pytest.raises(ValueError, match="unknown environment"):
        record_audit(
            environment_id=uuid.uuid4(),
            actor_principal_id=None,
            action="invalid",
        )

