"""
Web 層登入與環境切換測試。對應 07-testing-acceptance.md §3：跨 Environment 提交任何 ID
（此處為 environment_id）都必須失敗，且 membership 版本比對會在權限被抽換後擋下請求。
"""
from __future__ import annotations

from app.extensions import db as _db


def test_wrong_password_does_not_authenticate(client, two_environments):
    env_a, _env_b = two_environments
    resp = client.post("/auth/login", data={
        "environment_slug": "", "username": "user-a", "password": "wrong-password",
    })
    assert resp.status_code == 200  # 留在登入頁，不 redirect

    # 未登入狀態下訪問受保護頁應被導向登入
    protected = client.get("/environments/")
    assert protected.status_code in (302, 401)


def test_platform_login_then_switch_environment(client, two_environments):
    env_a, env_b = two_environments

    login_resp = client.post("/auth/login", data={
        "environment_slug": "", "username": "user-a", "password": "TestPass!12345",
    }, follow_redirects=False)
    assert login_resp.status_code == 302
    assert login_resp.headers["Location"].endswith("/environments/")

    env_list = client.get("/environments/")
    assert env_list.status_code == 200
    assert env_a.environment.slug.encode() in env_list.data
    # user-a 沒有 env-b 的 membership，不應出現在清單
    assert env_b.environment.slug.encode() not in env_list.data

    switch_resp = client.post(f"/environments/{env_a.environment.id}/switch", follow_redirects=False)
    assert switch_resp.status_code == 302
    assert "/microsoft/managed-tenants/" in switch_resp.headers["Location"]

    accounts_page = client.get("/capabilities/accounts/")
    assert accounts_page.status_code == 302
    client.post(f"/microsoft/managed-tenants/{env_a.tenant.id}/switch")
    assert client.get("/capabilities/accounts/").status_code == 200


def test_cannot_switch_to_environment_without_membership(client, two_environments):
    env_a, env_b = two_environments
    client.post("/auth/login", data={
        "environment_slug": "", "username": "user-a", "password": "TestPass!12345",
    })
    resp = client.post(f"/environments/{env_b.environment.id}/switch")
    assert resp.status_code == 404


def test_session_cannot_be_forged_to_foreign_environment(client, two_environments):
    """即使在 session 塞入 B 的 environment_id（模擬竄改），沒有 membership 一律 404。"""
    env_a, env_b = two_environments
    client.post("/auth/login", data={
        "environment_slug": "", "username": "user-a", "password": "TestPass!12345",
    })
    with client.session_transaction() as sess:
        sess["active_environment_id"] = str(env_b.environment.id)
        sess["membership_version_seen"] = 1

    resp = client.get("/capabilities/accounts/")
    assert resp.status_code == 404


def test_membership_version_bump_forces_reauthorization(client, two_environments):
    env_a, _env_b = two_environments
    client.post("/auth/login", data={
        "environment_slug": "", "username": "user-a", "password": "TestPass!12345",
    })
    client.post(f"/environments/{env_a.environment.id}/switch")
    client.post(f"/microsoft/managed-tenants/{env_a.tenant.id}/switch")

    ok = client.get("/capabilities/accounts/")
    assert ok.status_code == 200

    env_a.membership.version += 1
    _db.session.commit()

    stale = client.get("/capabilities/accounts/")
    assert stale.status_code == 403


def test_environment_local_login_auto_switches(client, two_environments, app):
    env_a, _env_b = two_environments
    from app.platform.models import EnvironmentLocalLogin
    from app.platform.security import hash_password

    with app.app_context():
        local_login = EnvironmentLocalLogin(
            environment_id=env_a.environment.id,
            principal_id=env_a.principal.id,
            normalized_username="local-a",
            password_hash=hash_password("LocalPass!12345"),
        )
        _db.session.add(local_login)
        _db.session.commit()

    resp = client.post("/auth/login", data={
        "environment_slug": env_a.environment.slug,
        "username": "local-a",
        "password": "LocalPass!12345",
    }, follow_redirects=False)
    assert resp.status_code == 302
    assert resp.headers["Location"].endswith("/microsoft/managed-tenants/")
