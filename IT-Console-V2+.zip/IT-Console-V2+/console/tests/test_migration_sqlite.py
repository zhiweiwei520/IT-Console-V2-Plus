"""
驗證 Alembic migration 腳本本身可執行且與 model metadata 不漂移。

conftest.py 的其他測試改用 db.metadata.create_all() 加速（來源仍是同一組 model），
本檔案專門驗證 migrations/versions/ 下「實際部署會執行」的腳本語法正確、可在乾淨 DB
上跑完（RLS 語句於非 PostgreSQL 方言下會被略過）。
"""
from __future__ import annotations

import os
from datetime import datetime
import uuid

os.environ["FLASK_ENV"] = "testing"

from flask_migrate import upgrade as migrate_upgrade
from sqlalchemy import inspect, text

from app import create_app
from app.extensions import db as _db


def test_alembic_upgrade_creates_all_model_tables():
    app = create_app()
    with app.app_context():
        migrate_upgrade()

        inspector = inspect(_db.engine)
        actual_tables = set(inspector.get_table_names())
        expected_tables = set(_db.metadata.tables.keys())

        missing = expected_tables - actual_tables
        assert not missing, f"migration 遺漏建立這些表：{missing}"

        for table_name, model_table in _db.metadata.tables.items():
            actual_columns = {column["name"] for column in inspector.get_columns(table_name)}
            expected_columns = set(model_table.columns.keys())
            assert actual_columns == expected_columns, (
                f"{table_name} migration/model 欄位漂移："
                f"missing={expected_columns - actual_columns}, "
                f"extra={actual_columns - expected_columns}"
            )


def test_audit_chain_migration_backfills_existing_rows():
    app = create_app()
    with app.app_context():
        migrate_upgrade(revision="0001")
        environment_id = uuid.UUID("10000000-0000-0000-0000-000000000001")
        first_id = uuid.UUID("20000000-0000-0000-0000-000000000001")
        second_id = uuid.UUID("20000000-0000-0000-0000-000000000002")
        created_at = datetime(2026, 7, 11, 1, 2, 3)
        created_at_db = created_at.isoformat(sep=" ")

        _db.session.execute(text("""
            INSERT INTO management_environments
                (id, slug, name, status, isolation_mode, membership_version, created_at, updated_at)
            VALUES
                (:id, 'legacy-env', 'Legacy Env', 'active', 'pooled', 1, :created_at, :created_at)
        """), {"id": environment_id.hex, "created_at": created_at_db})
        for entry_id, action in ((second_id, "legacy.second"), (first_id, "legacy.first")):
            _db.session.execute(text("""
                INSERT INTO environment_audit_logs
                    (id, environment_id, action, outcome, created_at)
                VALUES (:id, :environment_id, :action, 'success', :created_at)
            """), {
                "id": entry_id.hex,
                "environment_id": environment_id.hex,
                "action": action,
                "created_at": created_at_db,
            })
        _db.session.commit()

        migrate_upgrade()

        from app.platform.audit import verify_audit_chain
        from app.platform.models import EnvironmentAuditLog

        entries = EnvironmentAuditLog.query.order_by(EnvironmentAuditLog.chain_sequence).all()
        assert [entry.id for entry in entries] == [first_id, second_id]
        assert verify_audit_chain(environment_id).valid
