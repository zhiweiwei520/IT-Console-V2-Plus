"""WorkerProcess：跨 Environment fairness、graceful drain 與 metrics。"""
from __future__ import annotations

import asyncio
import uuid

from app.extensions import db as _db
from app.jobs.bootstrap import load_graph_client_factory
from app.jobs.dispatcher import AccountsSyncDispatcher
from app.jobs.models import DurableJob
from app.jobs.process import WorkerProcess
from app.jobs.worker import RetryableJobError, WorkerMetrics, WorkerRunner
from app.storage.tenant_context import TenantContext


def _context(fixture):
    return TenantContext(
        principal_id=fixture.principal.id,
        environment_id=fixture.environment.id,
        membership_id=fixture.membership.id,
        permission_codes=frozenset(fixture.membership.permission_codes),
        correlation_id=str(uuid.uuid4()),
        allowed_managed_tenant_ids=None,
        active_managed_tenant_id=None,
    )


def _enqueue(fixture):
    message_id = AccountsSyncDispatcher(_db.session, _context(fixture)).enqueue(
        fixture.tenant.id, operation_id=uuid.uuid4(),
    )
    _db.session.commit()
    return message_id


class SuccessfulHandler:
    async def handle(self, _envelope, **_kwargs):
        return None


class RetryHandler:
    async def handle(self, _envelope, **_kwargs):
        raise RetryableJobError("temporary", delay_seconds=10)


class BlockingHandler:
    def __init__(self):
        self.started = asyncio.Event()
        self.release = asyncio.Event()

    async def handle(self, _envelope, **_kwargs):
        self.started.set()
        await self.release.wait()


def test_cycle_claims_one_job_per_environment(two_environments):
    env_a, env_b = two_environments
    first = _enqueue(env_a)
    second = _enqueue(env_b)
    metrics = WorkerMetrics()
    runner = WorkerRunner(
        _db.session, {"accounts.sync": SuccessfulHandler()},
        worker_id="fair-worker", metrics=metrics,
    )
    snapshots = []
    process = WorkerProcess(_db.session, runner, poll_seconds=0.01, metrics_callback=snapshots.append)

    assert asyncio.run(process.run_cycle()) == 2
    assert _db.session.get(DurableJob, first).status == "completed"
    assert _db.session.get(DurableJob, second).status == "completed"
    assert metrics.claimed == metrics.completed == 2
    assert snapshots[-1]["active_jobs"] == 0


def test_graceful_stop_drains_current_job_without_claiming_next(two_environments):
    env_a, _env_b = two_environments
    first = _enqueue(env_a)
    second = _enqueue(env_a)

    async def scenario():
        handler = BlockingHandler()
        runner = WorkerRunner(
            _db.session, {"accounts.sync": handler}, worker_id="drain-worker",
        )
        process = WorkerProcess(_db.session, runner, poll_seconds=0.01)
        task = asyncio.create_task(process.run_forever())
        await asyncio.wait_for(handler.started.wait(), timeout=2)
        process.request_stop()
        handler.release.set()
        await asyncio.wait_for(task, timeout=2)
        return runner.metrics

    metrics = asyncio.run(scenario())
    statuses = {
        str(job.id): job.status
        for job in DurableJob.query.filter(DurableJob.id.in_((uuid.UUID(first), uuid.UUID(second)))).all()
    }
    assert sorted(statuses.values()) == ["completed", "queued"]
    assert metrics.completed == 1
    assert metrics.active_jobs == 0


def test_retry_updates_metrics(two_environments):
    env_a, _env_b = two_environments
    _enqueue(env_a)
    metrics = WorkerMetrics()
    runner = WorkerRunner(
        _db.session, {"accounts.sync": RetryHandler()},
        worker_id="retry-worker", metrics=metrics,
    )
    process = WorkerProcess(_db.session, runner, poll_seconds=0.01)

    assert asyncio.run(process.run_cycle()) == 1
    assert metrics.claimed == 1
    assert metrics.retried == 1
    assert metrics.completed == metrics.dead_lettered == 0


def test_configured_factory_loader_fails_loud():
    assert callable(load_graph_client_factory("app.storage.time_utils:utc_now_naive"))
    try:
        load_graph_client_factory("missing-format")
        assert False, "invalid import path must fail"
    except ValueError as exc:
        assert "module:attribute" in str(exc)
