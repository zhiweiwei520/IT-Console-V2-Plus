"""顯示層時區鐵則（root CLAUDE.md B2）：DB 存 naive UTC，顯示一律 UTC+8（Asia/Taipei）。

`to_taipei_str` 為唯一顯示轉換入口，模板以 `| datetime_local` 使用；本檔驗證：
- naive UTC datetime → +8（含跨日）；aware datetime 先轉 UTC 再 +8。
- Graph ISO 字串（尾碼 Z、7 位小數秒）走同一條轉換。
- None／空字串 → "—"；無法解析的字串原樣回傳（顯示 filter 不得讓整頁 500）。
- signin_logs 清單頁實際 render 出 +8 後的時間，且標頭為 (UTC+8)。
"""
from datetime import datetime, timezone

from app.extensions import db as _db
from app.storage.time_utils import to_taipei_str


def test_naive_utc_datetime_shifts_plus_eight():
    assert to_taipei_str(datetime(2026, 7, 11, 2, 3, 4)) == "2026-07-11 10:03"
    # 跨日：UTC 23:30 → 台北隔天 07:30
    assert to_taipei_str(datetime(2026, 7, 11, 23, 30, 0)) == "2026-07-12 07:30"


def test_aware_datetime_normalized_to_utc_first():
    aware = datetime(2026, 7, 11, 10, 3, 4, tzinfo=timezone.utc)
    assert to_taipei_str(aware) == "2026-07-11 18:03"


def test_graph_iso_string_with_z_and_seven_digit_fraction():
    assert to_taipei_str("2026-07-11T02:03:04Z") == "2026-07-11 10:03"
    assert to_taipei_str("2026-07-11T02:03:04.1234567Z") == "2026-07-11 10:03"


def test_none_and_empty_render_dash_and_garbage_passes_through():
    assert to_taipei_str(None) == "—"
    assert to_taipei_str("   ") == "—"
    assert to_taipei_str("not-a-date") == "not-a-date"  # 原樣露出供排查，不 raise


def test_custom_format_argument():
    assert to_taipei_str(datetime(2026, 7, 11, 2, 3, 4), "%Y-%m-%d %H:%M:%S") == "2026-07-11 10:03:04"


def test_filter_registered_and_signin_page_renders_taipei_time(client, two_environments, app):
    assert app.jinja_env.filters["datetime_local"] is to_taipei_str

    from app.capabilities.signin_logs.models import SignInLog
    f, _ = two_environments
    _db.session.add(SignInLog(
        environment_id=f.environment.id, managed_tenant_id=f.tenant.id,
        source_object_id="tz-check", created_datetime=datetime(2026, 7, 11, 2, 3, 4),
        user_display_name="TZ Check", status="success",
    ))
    _db.session.commit()

    client.post("/auth/login", data={"environment_slug": "", "username": "user-a", "password": "TestPass!12345"})
    client.post(f"/environments/{f.environment.id}/switch")
    client.post(f"/microsoft/managed-tenants/{f.tenant.id}/switch")
    body = client.get("/capabilities/signin-logs/").get_data(as_text=True)
    assert "2026-07-11 10:03:04" in body  # UTC 02:03:04 → 台北 10:03:04
    assert "02:03:04" not in body.replace("2026-07-11 10:03:04", "")  # 不再露出 naive UTC
    assert "時間 (UTC+8)" in body
