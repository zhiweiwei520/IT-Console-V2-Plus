import asyncio,uuid
from datetime import datetime
from app.capabilities.sentinel.handler import SentinelSyncHandler
from app.capabilities.sentinel.models import SecurityIncident
from app.extensions import db
from app.jobs.dispatcher import SentinelSyncDispatcher
from app.jobs.models import DurableJob
from app.jobs.worker import WorkerRunner
from app.storage.tenant_context import TenantContext
class Graph:
    def __init__(self): self.calls=[]
    async def get(self,r,*,params=None):
        self.calls.append((r,params))
        return {"value":[{"id":"i1","displayName":"Multi-stage incident","severity":"high","status":"active","classification":"truePositive","determination":"multiStagedAttack","createdDateTime":"2026-07-11T02:03:04Z","lastUpdateDateTime":"2026-07-11T02:30:00Z","assignedTo":"soc@contoso.com","incidentWebUrl":"https://security.microsoft.com/incidents/i1"}]}
def context(f): return TenantContext(principal_id=f.principal.id,environment_id=f.environment.id,membership_id=f.membership.id,allowed_managed_tenant_ids=None,active_managed_tenant_id=f.tenant.id,permission_codes=frozenset(f.membership.permission_codes),correlation_id="sentinel-test")
def test_worker_incremental_syncs_incidents_append_only(two_environments):
    f,_=two_environments; graph=Graph(); mid=SentinelSyncDispatcher(db.session,context(f)).enqueue(f.tenant.id,operation_id=uuid.uuid4()); db.session.commit(); runner=WorkerRunner(db.session,{"sentinel.sync":SentinelSyncHandler(db.session,lambda _e,_t:graph)},worker_id="sentinel",lease_seconds=60)
    assert asyncio.run(runner.run_once(f.environment.id)); assert db.session.get(DurableJob,mid).status=="completed"
    row=SecurityIncident.query.one(); assert (row.severity,row.status,row.classification,row.assigned_to)==("high","active","truePositive","soc@contoso.com"); assert isinstance(row.created_datetime,datetime) and row.last_update_datetime is not None
    # 首次同步無資料 → 初始視窗 watermark 帶進 $filter（增量時間區間查詢）。
    assert graph.calls[0][0]=="/security/incidents"; assert "createdDateTime ge" in graph.calls[0][1]["$filter"]
def test_web_requires_tenant_and_ignores_forged_form(client,two_environments):
    f,other=two_environments; client.post("/auth/login",data={"environment_slug":"","username":"user-a","password":"TestPass!12345"}); client.post(f"/environments/{f.environment.id}/switch"); assert "/microsoft/managed-tenants/" in client.get("/capabilities/sentinel/").headers["Location"]
    client.post(f"/microsoft/managed-tenants/{f.tenant.id}/switch"); assert client.get("/capabilities/sentinel/").status_code==200; client.post("/capabilities/sentinel/sync",data={"managed_tenant_id":str(other.tenant.id)}); assert DurableJob.query.filter_by(job_type="sentinel.sync",managed_tenant_id=f.tenant.id).count()==1
