"""內嵌 worker 的啟動守門邏輯。

重點：確認它**不會**在 pytest／停用／未設 factory 時啟動背景執行緒——這是避免測試與
manage.py CLI 被連帶啟動一個亂寫 DB 的背景 worker 的關鍵防線。實際「執行緒撿走並處理
job」的行為由 WorkerProcess／WorkerRunner 的既有測試覆蓋（test_worker_process.py 等），
本檔不重測執行緒排程（避免 flaky）。
"""
from __future__ import annotations

from app.jobs.embedded import start_embedded_worker


def test_not_started_under_testing(app):
    # app fixture 為 TestingConfig（TESTING=True）→ 一律不啟動，回 False。
    assert start_embedded_worker(app) is False


def test_not_started_when_disabled(app, monkeypatch):
    monkeypatch.setitem(app.config, "TESTING", False)
    monkeypatch.setenv("V2PLUS_EMBEDDED_WORKER", "false")
    monkeypatch.setenv(
        "V2PLUS_GRAPH_CLIENT_FACTORY", "app.microsoft.factory:default_graph_client_factory",
    )
    assert start_embedded_worker(app) is False


def test_not_started_without_graph_factory(app, monkeypatch):
    monkeypatch.setitem(app.config, "TESTING", False)
    monkeypatch.setenv("V2PLUS_EMBEDDED_WORKER", "true")
    monkeypatch.delenv("V2PLUS_GRAPH_CLIENT_FACTORY", raising=False)
    assert start_embedded_worker(app) is False
