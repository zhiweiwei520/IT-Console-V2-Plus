"""EnvironmentCredentialProvider：env: scheme allowlist（04 §2 BYO app 過渡方案）。"""
from __future__ import annotations

import uuid

import pytest
from cryptography.fernet import Fernet

from app.extensions import db as _db
from app.microsoft.credentials import (
    CompositeCredentialProvider,
    CredentialResolutionError,
    DatabaseEncryptedCredentialProvider,
    EnvironmentCredentialProvider,
)
from app.microsoft.encryption import encrypt_secret
from app.microsoft.models import TenantConnection


def test_resolves_allowed_env_var(monkeypatch):
    monkeypatch.setenv("V2PLUS_TEST_SECRET_X", "shh")
    provider = EnvironmentCredentialProvider()
    assert provider.get_secret("env:V2PLUS_TEST_SECRET_X") == "shh"


def test_rejects_non_env_scheme():
    provider = EnvironmentCredentialProvider()
    with pytest.raises(CredentialResolutionError):
        provider.get_secret("keyvault:some-secret")


def test_rejects_disallowed_variable_name():
    provider = EnvironmentCredentialProvider()
    with pytest.raises(CredentialResolutionError):
        provider.get_secret("env:PATH")


def test_rejects_missing_env_var(monkeypatch):
    monkeypatch.delenv("V2PLUS_TEST_UNSET", raising=False)
    provider = EnvironmentCredentialProvider()
    with pytest.raises(CredentialResolutionError):
        provider.get_secret("env:V2PLUS_TEST_UNSET")


@pytest.mark.parametrize("credential_ref", ["env:V2PLUS_bad-name", "env:v2plus_lower", "env:V2PLUS-DASH"])
def test_rejects_invalid_variable_name_format(credential_ref):
    provider = EnvironmentCredentialProvider()
    with pytest.raises(CredentialResolutionError):
        provider.get_secret(credential_ref)


def _make_connection(fixture, *, secret: str | None = "byo-secret") -> TenantConnection:
    connection = TenantConnection(
        environment_id=fixture.environment.id,
        managed_tenant_id=fixture.tenant.id,
        auth_mode="byo_app",
        client_id="client-abc",
        status="pending",
        encrypted_client_secret=encrypt_secret(secret) if secret else None,
    )
    _db.session.add(connection)
    _db.session.commit()
    connection.credential_ref = f"db:{connection.id}"
    _db.session.commit()
    return connection


class TestDatabaseEncryptedCredentialProvider:
    def test_resolves_secret_for_valid_reference(self, app, two_environments, monkeypatch):
        monkeypatch.setenv("V2PLUS_ENCRYPTION_KEY", Fernet.generate_key().decode("utf-8"))
        env_a, _env_b = two_environments
        connection = _make_connection(env_a)

        provider = DatabaseEncryptedCredentialProvider()
        assert provider.get_secret(f"db:{connection.id}") == "byo-secret"

    def test_rejects_non_db_scheme(self):
        provider = DatabaseEncryptedCredentialProvider()
        with pytest.raises(CredentialResolutionError):
            provider.get_secret("env:V2PLUS_X")

    def test_rejects_malformed_id(self):
        provider = DatabaseEncryptedCredentialProvider()
        with pytest.raises(CredentialResolutionError):
            provider.get_secret("db:not-a-uuid")

    def test_rejects_unknown_connection(self, app):
        provider = DatabaseEncryptedCredentialProvider()
        with pytest.raises(CredentialResolutionError):
            provider.get_secret(f"db:{uuid.uuid4()}")

    def test_rejects_connection_without_secret(self, app, two_environments):
        env_a, _env_b = two_environments
        connection = _make_connection(env_a, secret=None)
        provider = DatabaseEncryptedCredentialProvider()
        with pytest.raises(CredentialResolutionError):
            provider.get_secret(f"db:{connection.id}")


class TestCompositeCredentialProvider:
    def test_dispatches_env_scheme(self, monkeypatch):
        monkeypatch.setenv("V2PLUS_TEST_SECRET_X", "shh")
        composite = CompositeCredentialProvider()
        assert composite.get_secret("env:V2PLUS_TEST_SECRET_X") == "shh"

    def test_dispatches_db_scheme(self, app, two_environments, monkeypatch):
        monkeypatch.setenv("V2PLUS_ENCRYPTION_KEY", Fernet.generate_key().decode("utf-8"))
        env_a, _env_b = two_environments
        connection = _make_connection(env_a)
        composite = CompositeCredentialProvider()
        assert composite.get_secret(f"db:{connection.id}") == "byo-secret"

    def test_rejects_unknown_scheme(self):
        composite = CompositeCredentialProvider()
        with pytest.raises(CredentialResolutionError):
            composite.get_secret("keyvault:something")
