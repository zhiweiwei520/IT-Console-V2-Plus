"""
MsalTokenBroker：token cache key 規約、cloud／resource allowlist、MSAL 錯誤映射。

對應 04-microsoft-connection-and-consent.md §6：cache key 含
credential_profile_id + credential_version + entra_tenant_id + authority_cloud +
resource_audience + normalized_scope_hash；credential_version 更新須使快取失效。
"""
from __future__ import annotations

from types import SimpleNamespace

import pytest

from app.microsoft.token_broker import MsalTokenBroker, TokenAcquisitionError


class FakeCredentialProvider:
    def __init__(self, secret: str = "super-secret") -> None:
        self.secret = secret
        self.requested_refs: list[str] = []

    def get_secret(self, credential_ref: str) -> str:
        self.requested_refs.append(credential_ref)
        return self.secret


class FakeMsalApp:
    """記錄建構參數；acquire_token_for_client 回傳可控結果。"""

    instances: list["FakeMsalApp"] = []

    def __init__(self, *, client_id, client_credential, authority, result=None):
        self.client_id = client_id
        self.client_credential = client_credential
        self.authority = authority
        self._result = result if result is not None else {"access_token": "tok-123"}
        self.acquire_calls: list[list[str]] = []
        FakeMsalApp.instances.append(self)

    def acquire_token_for_client(self, scopes):
        self.acquire_calls.append(list(scopes))
        return self._result


def _factory_returning(result):
    def factory(*, client_id, client_credential, authority):
        return FakeMsalApp(
            client_id=client_id, client_credential=client_credential, authority=authority, result=result,
        )
    return factory


def _tenant(**overrides):
    defaults = dict(cloud="public", entra_tenant_id="tenant-123")
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _connection(**overrides):
    defaults = dict(id="conn-1", client_id="client-abc", credential_ref="env:V2PLUS_SECRET", credential_version=1)
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


@pytest.fixture(autouse=True)
def _reset_fake_app_registry():
    FakeMsalApp.instances = []
    yield
    FakeMsalApp.instances = []


def test_acquire_token_returns_access_token_and_builds_correct_authority():
    provider = FakeCredentialProvider()
    broker = MsalTokenBroker(provider, application_factory=_factory_returning({"access_token": "tok-123"}))

    token = broker.acquire_token(_tenant(), _connection())

    assert token == "tok-123"
    assert len(FakeMsalApp.instances) == 1
    app = FakeMsalApp.instances[0]
    assert app.client_id == "client-abc"
    assert app.client_credential == "super-secret"
    assert app.authority == "https://login.microsoftonline.com/tenant-123"
    assert app.acquire_calls == [["https://graph.microsoft.com/.default"]]
    assert provider.requested_refs == ["env:V2PLUS_SECRET"]


def test_acquire_token_caches_application_for_same_key():
    provider = FakeCredentialProvider()
    broker = MsalTokenBroker(provider, application_factory=_factory_returning({"access_token": "tok-123"}))
    tenant, connection = _tenant(), _connection()

    broker.acquire_token(tenant, connection)
    broker.acquire_token(tenant, connection)

    assert len(FakeMsalApp.instances) == 1
    assert provider.requested_refs == ["env:V2PLUS_SECRET"]


def test_acquire_token_rebuilds_application_when_credential_version_bumps():
    provider = FakeCredentialProvider()
    broker = MsalTokenBroker(provider, application_factory=_factory_returning({"access_token": "tok-123"}))
    tenant = _tenant()

    broker.acquire_token(tenant, _connection(credential_version=1))
    broker.acquire_token(tenant, _connection(credential_version=2))

    assert len(FakeMsalApp.instances) == 2


def test_rejects_non_public_cloud():
    broker = MsalTokenBroker(FakeCredentialProvider(), application_factory=_factory_returning({}))
    with pytest.raises(TokenAcquisitionError) as exc_info:
        broker.acquire_token(_tenant(cloud="gcc"), _connection())
    assert exc_info.value.code == "cloud_or_resource_not_allowed"


def test_rejects_non_graph_resource():
    broker = MsalTokenBroker(FakeCredentialProvider(), application_factory=_factory_returning({}))
    with pytest.raises(TokenAcquisitionError) as exc_info:
        broker.acquire_token(_tenant(), _connection(), resource="https://not-graph.example.com")
    assert exc_info.value.code == "cloud_or_resource_not_allowed"


@pytest.mark.parametrize("field", ["client_id", "credential_ref"])
def test_rejects_incomplete_connection(field):
    broker = MsalTokenBroker(FakeCredentialProvider(), application_factory=_factory_returning({}))
    connection = _connection(**{field: None})
    with pytest.raises(TokenAcquisitionError) as exc_info:
        broker.acquire_token(_tenant(), connection)
    assert exc_info.value.code == "connection_credential_incomplete"


def test_maps_known_msal_error_code():
    broker = MsalTokenBroker(
        FakeCredentialProvider(), application_factory=_factory_returning({"error": "invalid_client"}),
    )
    with pytest.raises(TokenAcquisitionError) as exc_info:
        broker.acquire_token(_tenant(), _connection())
    assert exc_info.value.code == "invalid_client"


def test_maps_unknown_msal_error_code_to_generic_failure():
    broker = MsalTokenBroker(
        FakeCredentialProvider(), application_factory=_factory_returning({"error": "server_error"}),
    )
    with pytest.raises(TokenAcquisitionError) as exc_info:
        broker.acquire_token(_tenant(), _connection())
    assert exc_info.value.code == "token_acquisition_failed"


def test_missing_access_token_without_error_field_is_generic_failure():
    broker = MsalTokenBroker(FakeCredentialProvider(), application_factory=_factory_returning({}))
    with pytest.raises(TokenAcquisitionError) as exc_info:
        broker.acquire_token(_tenant(), _connection())
    assert exc_info.value.code == "token_acquisition_failed"


def test_authority_validation_failure_at_construction_is_wrapped():
    """實測踩坑：MSAL 建構 ConfidentialClientApplication 時會做 OIDC discovery 網路呼叫，
    tenant id 不存在／格式錯誤時丟原生 ValueError（不是 TokenAcquisitionError），若不接住
    會讓「測試連線」這種使用者觸發的動作變成 500。"""
    def _raising_factory(*, client_id, client_credential, authority):
        raise ValueError(f"Unable to get authority configuration for {authority}")

    broker = MsalTokenBroker(FakeCredentialProvider(), application_factory=_raising_factory)
    with pytest.raises(TokenAcquisitionError) as exc_info:
        broker.acquire_token(_tenant(), _connection())
    assert exc_info.value.code == "authority_validation_failed"


def test_authority_validation_failure_at_acquire_call_is_wrapped():
    class RaisingApp:
        def acquire_token_for_client(self, scopes):
            raise ValueError("boom")

    broker = MsalTokenBroker(
        FakeCredentialProvider(), application_factory=lambda **_kwargs: RaisingApp(),
    )
    with pytest.raises(TokenAcquisitionError) as exc_info:
        broker.acquire_token(_tenant(), _connection())
    assert exc_info.value.code == "authority_validation_failed"
