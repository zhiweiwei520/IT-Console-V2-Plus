import asyncio, uuid
from app.capabilities.app_audit.handler import AppAuditSyncHandler
from app.capabilities.app_audit.models import AppRegistration, EnterpriseApp
from app.extensions import db
from app.jobs.dispatcher import AppAuditSyncDispatcher
from app.jobs.models import DurableJob
from app.jobs.worker import WorkerRunner
from app.storage.tenant_context import TenantContext

class Graph:
    def __init__(self): self.calls=[]
    async def get(self, resource, *, params=None):
        self.calls.append(resource)
        if resource == "/applications": return {"value":[{"id":"a1","appId":"client-1","displayName":"Internal App","signInAudience":"AzureADMyOrg","passwordCredentials":[{"endDateTime":"2027-01-01T00:00:00Z"}],"keyCredentials":[]}]}
        return {"value":[{"id":"sp1","appId":"client-1","displayName":"Internal App SP","accountEnabled":True,"servicePrincipalType":"Application"}]}
def context(f): return TenantContext(principal_id=f.principal.id, environment_id=f.environment.id, membership_id=f.membership.id, allowed_managed_tenant_ids=None, active_managed_tenant_id=f.tenant.id, permission_codes=frozenset(f.membership.permission_codes), correlation_id="app-audit-test")
def login(client,f):
    client.post("/auth/login",data={"environment_slug":"","username":"user-a","password":"TestPass!12345"}); client.post(f"/environments/{f.environment.id}/switch"); client.post(f"/microsoft/managed-tenants/{f.tenant.id}/switch")
def test_worker_syncs_both_app_types(two_environments):
    f,_=two_environments; mid=AppAuditSyncDispatcher(db.session,context(f)).enqueue(f.tenant.id,operation_id=uuid.uuid4()); db.session.commit(); graph=Graph()
    runner=WorkerRunner(db.session,{"app_audit.sync":AppAuditSyncHandler(db.session,lambda _e,_t:graph)},worker_id="app-audit",lease_seconds=60)
    assert asyncio.run(runner.run_once(f.environment.id)); assert db.session.get(DurableJob,mid).status=="completed"
    assert AppRegistration.query.one().credential_count==1; assert EnterpriseApp.query.one().account_enabled; assert graph.calls==["/applications","/servicePrincipals"]
def test_web_requires_selected_tenant_and_ignores_forged_form(client,two_environments):
    f,other=two_environments; client.post("/auth/login",data={"environment_slug":"","username":"user-a","password":"TestPass!12345"}); client.post(f"/environments/{f.environment.id}/switch")
    assert "/microsoft/managed-tenants/" in client.get("/capabilities/app-audit/").headers["Location"]
    client.post(f"/microsoft/managed-tenants/{f.tenant.id}/switch"); assert client.get("/capabilities/app-audit/").status_code==200
    client.post("/capabilities/app-audit/sync",data={"managed_tenant_id":str(other.tenant.id)})
    assert DurableJob.query.filter_by(job_type="app_audit.sync",managed_tenant_id=f.tenant.id).count()==1
