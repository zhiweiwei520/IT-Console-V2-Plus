from app.capabilities.dashboard.service import DashboardService
from app.extensions import db
from app.storage.tenant_context import TenantContext
def _ctx(f,perms): return TenantContext(principal_id=f.principal.id,environment_id=f.environment.id,membership_id=f.membership.id,allowed_managed_tenant_ids=None,active_managed_tenant_id=f.tenant.id,permission_codes=frozenset(perms),correlation_id="dash-test")
def test_service_only_returns_permitted_kpis(two_environments):
    f,_=two_environments
    # 後端 gate：只回傳有權限的模組 KPI（Issue #5——無權限模組根本不查、不進 context）。
    assert {c["label"] for c in DashboardService(db.session,_ctx(f,{"accounts.view"})).kpis()}=={"帳號"}
    assert {c["label"] for c in DashboardService(db.session,_ctx(f,{"defender.view","sentinel.view"})).kpis()}=={"Defender 告警","資安事件"}
    # 全權限 → 十個模組全列，且每張卡有整數計數（無資料為 0，不缺卡）。
    full=DashboardService(db.session,_ctx(f,{"accounts.view","devices.view","signin_logs.view","licenses.view","app_audit.view","software.view","teams.view","sharepoint.view","defender.view","sentinel.view"})).kpis()
    assert len(full)==10; assert all(isinstance(c["value"],int) for c in full)
def test_web_dashboard_redirects_without_tenant_and_renders_with(client,two_environments):
    f,_=two_environments; client.post("/auth/login",data={"environment_slug":"","username":"user-a","password":"TestPass!12345"}); client.post(f"/environments/{f.environment.id}/switch")
    assert "/microsoft/managed-tenants/" in client.get("/dashboard/").headers["Location"]
    client.post(f"/microsoft/managed-tenants/{f.tenant.id}/switch"); resp=client.get("/dashboard/")
    assert resp.status_code==200; assert "總覽儀表板".encode() in resp.data; assert "資安事件".encode() in resp.data
