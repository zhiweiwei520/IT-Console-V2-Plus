import asyncio,json,uuid
from app.capabilities.sharepoint.handler import SharePointSyncHandler
from app.capabilities.sharepoint.models import SharePointSiteAudit
from app.extensions import db
from app.jobs.dispatcher import SharePointSyncDispatcher
from app.jobs.models import DurableJob
from app.jobs.worker import WorkerRunner
from app.storage.tenant_context import TenantContext
class Graph:
    async def get(self,r,*,params=None):
        values={"/sites":[{"id":"s1","displayName":"Marketing","webUrl":"https://contoso.sharepoint.com/sites/mkt","siteCollection":{"hostname":"contoso.sharepoint.com"}}],"/sites/s1/drives":{"value":[{"id":"d1","name":"Documents","driveType":"documentLibrary","quota":{"used":1024,"total":2048}}]}}
        value=values[r]; return {"value":value} if isinstance(value,list) else value
def context(f): return TenantContext(principal_id=f.principal.id,environment_id=f.environment.id,membership_id=f.membership.id,allowed_managed_tenant_ids=None,active_managed_tenant_id=f.tenant.id,permission_codes=frozenset(f.membership.permission_codes),correlation_id="sharepoint-test")
def test_worker_syncs_site_quick_cache_with_storage_and_not_collected(two_environments):
    f,_=two_environments; mid=SharePointSyncDispatcher(db.session,context(f)).enqueue(f.tenant.id,operation_id=uuid.uuid4()); db.session.commit(); runner=WorkerRunner(db.session,{"sharepoint.sync":SharePointSyncHandler(db.session,lambda _e,_t:Graph())},worker_id="sharepoint",lease_seconds=60)
    assert asyncio.run(runner.run_once(f.environment.id)); assert db.session.get(DurableJob,mid).status=="completed"
    row=SharePointSiteAudit.query.one(); assert (row.library_count,row.storage_used_bytes,row.storage_total_bytes)==(1,1024,2048); assert row.hostname=="contoso.sharepoint.com"; assert json.loads(row.sharing_json)["status"]=="not_collected"; assert json.loads(row.activity_json)["status"]=="not_collected"
def test_web_requires_tenant_and_ignores_forged_form(client,two_environments):
    f,other=two_environments; client.post("/auth/login",data={"environment_slug":"","username":"user-a","password":"TestPass!12345"}); client.post(f"/environments/{f.environment.id}/switch"); assert "/microsoft/managed-tenants/" in client.get("/capabilities/sharepoint/").headers["Location"]
    client.post(f"/microsoft/managed-tenants/{f.tenant.id}/switch"); assert client.get("/capabilities/sharepoint/").status_code==200; client.post("/capabilities/sharepoint/sync",data={"managed_tenant_id":str(other.tenant.id)}); assert DurableJob.query.filter_by(job_type="sharepoint.sync",managed_tenant_id=f.tenant.id).count()==1
