"""Control Plane service：CLI 與 web 路由共用的 Principal／Environment／Membership 邏輯。"""
from __future__ import annotations

import pytest

from app.control_plane.service import add_membership, create_environment, create_principal
from app.platform.models import (
    EnvironmentMembership,
    PlatformLocalLogin,
    PlatformRoleAssignment,
    RoleAssignment,
)


def test_create_principal_with_platform_login(app):
    with app.app_context():
        principal = create_principal(
            "Alice", platform_username="alice", platform_password="ChangeMe!12345",
        )
        login = PlatformLocalLogin.query.filter_by(principal_id=principal.id).one()
        assert login.normalized_username == "alice"


def test_create_principal_rejects_duplicate_username(app):
    with app.app_context():
        create_principal("Alice", platform_username="alice", platform_password="ChangeMe!12345")
        with pytest.raises(ValueError, match="已存在"):
            create_principal("Alice 2", platform_username="alice", platform_password="ChangeMe!12345")


def test_create_principal_rejects_weak_password(app):
    with app.app_context():
        with pytest.raises(ValueError, match="密碼不符合政策"):
            create_principal("Alice", platform_username="alice", platform_password="short")


def test_create_principal_grants_platform_operator(app):
    with app.app_context():
        principal = create_principal(
            "Ops", platform_username="ops", platform_password="ChangeMe!12345", platform_operator=True,
        )
        assignment = PlatformRoleAssignment.query.filter_by(principal_id=principal.id).one()
        assert assignment.role_code == "platform_operator"


def test_create_environment_builds_builtin_roles(app):
    with app.app_context():
        from app.platform.models import EnvironmentRole
        env = create_environment("acme", "Acme Corp")
        codes = {r.code for r in EnvironmentRole.query.filter_by(environment_id=env.id).all()}
        assert codes == {"environment_admin", "viewer"}


def test_create_environment_rejects_duplicate_slug(app):
    with app.app_context():
        create_environment("acme", "Acme Corp")
        with pytest.raises(ValueError, match="已存在"):
            create_environment("acme", "Acme Corp Again")


def test_add_membership_creates_role_assignment(app):
    with app.app_context():
        principal = create_principal("Alice", platform_username="alice", platform_password="ChangeMe!12345")
        env = create_environment("acme", "Acme Corp")

        membership = add_membership(env, principal, role_code="environment_admin", all_managed_tenants=True)

        assert membership.all_managed_tenants is True
        assert RoleAssignment.query.filter_by(membership_id=membership.id).count() == 1


def test_add_membership_rejects_unknown_role(app):
    with app.app_context():
        principal = create_principal("Alice", platform_username="alice", platform_password="ChangeMe!12345")
        env = create_environment("acme", "Acme Corp")
        with pytest.raises(ValueError, match="沒有角色"):
            add_membership(env, principal, role_code="nonexistent-role")


def test_add_membership_is_idempotent_and_bumps_version_on_resubmit(app):
    with app.app_context():
        principal = create_principal("Alice", platform_username="alice", platform_password="ChangeMe!12345")
        env = create_environment("acme", "Acme Corp")

        first = add_membership(env, principal, role_code="viewer")
        assert first.version == 1

        second = add_membership(env, principal, role_code="viewer")
        assert second.id == first.id
        assert second.version == 2
        assert EnvironmentMembership.query.filter_by(
            environment_id=env.id, principal_id=principal.id,
        ).count() == 1
        # 重複呼叫不應該疊出兩筆一樣的 role assignment
        assert RoleAssignment.query.filter_by(membership_id=first.id).count() == 1
