"""
Audit signing key 派生、anchor 檔案寫入／驗證，與「內部自洽但被整條重算」的竄改偵測。

對應 05-security-operations.md §5：hash chain 只保證內部自洽，anchor 是外部檢查點，
能抓到「攻擊者已能寫 DB、把整條 chain 重新算過」這種單靠 verify_audit_chain 測不出的攻擊。
"""
from __future__ import annotations

import uuid

import pytest

from app.extensions import db as _db
from app.platform.audit import record_audit, verify_audit_chain, verify_chain_against_anchor
from app.platform.audit_anchor import AnchorRecord, LocalFileAuditAnchorWriter
from app.platform.audit_signing import (
    AuditSigningKeyUnavailable,
    derive_environment_signing_key,
    sign_chain_head,
    verify_chain_head_signature,
)
from app.platform.models import EnvironmentAuditChainHead, EnvironmentAuditLog


@pytest.fixture(autouse=True)
def _master_key(monkeypatch):
    monkeypatch.setenv("V2PLUS_AUDIT_MASTER_KEY", "test-master-key-do-not-use-in-prod")


def test_key_derivation_is_deterministic_and_per_environment():
    env_a = uuid.uuid4()
    env_b = uuid.uuid4()

    assert derive_environment_signing_key(env_a) == derive_environment_signing_key(env_a)
    assert derive_environment_signing_key(env_a) != derive_environment_signing_key(env_b)


def test_missing_master_key_fails_loud(monkeypatch):
    monkeypatch.delenv("V2PLUS_AUDIT_MASTER_KEY", raising=False)
    with pytest.raises(AuditSigningKeyUnavailable):
        derive_environment_signing_key(uuid.uuid4())


def test_sign_and_verify_roundtrip():
    env_id = uuid.uuid4()
    signature = sign_chain_head(env_id, chain_sequence=3, chain_hash="abc123")
    assert verify_chain_head_signature(env_id, chain_sequence=3, chain_hash="abc123", signature=signature)


def test_verify_rejects_tampered_hash():
    env_id = uuid.uuid4()
    signature = sign_chain_head(env_id, chain_sequence=3, chain_hash="abc123")
    assert not verify_chain_head_signature(env_id, chain_sequence=3, chain_hash="tampered", signature=signature)


def test_verify_rejects_tampered_signature():
    env_id = uuid.uuid4()
    signature = sign_chain_head(env_id, chain_sequence=3, chain_hash="abc123")
    flipped = ("0" if signature[0] != "0" else "1") + signature[1:]
    assert not verify_chain_head_signature(env_id, chain_sequence=3, chain_hash="abc123", signature=flipped)


def test_writer_appends_and_reads_back(tmp_path):
    writer = LocalFileAuditAnchorWriter(tmp_path)
    env_id = uuid.uuid4()

    first = writer.write(environment_id=env_id, environment_slug="acme", chain_sequence=1, chain_hash="hash-1")
    second = writer.write(environment_id=env_id, environment_slug="acme", chain_sequence=2, chain_hash="hash-2")

    records = writer.read_all("acme")
    assert records == [first, second]
    assert writer.latest("acme") == second
    assert all(r.signature_valid() for r in records)


def test_latest_returns_none_when_no_anchor_written(tmp_path):
    writer = LocalFileAuditAnchorWriter(tmp_path)
    assert writer.latest("never-anchored") is None


def _write_entries(fixture, count: int) -> None:
    for i in range(count):
        record_audit(
            environment_id=fixture.environment.id, actor_principal_id=fixture.principal.id,
            action=f"test.action.{i}",
        )
    _db.session.commit()


def test_verify_chain_against_anchor_passes_when_untampered(two_environments, tmp_path):
    env_a, _env_b = two_environments
    _write_entries(env_a, 3)
    head = _db.session.get(EnvironmentAuditChainHead, env_a.environment.id)

    writer = LocalFileAuditAnchorWriter(tmp_path)
    anchor = writer.write(
        environment_id=env_a.environment.id, environment_slug=env_a.environment.slug,
        chain_sequence=head.last_sequence, chain_hash=head.last_hash,
    )

    result = verify_chain_against_anchor(env_a.environment.id, anchor)
    assert result.valid


def test_verify_chain_against_anchor_detects_full_chain_rewrite(two_environments, tmp_path):
    """模擬攻擊者：改掉一筆歷史 entry 的內容，並把後面所有 hash 重新算到自洽為止。
    verify_audit_chain（純內部自洽）會被騙過；verify_chain_against_anchor 靠 anchor 抓到。"""
    env_a, _env_b = two_environments
    _write_entries(env_a, 3)
    head = _db.session.get(EnvironmentAuditChainHead, env_a.environment.id)
    writer = LocalFileAuditAnchorWriter(tmp_path)
    anchor = writer.write(
        environment_id=env_a.environment.id, environment_slug=env_a.environment.slug,
        chain_sequence=head.last_sequence, chain_hash=head.last_hash,
    )

    # 攻擊者事後改了第一筆的 reason，並手動重算全部後續 hash，讓鏈保持內部自洽。
    # 用 Core-level update()（不碰 ORM instance 屬性、不觸發 autoflush／before_update guard，
    # 模擬直接改 DB 的攻擊者；若走 ORM instance mutation + commit，append-only guard 會先
    # 擋下來，測不到這個情境）。
    from types import SimpleNamespace
    from sqlalchemy import update as sa_update
    from app.platform.audit import GENESIS_HASH, compute_entry_hash

    entries = (
        EnvironmentAuditLog.query
        .filter_by(environment_id=env_a.environment.id)
        .order_by(EnvironmentAuditLog.chain_sequence)
        .all()
    )
    previous_hash = GENESIS_HASH
    for index, entry in enumerate(entries):
        reason = "attacker was here" if index == 0 else entry.reason
        shadow = SimpleNamespace(
            action=entry.action, actor_principal_id=entry.actor_principal_id,
            chain_sequence=entry.chain_sequence, correlation_id=entry.correlation_id,
            created_at=entry.created_at, id=entry.id, environment_id=entry.environment_id,
            hash_version=entry.hash_version, outcome=entry.outcome, previous_hash=previous_hash,
            reason=reason, target_id=entry.target_id, target_type=entry.target_type,
        )
        new_hash = compute_entry_hash(shadow)
        _db.session.execute(
            sa_update(EnvironmentAuditLog)
            .where(EnvironmentAuditLog.id == entry.id)
            .values(reason=reason, previous_hash=previous_hash, entry_hash=new_hash)
        )
        previous_hash = new_hash
    head.last_hash = previous_hash
    _db.session.commit()

    # 內部自洽性驗證會被騙過（鏈仍然自洽）。
    from app.platform.audit import verify_audit_chain
    assert verify_audit_chain(env_a.environment.id).valid

    # anchor 比對抓得到：anchor 記下的 hash 已經對不上現在這筆 entry 的內容。
    result = verify_chain_against_anchor(env_a.environment.id, anchor)
    assert not result.valid
    assert "rewritten" in result.error


def test_verify_chain_against_anchor_detects_rewind(two_environments, tmp_path):
    env_a, _env_b = two_environments
    _write_entries(env_a, 3)
    head = _db.session.get(EnvironmentAuditChainHead, env_a.environment.id)
    writer = LocalFileAuditAnchorWriter(tmp_path)
    anchor = writer.write(
        environment_id=env_a.environment.id, environment_slug=env_a.environment.slug,
        chain_sequence=head.last_sequence, chain_hash=head.last_hash,
    )

    # 模擬 audit rows 被刪除（rewind）：直接用 raw delete 繞過 append-only event guard，
    # 並把 head 一併「修好」成內部自洽（否則 verify_audit_chain 自己就會先抓到 head
    # mismatch，測不到本測試真正要驗證的「比 anchor 記錄的還短」這條路徑）。
    from sqlalchemy import delete
    remaining = (
        EnvironmentAuditLog.query
        .filter_by(environment_id=env_a.environment.id, chain_sequence=2)
        .one()
    )
    _db.session.execute(
        delete(EnvironmentAuditLog).where(
            EnvironmentAuditLog.environment_id == env_a.environment.id,
            EnvironmentAuditLog.chain_sequence == 3,
        )
    )
    head.last_sequence = 2
    head.last_hash = remaining.entry_hash
    _db.session.commit()

    assert verify_audit_chain(env_a.environment.id).valid  # 內部自洽性本身沒問題

    result = verify_chain_against_anchor(env_a.environment.id, anchor)
    assert not result.valid
    assert "fewer entries" in result.error


def test_verify_chain_against_anchor_detects_forged_anchor_signature(two_environments, tmp_path):
    env_a, _env_b = two_environments
    _write_entries(env_a, 1)
    head = _db.session.get(EnvironmentAuditChainHead, env_a.environment.id)

    forged = AnchorRecord(
        environment_id=str(env_a.environment.id),
        environment_slug=env_a.environment.slug,
        chain_sequence=head.last_sequence,
        chain_hash=head.last_hash,
        signature="0" * 64,  # 假簽章
        written_at="2026-01-01T00:00:00",
    )

    result = verify_chain_against_anchor(env_a.environment.id, forged)
    assert not result.valid
    assert "signature" in result.error
