"""
Repository 層隔離測試（defense-in-depth 第一層，SQLite 無 RLS 時的唯一防線）。
對應 07-testing-acceptance.md §3 必測隔離案例（子集，SQLite 可驗證的部分）。
"""
from __future__ import annotations

import uuid

from app.capabilities.accounts.repository import AccountRepository
from app.capabilities.accounts.service import seed_demo_accounts
from app.extensions import db as _db
from app.storage.tenant_context import TenantContext


def _context_for(fixture, *, correlation_id="test") -> TenantContext:
    return TenantContext(
        principal_id=fixture.principal.id,
        environment_id=fixture.environment.id,
        membership_id=fixture.membership.id,
        allowed_managed_tenant_ids=None,  # all_managed_tenants=True in fixture
        active_managed_tenant_id=fixture.tenant.id,
        permission_codes=frozenset({"accounts.view"}),
        correlation_id=correlation_id,
    )


def test_account_repository_only_sees_own_environment(two_environments):
    env_a, env_b = two_environments
    seed_demo_accounts(_db.session, environment_id=env_a.environment.id, managed_tenant_id=env_a.tenant.id, count=2)
    seed_demo_accounts(_db.session, environment_id=env_b.environment.id, managed_tenant_id=env_b.tenant.id, count=3)
    _db.session.commit()

    repo_a = AccountRepository(_db.session, _context_for(env_a))
    accounts_a = repo_a.list_accounts()
    assert len(accounts_a) == 2
    assert all(a.environment_id == env_a.environment.id for a in accounts_a)

    repo_b = AccountRepository(_db.session, _context_for(env_b))
    accounts_b = repo_b.list_accounts()
    assert len(accounts_b) == 3
    assert all(a.environment_id == env_b.environment.id for a in accounts_b)


def test_get_authorized_returns_none_for_foreign_environment_id(two_environments):
    env_a, env_b = two_environments
    [account_b] = seed_demo_accounts(
        _db.session, environment_id=env_b.environment.id, managed_tenant_id=env_b.tenant.id, count=1,
    )
    _db.session.commit()

    repo_a = AccountRepository(_db.session, _context_for(env_a))
    # A 明確提交 B 的 record id，仍必須查不到（不是 403，是「查不到」＝ 404 語意）。
    assert repo_a.get_authorized(account_b.id) is None


def test_get_authorized_returns_none_for_random_uuid(two_environments):
    env_a, _env_b = two_environments
    repo_a = AccountRepository(_db.session, _context_for(env_a))
    assert repo_a.get_authorized(uuid.uuid4()) is None


def test_explicit_tenant_grant_narrows_visible_accounts(two_environments):
    env_a, _env_b = two_environments
    from app.microsoft.models import ManagedTenant

    other_tenant = ManagedTenant(
        environment_id=env_a.environment.id, entra_tenant_id=str(uuid.uuid4()),
        display_name="second-tenant-in-env-a", status="active",
    )
    _db.session.add(other_tenant)
    _db.session.commit()

    seed_demo_accounts(_db.session, environment_id=env_a.environment.id, managed_tenant_id=env_a.tenant.id, count=2)
    seed_demo_accounts(_db.session, environment_id=env_a.environment.id, managed_tenant_id=other_tenant.id, count=5)
    _db.session.commit()

    # 同一 Environment，但 membership 只 grant 第一個 tenant（模擬非 all_managed_tenants 授權）。
    scoped_context = TenantContext(
        principal_id=env_a.principal.id,
        environment_id=env_a.environment.id,
        membership_id=env_a.membership.id,
        allowed_managed_tenant_ids=frozenset({env_a.tenant.id}),
        active_managed_tenant_id=env_a.tenant.id,
        permission_codes=frozenset({"accounts.view"}),
        correlation_id="scoped",
    )
    repo = AccountRepository(_db.session, scoped_context)
    accounts = repo.list_accounts()
    assert len(accounts) == 2
    assert all(a.managed_tenant_id == env_a.tenant.id for a in accounts)


def test_active_managed_tenant_outside_grant_raises(two_environments):
    env_a, _env_b = two_environments
    other_tenant_id = uuid.uuid4()
    scoped_context = TenantContext(
        principal_id=env_a.principal.id,
        environment_id=env_a.environment.id,
        membership_id=env_a.membership.id,
        allowed_managed_tenant_ids=frozenset({env_a.tenant.id}),
        active_managed_tenant_id=other_tenant_id,
        permission_codes=frozenset({"accounts.view"}),
        correlation_id="scoped",
    )
    repo = AccountRepository(_db.session, scoped_context)
    try:
        repo.list_accounts()
        assert False, "should have raised PermissionError"
    except PermissionError:
        pass
