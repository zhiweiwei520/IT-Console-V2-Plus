"""Managed Tenant web 路由：權限守門、BYO app 建立表單、測試連線流程。"""
from __future__ import annotations

from cryptography.fernet import Fernet

from app.extensions import db as _db
from app.microsoft.models import ManagedTenant, TenantConnection
from app.platform.models import EnvironmentRole, RoleAssignment

VALID_TENANT_ID = "11111111-1111-1111-1111-111111111111"


def _login_env_a(client):
    client.post("/auth/login", data={
        "environment_slug": "", "username": "user-a", "password": "TestPass!12345",
    })


def _login_and_switch(client, environment_id, *, username="user-a"):
    client.post("/auth/login", data={
        "environment_slug": "", "username": username, "password": "TestPass!12345",
    })
    client.post(f"/environments/{environment_id}/switch")


def test_requires_login(client):
    resp = client.get("/microsoft/managed-tenants/")
    assert resp.status_code in (302, 401)


def test_requires_active_environment(client, two_environments):
    _login_env_a(client)  # 登入但沒切換環境
    resp = client.get("/microsoft/managed-tenants/", follow_redirects=False)
    assert resp.status_code == 302
    assert "/environments/" in resp.headers["Location"]


def test_viewer_can_select_tenant_but_cannot_manage_connections(app, client, two_environments):
    env_a, _env_b = two_environments
    with app.app_context():
        viewer_role = EnvironmentRole.query.filter_by(
            environment_id=env_a.environment.id, code="viewer",
        ).one()
        RoleAssignment.query.filter_by(membership_id=env_a.membership.id).delete()
        from app.storage.time_utils import utc_now_naive
        _db.session.add(RoleAssignment(
            environment_id=env_a.environment.id, membership_id=env_a.membership.id,
            role_id=viewer_role.id, granted_at=utc_now_naive(),
        ))
        _db.session.commit()

    _login_and_switch(client, env_a.environment.id)
    resp = client.get("/microsoft/managed-tenants/")
    body = resp.get_data(as_text=True)
    assert resp.status_code == 200
    assert "進入管理" in body
    assert "新增 Tenant" not in body
    assert "測試連線" not in body


def test_environment_admin_can_create_byo_tenant(app, client, two_environments, monkeypatch):
    monkeypatch.setenv("V2PLUS_ENCRYPTION_KEY", Fernet.generate_key().decode("utf-8"))
    env_a, _env_b = two_environments
    _login_and_switch(client, env_a.environment.id)

    resp = client.post("/microsoft/managed-tenants/new", data={
        "entra_tenant_id": VALID_TENANT_ID,
        "display_name": "Acme Corp",
        "domain": "acme.onmicrosoft.com",
        "client_id": "client-123",
        "client_secret": "super-secret-value",
    }, follow_redirects=False)
    assert resp.status_code == 302

    with app.app_context():
        tenant = ManagedTenant.query.filter_by(
            environment_id=env_a.environment.id, entra_tenant_id=VALID_TENANT_ID,
        ).one()
        assert tenant.status == "pending"
        connection = TenantConnection.query.filter_by(managed_tenant_id=tenant.id).one()
        assert connection.encrypted_client_secret is not None
        assert "super-secret-value" not in (connection.encrypted_client_secret or "")

    list_page = client.get("/microsoft/managed-tenants/")
    assert b"Acme Corp" in list_page.data


def test_create_rejects_duplicate_tenant_without_500(app, client, two_environments, monkeypatch):
    monkeypatch.setenv("V2PLUS_ENCRYPTION_KEY", Fernet.generate_key().decode("utf-8"))
    env_a, _env_b = two_environments
    _login_and_switch(client, env_a.environment.id)
    payload = {
        "entra_tenant_id": VALID_TENANT_ID, "display_name": "Acme", "domain": "",
        "client_id": "client-1", "client_secret": "secret",
    }
    client.post("/microsoft/managed-tenants/new", data=payload)
    resp = client.post("/microsoft/managed-tenants/new", data=payload)
    assert resp.status_code == 200


def test_test_connection_success_activates_tenant(app, client, two_environments, monkeypatch):
    monkeypatch.setenv("V2PLUS_ENCRYPTION_KEY", Fernet.generate_key().decode("utf-8"))
    env_a, _env_b = two_environments
    _login_and_switch(client, env_a.environment.id)
    client.post("/microsoft/managed-tenants/new", data={
        "entra_tenant_id": VALID_TENANT_ID, "display_name": "Acme", "domain": "",
        "client_id": "client-1", "client_secret": "secret",
    })

    class FakeClient:
        async def get(self, resource, params=None):
            return {"value": [{"id": VALID_TENANT_ID, "displayName": "Acme Corp Verified"}]}

    monkeypatch.setattr(
        "app.microsoft.onboarding_service.default_graph_client_factory",
        lambda env_id, tenant_id, include_pending=False: FakeClient(),
    )

    with app.app_context():
        tenant = ManagedTenant.query.filter_by(
            environment_id=env_a.environment.id, entra_tenant_id=VALID_TENANT_ID,
        ).one()
        tenant_id = str(tenant.id)

    resp = client.post(f"/microsoft/managed-tenants/{tenant_id}/test-connection", follow_redirects=False)
    assert resp.status_code == 302

    with app.app_context():
        tenant = _db.session.get(ManagedTenant, tenant_id)
        assert tenant.status == "active"
        assert tenant.display_name == "Acme Corp Verified"
        connection = TenantConnection.query.filter_by(managed_tenant_id=tenant.id).one()
        assert connection.status == "active"


def test_test_connection_failure_keeps_tenant_pending(app, client, two_environments, monkeypatch):
    monkeypatch.setenv("V2PLUS_ENCRYPTION_KEY", Fernet.generate_key().decode("utf-8"))
    env_a, _env_b = two_environments
    _login_and_switch(client, env_a.environment.id)
    client.post("/microsoft/managed-tenants/new", data={
        "entra_tenant_id": VALID_TENANT_ID, "display_name": "Acme", "domain": "",
        "client_id": "client-1", "client_secret": "secret",
    })

    from app.microsoft.token_broker import TokenAcquisitionError

    class FailingClient:
        async def get(self, resource, params=None):
            raise TokenAcquisitionError("invalid_client")

    monkeypatch.setattr(
        "app.microsoft.onboarding_service.default_graph_client_factory",
        lambda env_id, tenant_id, include_pending=False: FailingClient(),
    )

    with app.app_context():
        tenant = ManagedTenant.query.filter_by(
            environment_id=env_a.environment.id, entra_tenant_id=VALID_TENANT_ID,
        ).one()
        tenant_id = str(tenant.id)

    client.post(f"/microsoft/managed-tenants/{tenant_id}/test-connection")

    with app.app_context():
        tenant = _db.session.get(ManagedTenant, tenant_id)
        assert tenant.status == "pending"


def test_cross_environment_test_connection_returns_404(app, client, two_environments, monkeypatch):
    """A 不能對 B 的 Managed Tenant 觸發測試連線（即使猜得到 UUID）。"""
    monkeypatch.setenv("V2PLUS_ENCRYPTION_KEY", Fernet.generate_key().decode("utf-8"))
    env_a, env_b = two_environments

    _login_and_switch(client, env_b.environment.id, username="user-b")
    client.post("/microsoft/managed-tenants/new", data={
        "entra_tenant_id": VALID_TENANT_ID, "display_name": "B's Tenant", "domain": "",
        "client_id": "client-1", "client_secret": "secret",
    })
    with app.app_context():
        tenant = ManagedTenant.query.filter_by(
            environment_id=env_b.environment.id, entra_tenant_id=VALID_TENANT_ID,
        ).one()
        tenant_id = str(tenant.id)
    client.post("/auth/logout")

    _login_and_switch(client, env_a.environment.id)
    resp = client.post(f"/microsoft/managed-tenants/{tenant_id}/test-connection")
    assert resp.status_code == 404


def test_switch_tenant_sets_single_session_scope(client, two_environments):
    env_a, _env_b = two_environments
    _login_and_switch(client, env_a.environment.id)

    resp = client.post(
        f"/microsoft/managed-tenants/{env_a.tenant.id}/switch",
        follow_redirects=False,
    )
    assert resp.status_code == 302
    assert "/capabilities/accounts/" in resp.headers["Location"]
    with client.session_transaction() as session:
        assert session["active_managed_tenant_id"] == str(env_a.tenant.id)


def test_cannot_switch_to_foreign_environment_tenant(client, two_environments):
    env_a, env_b = two_environments
    _login_and_switch(client, env_a.environment.id)
    resp = client.post(f"/microsoft/managed-tenants/{env_b.tenant.id}/switch")
    assert resp.status_code == 404
    with client.session_transaction() as session:
        assert "active_managed_tenant_id" not in session
