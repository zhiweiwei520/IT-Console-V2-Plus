"""平台管理者 Web UI：權限守門 + 開設 Principal／Environment／Membership。"""
from __future__ import annotations

from app.control_plane.service import create_principal
from app.extensions import db as _db
from app.platform.models import EnvironmentMembership, ManagementEnvironment, Principal


def _login_platform_operator(client, app, *, username="ops"):
    with app.app_context():
        create_principal(
            "Platform Ops", platform_username=username, platform_password="ChangeMe!12345",
            platform_operator=True,
        )
    client.post("/auth/login", data={"environment_slug": "", "username": username, "password": "ChangeMe!12345"})


def _login_regular_user(two_environments, client):
    env_a, _env_b = two_environments
    client.post("/auth/login", data={
        "environment_slug": "", "username": "user-a", "password": "TestPass!12345",
    })


def test_non_platform_operator_gets_403(two_environments, client):
    _login_regular_user(two_environments, client)
    resp = client.get("/platform/environments")
    assert resp.status_code == 403


def test_unauthenticated_is_redirected_to_login(client):
    resp = client.get("/platform/environments")
    assert resp.status_code in (302, 401)


def test_platform_operator_can_view_dashboard(app, client):
    _login_platform_operator(client, app)
    resp = client.get("/platform/environments")
    assert resp.status_code == 200


def test_platform_operator_can_create_principal(app, client):
    _login_platform_operator(client, app)
    resp = client.post("/platform/principals/new", data={
        "display_name": "Alice", "platform_username": "alice", "platform_password": "ChangeMe!12345",
    }, follow_redirects=False)
    assert resp.status_code == 302

    with app.app_context():
        assert Principal.query.filter_by(display_name="Alice").count() == 1


def test_platform_operator_can_create_environment(app, client):
    _login_platform_operator(client, app)
    resp = client.post("/platform/environments/new", data={
        "slug": "acme", "name": "Acme Corp",
    }, follow_redirects=False)
    assert resp.status_code == 302

    with app.app_context():
        env = ManagementEnvironment.query.filter_by(slug="acme").one()
        assert env.name == "Acme Corp"


def test_create_environment_rejects_duplicate_slug_with_flash_not_500(app, client):
    _login_platform_operator(client, app)
    client.post("/platform/environments/new", data={"slug": "acme", "name": "Acme Corp"})
    resp = client.post("/platform/environments/new", data={"slug": "acme", "name": "Acme Corp Again"})
    assert resp.status_code == 200  # 留在表單頁，不是 500


def test_platform_operator_can_add_membership(app, client):
    _login_platform_operator(client, app)
    client.post("/platform/principals/new", data={
        "display_name": "Bob", "platform_username": "bob", "platform_password": "ChangeMe!12345",
    })
    client.post("/platform/environments/new", data={"slug": "widgets", "name": "Widgets Inc"})

    with app.app_context():
        principal = Principal.query.filter_by(display_name="Bob").one()
        env = ManagementEnvironment.query.filter_by(slug="widgets").one()
        principal_id, env_id = str(principal.id), str(env.id)

    resp = client.post(f"/platform/environments/{env_id}/memberships", data={
        "principal_id": principal_id, "role_code": "environment_admin", "all_managed_tenants": "y",
    }, follow_redirects=False)
    assert resp.status_code == 302

    with app.app_context():
        membership = EnvironmentMembership.query.filter_by(
            environment_id=env_id, principal_id=principal_id,
        ).one()
        assert membership.all_managed_tenants is True

    # 新使用者現在應該能用 bob 登入並看到 widgets 環境（跨模組驗收：平台開設的成員資格對登入生效）。
    client.post("/auth/logout")
    login_resp = client.post("/auth/login", data={
        "environment_slug": "", "username": "bob", "password": "ChangeMe!12345",
    })
    assert login_resp.status_code == 302
    env_list = client.get("/environments/")
    assert b"widgets" in env_list.data
