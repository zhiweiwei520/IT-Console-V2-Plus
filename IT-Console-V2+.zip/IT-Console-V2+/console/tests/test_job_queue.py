"""PgJobQueue：冪等、lease recovery、DLQ 與 Environment 隔離。"""
from __future__ import annotations

from datetime import datetime, timedelta

import pytest

from app.extensions import db as _db
from app.jobs.models import DurableJob, JobDeadLetter
from app.jobs.queue import (
    IdempotencyConflict,
    InvalidJobState,
    JobNotFound,
    PgJobQueue,
)


class FakeClock:
    def __init__(self):
        self.now = datetime(2026, 7, 11, 8, 0, 0)

    def __call__(self):
        return self.now

    def advance(self, seconds: int):
        self.now += timedelta(seconds=seconds)


def _queue(fixture, clock):
    return PgJobQueue(_db.session, fixture.environment.id, clock=clock)


def test_enqueue_is_idempotent_and_conflicting_reuse_fails(two_environments):
    env_a, _env_b = two_environments
    clock = FakeClock()
    queue = _queue(env_a, clock)
    kwargs = {
        "idempotency_key": "schedule:1:tenant:1:20260711T0800:v1",
        "managed_tenant_id": env_a.tenant.id,
    }

    first = queue.enqueue("accounts.sync", {"mode": "delta"}, **kwargs)
    second = queue.enqueue("accounts.sync", {"mode": "delta"}, **kwargs)
    assert second == first
    assert DurableJob.query.count() == 1

    with pytest.raises(IdempotencyConflict):
        queue.enqueue("accounts.sync", {"mode": "full"}, **kwargs)


def test_enqueue_rejects_foreign_tenant_and_sensitive_payload(two_environments):
    env_a, env_b = two_environments
    queue = _queue(env_a, FakeClock())
    with pytest.raises(ValueError, match="does not belong"):
        queue.enqueue(
            "accounts.sync", {}, idempotency_key="foreign",
            managed_tenant_id=env_b.tenant.id,
        )
    with pytest.raises(ValueError, match="forbidden field"):
        queue.enqueue(
            "accounts.sync", {"connection": {"access_token": "must-not-enter-queue"}},
            idempotency_key="secret",
        )


def test_claim_heartbeat_and_complete(two_environments):
    env_a, _env_b = two_environments
    clock = FakeClock()
    queue = _queue(env_a, clock)
    message_id = queue.enqueue(
        "accounts.sync", {"mode": "delta"}, idempotency_key="manual:operation-1",
        managed_tenant_id=env_a.tenant.id, trace_id="trace-1",
    )

    envelope = queue.claim(job_types=["accounts.sync"], worker_id="worker-1", lease_seconds=30)
    assert envelope is not None
    assert envelope["message_id"] == message_id
    assert envelope["environment_id"] == str(env_a.environment.id)
    assert envelope["managed_tenant_id"] == str(env_a.tenant.id)
    assert envelope["attempt"] == 1

    clock.advance(10)
    queue.heartbeat(message_id, worker_id="worker-1", lease_seconds=60)
    clock.advance(40)
    queue.complete(message_id, worker_id="worker-1")
    _db.session.commit()

    job = _db.session.get(DurableJob, message_id)
    assert job.status == "completed"
    assert job.completed_at == clock.now


def test_expired_lease_is_reclaimed_and_stale_worker_cannot_complete(two_environments):
    env_a, _env_b = two_environments
    clock = FakeClock()
    queue = _queue(env_a, clock)
    message_id = queue.enqueue("accounts.sync", {}, idempotency_key="lease-recovery")
    queue.claim(job_types=["accounts.sync"], worker_id="worker-old", lease_seconds=10)
    _db.session.commit()

    clock.advance(11)
    recovered = queue.claim(job_types=["accounts.sync"], worker_id="worker-new", lease_seconds=30)
    assert recovered["message_id"] == message_id
    assert recovered["attempt"] == 2
    with pytest.raises(InvalidJobState):
        queue.complete(message_id, worker_id="worker-old")


def test_abandon_retries_then_moves_to_dlq(two_environments):
    env_a, _env_b = two_environments
    clock = FakeClock()
    queue = _queue(env_a, clock)
    message_id = queue.enqueue(
        "accounts.sync", {}, idempotency_key="retry-to-dlq", max_attempts=2,
    )
    queue.claim(job_types=["accounts.sync"], worker_id="worker", lease_seconds=30)
    queue.abandon(message_id, worker_id="worker", reason="429", delay_seconds=5)
    assert queue.claim(job_types=["accounts.sync"], worker_id="worker", lease_seconds=30) is None

    clock.advance(5)
    queue.claim(job_types=["accounts.sync"], worker_id="worker", lease_seconds=30)
    queue.abandon(message_id, worker_id="worker", reason="429 again")
    _db.session.commit()

    job = _db.session.get(DurableJob, message_id)
    assert job.status == "dead_letter"
    dead_letter = JobDeadLetter.query.one()
    assert dead_letter.job_id == job.id
    assert dead_letter.attempts == 2


def test_queue_operations_cannot_cross_environment(two_environments):
    env_a, env_b = two_environments
    clock = FakeClock()
    queue_a = _queue(env_a, clock)
    queue_b = _queue(env_b, clock)
    message_id = queue_b.enqueue("accounts.sync", {}, idempotency_key="env-b-only")

    assert queue_a.claim(
        job_types=["accounts.sync"], worker_id="worker-a", lease_seconds=30,
    ) is None
    queue_b.claim(job_types=["accounts.sync"], worker_id="worker-b", lease_seconds=30)
    with pytest.raises(JobNotFound):
        queue_a.complete(message_id, worker_id="worker-b")
