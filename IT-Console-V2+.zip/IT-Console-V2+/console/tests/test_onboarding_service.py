"""Managed Tenant BYO app 自助連接：建立驗證、測試連線、狀態轉換。"""
from __future__ import annotations

import asyncio
import uuid

import pytest

from app.extensions import db as _db
from app.microsoft.models import ManagedTenant, TenantConnection
from app.microsoft.onboarding_service import (
    ConnectionTestResult,
    apply_connection_test_result,
    create_byo_managed_tenant,
)
# 別名匯入：函式名稱以 test_ 開頭會被 pytest 誤判成測試函式本身去收集（見下方呼叫處一律用別名）。
from app.microsoft.onboarding_service import test_tenant_connection as check_tenant_connection

VALID_TENANT_ID = "11111111-1111-1111-1111-111111111111"


class TestCreateByoManagedTenant:
    def test_creates_tenant_and_encrypted_connection(self, app, two_environments, monkeypatch):
        from cryptography.fernet import Fernet
        monkeypatch.setenv("V2PLUS_ENCRYPTION_KEY", Fernet.generate_key().decode("utf-8"))
        env_a, _env_b = two_environments

        tenant = create_byo_managed_tenant(
            env_a.environment.id, entra_tenant_id=VALID_TENANT_ID, display_name="Acme",
            domain="acme.onmicrosoft.com", client_id="client-1", client_secret="super-secret",
        )

        assert tenant.status == "pending"
        connection = TenantConnection.query.filter_by(managed_tenant_id=tenant.id).one()
        assert connection.status == "pending"
        assert connection.auth_mode == "byo_app"
        assert connection.credential_ref == f"db:{connection.id}"
        assert connection.encrypted_client_secret != "super-secret"

    def test_rejects_invalid_tenant_id(self, app, two_environments):
        env_a, _env_b = two_environments
        with pytest.raises(ValueError, match="GUID"):
            create_byo_managed_tenant(
                env_a.environment.id, entra_tenant_id="not-a-guid", display_name="Acme",
                domain=None, client_id="client-1", client_secret="secret",
            )

    def test_rejects_missing_client_credentials(self, app, two_environments):
        env_a, _env_b = two_environments
        with pytest.raises(ValueError, match="client_id"):
            create_byo_managed_tenant(
                env_a.environment.id, entra_tenant_id=VALID_TENANT_ID, display_name="Acme",
                domain=None, client_id="", client_secret="",
            )

    def test_rejects_duplicate_tenant_in_same_environment(self, app, two_environments, monkeypatch):
        from cryptography.fernet import Fernet
        monkeypatch.setenv("V2PLUS_ENCRYPTION_KEY", Fernet.generate_key().decode("utf-8"))
        env_a, _env_b = two_environments
        create_byo_managed_tenant(
            env_a.environment.id, entra_tenant_id=VALID_TENANT_ID, display_name="Acme",
            domain=None, client_id="client-1", client_secret="secret",
        )
        with pytest.raises(ValueError, match="已存在"):
            create_byo_managed_tenant(
                env_a.environment.id, entra_tenant_id=VALID_TENANT_ID, display_name="Acme Again",
                domain=None, client_id="client-2", client_secret="secret2",
            )


class TestTestTenantConnection:
    def test_success_returns_remote_org_info(self, monkeypatch):
        class FakeClient:
            async def get(self, resource, params=None):
                assert resource == "/organization"
                return {"value": [{"id": VALID_TENANT_ID, "displayName": "Acme Corp"}]}

        monkeypatch.setattr(
            "app.microsoft.onboarding_service.default_graph_client_factory",
            lambda env_id, tenant_id, include_pending=False: FakeClient(),
        )
        result = asyncio.run(check_tenant_connection(uuid.uuid4(), uuid.uuid4()))
        assert result.success
        assert result.remote_tenant_id == VALID_TENANT_ID
        assert result.remote_display_name == "Acme Corp"

    def test_factory_error_is_reported_not_raised(self, monkeypatch):
        from app.microsoft.factory import GraphClientFactoryError

        def _raise(*_args, **_kwargs):
            raise GraphClientFactoryError("tenant_connection_unavailable")

        monkeypatch.setattr("app.microsoft.onboarding_service.default_graph_client_factory", _raise)
        result = asyncio.run(check_tenant_connection(uuid.uuid4(), uuid.uuid4()))
        assert not result.success
        assert "tenant_connection_unavailable" in result.error

    def test_token_acquisition_error_is_reported(self, monkeypatch):
        from app.microsoft.token_broker import TokenAcquisitionError

        class FailingClient:
            async def get(self, resource, params=None):
                raise TokenAcquisitionError("invalid_client")

        monkeypatch.setattr(
            "app.microsoft.onboarding_service.default_graph_client_factory",
            lambda env_id, tenant_id, include_pending=False: FailingClient(),
        )
        result = asyncio.run(check_tenant_connection(uuid.uuid4(), uuid.uuid4()))
        assert not result.success
        assert "invalid_client" in result.error

    def test_empty_organization_result_is_failure(self, monkeypatch):
        class EmptyClient:
            async def get(self, resource, params=None):
                return {"value": []}

        monkeypatch.setattr(
            "app.microsoft.onboarding_service.default_graph_client_factory",
            lambda env_id, tenant_id, include_pending=False: EmptyClient(),
        )
        result = asyncio.run(check_tenant_connection(uuid.uuid4(), uuid.uuid4()))
        assert not result.success

    def test_unexpected_exception_is_reported_not_raised(self, monkeypatch):
        """實測踩坑：填一個格式正確但不存在的 tenant id，MSAL 在建構 client 時做 OIDC
        discovery 網路呼叫失敗會丟原生 ValueError；token_broker 已在來源處接住並轉譯，
        這裡是最後一道防線，確保「測試連線」這個使用者觸發的按鈕不管什麼例外都不會 500。"""
        class ExplodingClient:
            async def get(self, resource, params=None):
                raise ValueError("Unable to get authority configuration for https://login.microsoftonline.com/x")

        monkeypatch.setattr(
            "app.microsoft.onboarding_service.default_graph_client_factory",
            lambda env_id, tenant_id, include_pending=False: ExplodingClient(),
        )
        result = asyncio.run(check_tenant_connection(uuid.uuid4(), uuid.uuid4()))
        assert not result.success
        assert "未預期的錯誤" in result.error


class TestApplyConnectionTestResult:
    def _tenant_and_connection(self, *, tenant_status="pending", connection_status="pending"):
        tenant = ManagedTenant(
            entra_tenant_id=VALID_TENANT_ID, display_name="Acme", status=tenant_status,
        )
        connection = TenantConnection(status=connection_status)
        return tenant, connection

    def test_success_activates_tenant_and_connection(self):
        tenant, connection = self._tenant_and_connection()
        result = ConnectionTestResult(success=True, remote_tenant_id=VALID_TENANT_ID, remote_display_name="Acme Corp")

        apply_connection_test_result(tenant, connection, result)

        assert tenant.status == "active"
        assert connection.status == "active"
        assert tenant.display_name == "Acme Corp"

    def test_failure_marks_pending_as_still_pending(self):
        tenant, connection = self._tenant_and_connection()
        result = ConnectionTestResult(success=False, error="graph_authorization_failed")

        apply_connection_test_result(tenant, connection, result)

        assert tenant.status == "pending"
        assert connection.status == "pending"

    def test_failure_degrades_previously_active_connection(self):
        tenant, connection = self._tenant_and_connection(tenant_status="active", connection_status="active")
        result = ConnectionTestResult(success=False, error="graph_authorization_failed")

        apply_connection_test_result(tenant, connection, result)

        assert tenant.status == "degraded"
        assert connection.status == "degraded"

    def test_tenant_id_mismatch_is_rejected_and_not_activated(self):
        """安全檢查：回傳的 tenant id 跟輸入值不一致，不能自動信任並標記為 active。"""
        tenant, connection = self._tenant_and_connection()
        result = ConnectionTestResult(
            success=True, remote_tenant_id="99999999-9999-9999-9999-999999999999", remote_display_name="Someone Else",
        )

        with pytest.raises(ValueError, match="不符"):
            apply_connection_test_result(tenant, connection, result)

        assert tenant.status == "pending"
        assert connection.status == "pending"
