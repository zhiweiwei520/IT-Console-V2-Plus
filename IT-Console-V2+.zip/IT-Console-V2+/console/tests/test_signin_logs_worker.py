"""signin_logs.sync Dispatcher/Worker：watermark 增量、time-range $filter、append-only。

roadmap Phase B3 的驗證重點——刻意與 accounts/devices（全量同步 + 刪除過期）相反：
- 首次同步用初始視窗（最近 24h）控制資料量；後續只抓 createdDateTime >= watermark。
- 完成後不刪除既有資料（append-only）。
另含與其他模組相同的 checkpoint 重送、Retry-After、401 降級、授權重驗證 parity 案例。
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta
import uuid

from app.capabilities.signin_logs.handler import SignInLogsSyncHandler
from app.capabilities.signin_logs.models import SignInLog, SignInLogSyncCheckpoint
from app.extensions import db as _db
from app.jobs.dispatcher import SignInLogsSyncDispatcher
from app.jobs.models import DurableJob, JobDeadLetter
from app.jobs.worker import WorkerRunner
from app.microsoft.graph_client import GraphRetryableError, GraphTerminalError
from app.microsoft.models import TenantConnection
from app.storage.tenant_context import TenantContext
from app.storage.time_utils import utc_now_naive

_SIGNINS = "/auditLogs/signIns"
_SIGNINS_P2 = "/auditLogs/signIns?page=2"


class FakeGraphClient:
    def __init__(self, pages, *, fail_once_on=None):
        self.pages = pages
        self.fail_once_on = fail_once_on
        self.failed = False
        self.calls = []  # (resource, params)

    async def get(self, resource, *, params=None):
        self.calls.append((resource, params))
        if resource == self.fail_once_on and not self.failed:
            self.failed = True
            raise TimeoutError("simulated crash")
        return self.pages[resource]


class RaisingGraphClient:
    def __init__(self, exc: Exception) -> None:
        self.exc = exc
        self.calls: list = []

    async def get(self, resource, *, params=None):
        self.calls.append((resource, params))
        raise self.exc


def _signin(sid: str, created: str, *, error_code: int = 0) -> dict:
    return {
        "id": sid, "createdDateTime": created,
        "userPrincipalName": f"{sid}@example.com", "userDisplayName": sid.upper(),
        "appDisplayName": "Microsoft 365", "ipAddress": "203.0.113.9",
        "clientAppUsed": "Browser", "conditionalAccessStatus": "notApplied",
        "status": {"errorCode": error_code, "failureReason": None if error_code == 0 else "bad creds"},
    }


def _context(fixture) -> TenantContext:
    return TenantContext(
        principal_id=fixture.principal.id,
        environment_id=fixture.environment.id,
        membership_id=fixture.membership.id,
        allowed_managed_tenant_ids=None,
        active_managed_tenant_id=None,
        permission_codes=frozenset(fixture.membership.permission_codes),
        correlation_id=str(uuid.uuid4()),
    )


def _dispatch(fixture) -> str:
    dispatcher = SignInLogsSyncDispatcher(_db.session, _context(fixture))
    message_id = dispatcher.enqueue(fixture.tenant.id, operation_id=uuid.uuid4())
    _db.session.commit()
    return message_id


def _runner(fixture, client, *, worker_id="worker-1"):
    handler = SignInLogsSyncHandler(_db.session, lambda _env, _tenant: client)
    return WorkerRunner(
        _db.session, {"signin_logs.sync": handler}, worker_id=worker_id, lease_seconds=60,
    )


def _two_pages():
    return {
        _SIGNINS: {"value": [_signin("s1", "2026-07-11T05:00:00Z")], "@odata.nextLink": _SIGNINS_P2},
        _SIGNINS_P2: {"value": [_signin("s2", "2026-07-11T05:01:00Z")]},
    }


def test_worker_syncs_signins_and_completes_job(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = FakeGraphClient(_two_pages())

    assert asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    job = _db.session.get(DurableJob, message_id)
    checkpoint = SignInLogSyncCheckpoint.query.filter_by(job_id=job.id).one()
    rows = SignInLog.query.filter_by(managed_tenant_id=env_a.tenant.id).order_by(SignInLog.source_object_id).all()
    assert job.status == "completed"
    assert checkpoint.status == "completed"
    assert checkpoint.processed_count == 2
    assert [r.source_object_id for r in rows] == ["s1", "s2"]
    assert rows[0].created_datetime == datetime(2026, 7, 11, 5, 0, 0)
    assert rows[0].status == "success"


def test_first_sync_uses_initial_24h_window_when_no_data(two_environments):
    env_a, _env_b = two_environments
    _dispatch(env_a)
    client = FakeGraphClient({_SIGNINS: {"value": [_signin("s1", "2026-07-11T05:00:00Z")]}})

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    first_resource, first_params = client.calls[0]
    assert first_resource == _SIGNINS
    assert first_params["$filter"].startswith("createdDateTime ge ")
    assert first_params["$orderby"] == "createdDateTime"
    assert first_params["$top"] == 200
    # 無既有資料 → 視窗下界約為 now-24h（容忍幾分鐘誤差）。
    boundary = datetime.strptime(first_params["$filter"].split(" ge ")[1], "%Y-%m-%dT%H:%M:%SZ")
    expected = utc_now_naive() - timedelta(hours=24)
    assert abs((boundary - expected).total_seconds()) < 300


def test_incremental_second_sync_filters_from_watermark(two_environments):
    env_a, _env_b = two_environments
    _dispatch(env_a)
    asyncio.run(_runner(env_a, FakeGraphClient(_two_pages())).run_once(env_a.environment.id))
    # 第一輪後 watermark = MAX(createdDateTime) = 05:01:00。

    _dispatch(env_a)  # 新 operation → 新 job
    client2 = FakeGraphClient({_SIGNINS: {"value": [_signin("s3", "2026-07-11T05:05:00Z")]}})
    asyncio.run(_runner(env_a, client2, worker_id="worker-2").run_once(env_a.environment.id))

    _first_resource, params = client2.calls[0]
    assert params["$filter"] == "createdDateTime ge 2026-07-11T05:01:00Z"
    # append-only：舊 2 筆保留 + 新 1 筆 = 3。
    assert SignInLog.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 3


def test_sync_is_append_only_and_never_deletes(two_environments):
    env_a, _env_b = two_environments
    _dispatch(env_a)
    asyncio.run(_runner(env_a, FakeGraphClient(_two_pages())).run_once(env_a.environment.id))
    assert SignInLog.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 2

    # 第二輪回空頁（沒有新記錄）——既有資料不得被刪除（與 devices/accounts full-sync 相反）。
    _dispatch(env_a)
    empty_client = FakeGraphClient({_SIGNINS: {"value": []}})
    asyncio.run(_runner(env_a, empty_client, worker_id="worker-2").run_once(env_a.environment.id))

    assert SignInLog.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 2


def test_failure_signin_records_status_and_reason(two_environments):
    env_a, _env_b = two_environments
    _dispatch(env_a)
    client = FakeGraphClient({_SIGNINS: {"value": [_signin("s1", "2026-07-11T05:00:00Z", error_code=50126)]}})

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    row = SignInLog.query.filter_by(managed_tenant_id=env_a.tenant.id).one()
    assert row.status == "failure"
    assert row.failure_reason == "bad creds"


def test_signin_missing_id_is_terminal(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = FakeGraphClient({_SIGNINS: {"value": [{"createdDateTime": "2026-07-11T05:00:00Z"}]}})

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    assert _db.session.get(DurableJob, message_id).status == "dead_letter"
    assert JobDeadLetter.query.filter_by(job_id=uuid.UUID(message_id)).one().reason == "graph_signin_invalid"
    assert SignInLog.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 0


def test_signin_missing_created_datetime_is_terminal(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = FakeGraphClient({_SIGNINS: {"value": [{"id": "s1"}]}})

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    assert _db.session.get(DurableJob, message_id).status == "dead_letter"
    assert JobDeadLetter.query.filter_by(job_id=uuid.UUID(message_id)).one().reason == "graph_signin_invalid"


def test_retry_resumes_from_committed_page_checkpoint(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = FakeGraphClient(_two_pages(), fail_once_on=_SIGNINS_P2)
    runner = _runner(env_a, client)

    asyncio.run(runner.run_once(env_a.environment.id))
    checkpoint = SignInLogSyncCheckpoint.query.filter_by(job_id=uuid.UUID(message_id)).one()
    assert checkpoint.next_resource == _SIGNINS_P2
    assert checkpoint.processed_count == 1
    window_after_crash = checkpoint.window_start
    assert SignInLog.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 1

    job = _db.session.get(DurableJob, message_id)
    job.available_at = utc_now_naive() - timedelta(seconds=1)
    _db.session.commit()
    asyncio.run(runner.run_once(env_a.environment.id))

    assert _db.session.get(DurableJob, message_id).status == "completed"
    assert SignInLog.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 2
    # window_start 不因 resume 而改變（避免 watermark 前移跳過邊界）。
    assert SignInLogSyncCheckpoint.query.filter_by(job_id=uuid.UUID(message_id)).one().window_start == window_after_crash
    assert [c[0] for c in client.calls] == [_SIGNINS, _SIGNINS_P2, _SIGNINS_P2]


def test_worker_dead_letters_job_after_membership_revocation(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    env_a.membership.status = "suspended"
    _db.session.commit()
    client = FakeGraphClient(_two_pages())

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    assert _db.session.get(DurableJob, message_id).status == "dead_letter"
    assert JobDeadLetter.query.filter_by(job_id=uuid.UUID(message_id)).one().reason == (
        "membership_no_longer_authorized"
    )
    assert client.calls == []


def test_worker_requeues_using_graph_retry_after_not_fixed_delay(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = RaisingGraphClient(GraphRetryableError("graph_throttled", retry_after=91, status_code=429))
    before = utc_now_naive()

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    job = _db.session.get(DurableJob, message_id)
    assert job.status == "queued"
    assert job.last_error == "graph_throttled"
    delay = (job.available_at - before).total_seconds()
    assert 85 <= delay <= 95, f"expected ~91s delay from Retry-After, got {delay}s"


def test_worker_dead_letters_immediately_and_degrades_connection_on_401(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    connection = TenantConnection(
        environment_id=env_a.environment.id,
        managed_tenant_id=env_a.tenant.id,
        client_id="client-abc",
        credential_ref="env:V2PLUS_TEST_SECRET",
        status="active",
    )
    _db.session.add(connection)
    _db.session.commit()

    client = RaisingGraphClient(GraphTerminalError("graph_authorization_failed", status_code=401))
    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    job = _db.session.get(DurableJob, message_id)
    assert job.status == "dead_letter"
    assert job.attempt == 1
    assert _db.session.get(TenantConnection, connection.id).status == "degraded"
