"""
PostgreSQL RLS 整合測試 — opt-in，需明確設定 V2PLUS_TEST_DATABASE_URL 才會執行。

AGENTS.md sandbox 規則：測試預設只能用 sqlite:///:memory:，不得未經核准觸碰任何真實
Postgres 資料庫。此檔案在未設定該環境變數時全數 skip（不是靜默略過斷言，而是整個
collection 直接 skip，pytest 報告會清楚列出 skipped，不會被誤認為「已驗證通過」）。

使用方式（人工執行，不在預設 CI/PR 測試門檻內）：
    createdb it_console_v2plus_rls_test
    V2PLUS_TEST_DATABASE_URL=postgresql://user:pass@localhost/it_console_v2plus_rls_test \
        pytest tests/test_rls_postgres.py -v
"""
from __future__ import annotations

import os
import uuid

import pytest

TEST_DB_URL = os.environ.get("V2PLUS_TEST_DATABASE_URL", "").strip()

pytestmark = pytest.mark.skipif(
    not TEST_DB_URL,
    reason="V2PLUS_TEST_DATABASE_URL 未設定；RLS 整合測試需明確核准的拋棄式 Postgres DB（見檔案說明）。",
)


@pytest.fixture()
def pg_app():
    os.environ["FLASK_ENV"] = "testing"

    from config import TestingConfig

    class RlsTestConfig(TestingConfig):
        SQLALCHEMY_DATABASE_URI = TEST_DB_URL

    from app import create_app
    from app.extensions import db as _db
    from flask_migrate import upgrade as migrate_upgrade

    application = create_app(RlsTestConfig)
    with application.app_context():
        migrate_upgrade()
        yield application
        _db.session.remove()
        for table in reversed(_db.metadata.sorted_tables):
            _db.session.execute(table.delete())
        _db.session.commit()


def _seed_environment(_db, slug: str):
    from app.microsoft.models import ManagedTenant
    from app.platform.models import ManagementEnvironment, Principal
    from app.storage.rls import apply_rls_context
    from app.storage.tenant_context import TenantContext

    env = ManagementEnvironment(slug=slug, name=slug, status="active")
    principal = Principal(display_name=slug)
    _db.session.add_all([env, principal])
    _db.session.flush()

    ctx = TenantContext(
        principal_id=principal.id, environment_id=env.id, membership_id=uuid.uuid4(),
        permission_codes=frozenset(), correlation_id="seed",
    )
    apply_rls_context(_db.session, ctx)

    tenant = ManagedTenant(
        environment_id=env.id, entra_tenant_id=str(uuid.uuid4()), display_name=slug, status="active",
    )
    _db.session.add(tenant)
    _db.session.flush()

    from app.capabilities.accounts.models import Account
    account = Account(
        environment_id=env.id, managed_tenant_id=tenant.id, source_object_id="obj-1",
        display_name=slug, user_principal_name=f"{slug}@example.com",
    )
    _db.session.add(account)
    _db.session.commit()
    return env, tenant, account


def test_rls_blocks_cross_environment_raw_query(pg_app):
    from app.extensions import db as _db
    from app.storage.rls import apply_rls_context
    from app.storage.tenant_context import TenantContext
    from app.capabilities.accounts.models import Account

    env_a, _tenant_a, _account_a = _seed_environment(_db, "rls-env-a")
    env_b, _tenant_b, _account_b = _seed_environment(_db, "rls-env-b")

    ctx_a = TenantContext(
        principal_id=uuid.uuid4(), environment_id=env_a.id, membership_id=uuid.uuid4(),
        permission_codes=frozenset(), correlation_id="check-a",
    )
    apply_rls_context(_db.session, ctx_a)

    visible = _db.session.query(Account).all()
    assert len(visible) == 1
    assert visible[0].environment_id == env_a.id


def test_rls_default_deny_without_context(pg_app):
    from app.extensions import db as _db
    from app.capabilities.accounts.models import Account
    from app.storage.rls import clear_rls_context

    _seed_environment(_db, "rls-env-default-deny")
    clear_rls_context(_db.session)

    visible = _db.session.query(Account).all()
    assert visible == []


def test_rls_with_check_blocks_cross_environment_insert(pg_app):
    from app.extensions import db as _db
    from app.storage.rls import apply_rls_context
    from app.storage.tenant_context import TenantContext
    from app.capabilities.accounts.models import Account
    from sqlalchemy.exc import DBAPIError

    env_a, tenant_a, _account_a = _seed_environment(_db, "rls-env-insert-a")
    env_b, _tenant_b, _account_b = _seed_environment(_db, "rls-env-insert-b")

    ctx_a = TenantContext(
        principal_id=uuid.uuid4(), environment_id=env_a.id, membership_id=uuid.uuid4(),
        permission_codes=frozenset(), correlation_id="insert-check",
    )
    apply_rls_context(_db.session, ctx_a)

    rogue = Account(
        environment_id=env_b.id,  # 故意夾帶別的 Environment
        managed_tenant_id=tenant_a.id,
        source_object_id="rogue",
        display_name="rogue",
        user_principal_name="rogue@example.com",
    )
    _db.session.add(rogue)
    with pytest.raises(DBAPIError):
        _db.session.commit()
    _db.session.rollback()
