"""signin_logs capability：權限缺口、三層 gating、清單頁 render、ISO 時間解析單元測試。"""
from __future__ import annotations

from datetime import datetime

import pytest

from app.capabilities.signin_logs.service import SignInLogService, parse_graph_datetime
from app.extensions import db as _db
from app.storage.tenant_context import TenantContext


def test_parse_graph_datetime_handles_z_and_fractional_seconds():
    assert parse_graph_datetime("2026-07-11T05:00:00Z") == datetime(2026, 7, 11, 5, 0, 0)
    # 7 位小數（Graph 常見）截到 6 位仍可解析。
    assert parse_graph_datetime("2026-07-11T05:00:00.1234567Z") == datetime(2026, 7, 11, 5, 0, 0, 123456)
    # 帶時區偏移 → 轉 UTC。
    assert parse_graph_datetime("2026-07-11T13:00:00+08:00") == datetime(2026, 7, 11, 5, 0, 0)


def test_parse_graph_datetime_rejects_missing_and_garbage():
    with pytest.raises(ValueError):
        parse_graph_datetime("")
    with pytest.raises(ValueError):
        parse_graph_datetime("not-a-date")


def test_service_raises_without_signin_view_permission(two_environments):
    env_a, _env_b = two_environments
    ctx = TenantContext(
        principal_id=env_a.principal.id,
        environment_id=env_a.environment.id,
        membership_id=env_a.membership.id,
        allowed_managed_tenant_ids=None,
        active_managed_tenant_id=None,
        permission_codes=frozenset(),  # 沒有 signin_logs.view
        correlation_id="no-perm",
    )
    service = SignInLogService(_db.session, ctx)
    with pytest.raises(PermissionError):
        service.list_recent()


def _login_and_switch(client, env_a):
    client.post("/auth/login", data={
        "environment_slug": "", "username": "user-a", "password": "TestPass!12345",
    })
    client.post(f"/environments/{env_a.environment.id}/switch")
    client.post(f"/microsoft/managed-tenants/{env_a.tenant.id}/switch")


def test_web_route_returns_403_when_role_lacks_signin_view(client, two_environments, app):
    env_a, _env_b = two_environments
    from app.platform.models import EnvironmentRole, RoleAssignment
    from app.storage.time_utils import utc_now_naive

    with app.app_context():
        bare_role = EnvironmentRole(environment_id=env_a.environment.id, code="bare", label="Bare", is_builtin=False)
        _db.session.add(bare_role)
        _db.session.flush()
        RoleAssignment.query.filter_by(membership_id=env_a.membership.id).delete()
        _db.session.add(RoleAssignment(
            environment_id=env_a.environment.id, membership_id=env_a.membership.id,
            role_id=bare_role.id, granted_at=utc_now_naive(),
        ))
        _db.session.commit()

    _login_and_switch(client, env_a)
    resp = client.get("/capabilities/signin-logs/")
    assert resp.status_code == 403


def test_list_page_renders_seeded_sign_ins(client, two_environments, app):
    from app.capabilities.signin_logs.service import seed_demo_sign_in_logs

    env_a, _env_b = two_environments
    with app.app_context():
        seed_demo_sign_in_logs(_db.session, environment_id=env_a.environment.id, managed_tenant_id=env_a.tenant.id)
        _db.session.commit()

    _login_and_switch(client, env_a)
    resp = client.get("/capabilities/signin-logs/")
    body = resp.get_data(as_text=True)
    assert resp.status_code == 200
    assert "登入記錄" in body
    assert "demo.user1@example.onmicrosoft.com" in body


def test_sync_route_enqueues_job_for_authorized_tenant(client, two_environments, app):
    from app.jobs.models import DurableJob

    env_a, _env_b = two_environments
    _login_and_switch(client, env_a)

    resp = client.post("/capabilities/signin-logs/sync", data={
        "managed_tenant_id": str(env_a.tenant.id),
    }, follow_redirects=False)
    assert resp.status_code == 302

    with app.app_context():
        assert DurableJob.query.filter_by(
            environment_id=env_a.environment.id, managed_tenant_id=env_a.tenant.id, job_type="signin_logs.sync",
        ).count() == 1


def test_sync_route_ignores_forged_foreign_tenant_form_value(client, two_environments, app):
    env_a, env_b = two_environments
    _login_and_switch(client, env_a)

    resp = client.post("/capabilities/signin-logs/sync", data={
        "managed_tenant_id": str(env_b.tenant.id),
    }, follow_redirects=True)
    assert resp.status_code == 200

    with app.app_context():
        from app.jobs.models import DurableJob
        assert DurableJob.query.filter_by(managed_tenant_id=env_b.tenant.id).count() == 0
        assert DurableJob.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 1


def test_sync_route_requires_signin_sync_permission(client, two_environments, app):
    from app.platform.models import EnvironmentRole, RoleAssignment
    from app.storage.time_utils import utc_now_naive

    env_a, _env_b = two_environments
    with app.app_context():
        # viewer 有 signin_logs.view 但無 signin_logs.sync；動作端點窄權限不被清單權限放寬。
        viewer_role = EnvironmentRole.query.filter_by(
            environment_id=env_a.environment.id, code="viewer",
        ).one()
        RoleAssignment.query.filter_by(membership_id=env_a.membership.id).delete()
        _db.session.add(RoleAssignment(
            environment_id=env_a.environment.id, membership_id=env_a.membership.id,
            role_id=viewer_role.id, granted_at=utc_now_naive(),
        ))
        _db.session.commit()

    _login_and_switch(client, env_a)
    resp = client.post("/capabilities/signin-logs/sync", data={"managed_tenant_id": str(env_a.tenant.id)})
    assert resp.status_code == 403
