"""accounts.sync Dispatcher/Worker：分頁、checkpoint、重送與授權重驗證。"""
from __future__ import annotations

import asyncio
from datetime import timedelta
import uuid

from app.capabilities.accounts.handler import AccountsSyncHandler
from app.capabilities.accounts.models import Account, AccountSyncCheckpoint
from app.extensions import db as _db
from app.jobs.dispatcher import AccountsSyncDispatcher
from app.jobs.models import DurableJob, JobDeadLetter
from app.jobs.worker import WorkerRunner
from app.microsoft.graph_client import GraphRetryableError, GraphTerminalError
from app.microsoft.models import TenantConnection
from app.storage.tenant_context import TenantContext
from app.storage.time_utils import utc_now_naive


class FakeGraphClient:
    def __init__(self, pages, *, fail_once_on=None):
        self.pages = pages
        self.fail_once_on = fail_once_on
        self.failed = False
        self.calls = []

    async def get(self, resource, *, params=None):
        self.calls.append(resource)
        if resource == self.fail_once_on and not self.failed:
            self.failed = True
            raise TimeoutError("simulated crash")
        return self.pages[resource]


def _context(fixture) -> TenantContext:
    return TenantContext(
        principal_id=fixture.principal.id,
        environment_id=fixture.environment.id,
        membership_id=fixture.membership.id,
        allowed_managed_tenant_ids=None,
        active_managed_tenant_id=None,
        permission_codes=frozenset(fixture.membership.permission_codes),
        correlation_id=str(uuid.uuid4()),
    )


def _dispatch(fixture) -> str:
    dispatcher = AccountsSyncDispatcher(_db.session, _context(fixture))
    message_id = dispatcher.enqueue(fixture.tenant.id, operation_id=uuid.uuid4())
    _db.session.commit()
    return message_id


def _runner(fixture, client, *, worker_id="worker-1"):
    handler = AccountsSyncHandler(_db.session, lambda _env, _tenant: client)
    return WorkerRunner(
        _db.session, {"accounts.sync": handler}, worker_id=worker_id, lease_seconds=60,
    )


class RaisingGraphClient:
    """回傳真實 GraphClient 例外類別（非通用 Exception），驗證 handler 正確轉譯而非全部
    落入 except Exception 的固定 30 秒重試（曾經的 bug：見 handler.py 修正說明）。"""

    def __init__(self, exc: Exception) -> None:
        self.exc = exc
        self.calls: list[str] = []

    async def get(self, resource, *, params=None):
        self.calls.append(resource)
        raise self.exc


def _pages():
    return {
        "/users": {
            "value": [{
                "id": "user-1", "displayName": "User One",
                "userPrincipalName": "one@example.com", "accountEnabled": True,
            }],
            "@odata.nextLink": "/users?page=2",
        },
        "/users?page=2": {
            "value": [{
                "id": "user-2", "displayName": "User Two",
                "userPrincipalName": "two@example.com", "accountEnabled": False,
            }],
        },
    }


def test_worker_syncs_graph_pages_and_completes_job(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = FakeGraphClient(_pages())

    assert asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    job = _db.session.get(DurableJob, message_id)
    checkpoint = AccountSyncCheckpoint.query.filter_by(job_id=job.id).one()
    accounts = Account.query.filter_by(managed_tenant_id=env_a.tenant.id).order_by(Account.source_object_id).all()
    assert job.status == "completed"
    assert checkpoint.status == "completed"
    assert checkpoint.processed_count == 2
    assert [account.source_object_id for account in accounts] == ["user-1", "user-2"]
    assert accounts[1].account_enabled is False


def test_retry_resumes_from_committed_page_checkpoint(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = FakeGraphClient(_pages(), fail_once_on="/users?page=2")
    runner = _runner(env_a, client)

    asyncio.run(runner.run_once(env_a.environment.id))
    checkpoint = AccountSyncCheckpoint.query.filter_by(job_id=uuid.UUID(message_id)).one()
    assert checkpoint.next_resource == "/users?page=2"
    assert checkpoint.processed_count == 1
    assert Account.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 1

    job = _db.session.get(DurableJob, message_id)
    job.available_at = utc_now_naive() - timedelta(seconds=1)
    _db.session.commit()
    asyncio.run(runner.run_once(env_a.environment.id))

    assert _db.session.get(DurableJob, message_id).status == "completed"
    assert Account.query.filter_by(managed_tenant_id=env_a.tenant.id).count() == 2
    assert client.calls == ["/users", "/users?page=2", "/users?page=2"]


def test_completed_checkpoint_makes_redelivery_idempotent(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = FakeGraphClient(_pages())
    runner = _runner(env_a, client)
    asyncio.run(runner.run_once(env_a.environment.id))
    calls_after_completion = list(client.calls)

    job = _db.session.get(DurableJob, message_id)
    job.status = "leased"
    job.lease_owner = "crashed-worker"
    job.lease_expires_at = utc_now_naive() - timedelta(seconds=1)
    job.completed_at = None
    _db.session.commit()

    asyncio.run(_runner(env_a, client, worker_id="recovery-worker").run_once(env_a.environment.id))
    assert _db.session.get(DurableJob, message_id).status == "completed"
    assert client.calls == calls_after_completion


def test_worker_dead_letters_job_after_membership_revocation(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    env_a.membership.status = "suspended"
    _db.session.commit()
    client = FakeGraphClient(_pages())

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    assert _db.session.get(DurableJob, message_id).status == "dead_letter"
    assert JobDeadLetter.query.filter_by(job_id=uuid.UUID(message_id)).one().reason == (
        "membership_no_longer_authorized"
    )
    assert client.calls == []


def test_worker_revalidates_managed_tenant_grant(two_environments):
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    env_a.membership.all_managed_tenants = False
    env_a.membership.version += 1
    _db.session.commit()
    client = FakeGraphClient(_pages())

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    assert _db.session.get(DurableJob, message_id).status == "dead_letter"
    assert JobDeadLetter.query.filter_by(job_id=uuid.UUID(message_id)).one().reason == (
        "managed_tenant_grant_revoked"
    )
    assert client.calls == []


def test_worker_requeues_using_graph_retry_after_not_fixed_delay(two_environments):
    """04 §7：429 必須遵守 Retry-After，不能被 handler 蓋成寫死的 30 秒。"""
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = RaisingGraphClient(GraphRetryableError("graph_throttled", retry_after=91, status_code=429))
    before = utc_now_naive()

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    job = _db.session.get(DurableJob, message_id)
    assert job.status == "queued"
    assert job.last_error == "graph_throttled"
    delay = (job.available_at - before).total_seconds()
    assert 85 <= delay <= 95, f"expected ~91s delay from Retry-After, got {delay}s"


def test_worker_dead_letters_immediately_and_degrades_connection_on_401(two_environments):
    """401/403 是永久性錯誤，必須立刻 dead-letter（不是重試 5 次才放棄）且降級 connection。"""
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    connection = TenantConnection(
        environment_id=env_a.environment.id,
        managed_tenant_id=env_a.tenant.id,
        client_id="client-abc",
        credential_ref="env:V2PLUS_TEST_SECRET",
        status="active",
    )
    _db.session.add(connection)
    _db.session.commit()

    client = RaisingGraphClient(GraphTerminalError("graph_authorization_failed", status_code=401))
    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    job = _db.session.get(DurableJob, message_id)
    assert job.status == "dead_letter"
    assert job.attempt == 1  # 沒有燒完 max_attempts 才放棄
    assert JobDeadLetter.query.filter_by(job_id=uuid.UUID(message_id)).one().reason == (
        "graph_authorization_failed"
    )
    assert _db.session.get(TenantConnection, connection.id).status == "degraded"


def test_worker_ignores_unexpected_errors_as_retryable_with_default_delay(two_environments):
    """非 Graph 例外（程式錯誤／未預期 exception）仍走保守的可重試路徑，不當機整個 worker。"""
    env_a, _env_b = two_environments
    message_id = _dispatch(env_a)
    client = RaisingGraphClient(RuntimeError("unexpected bug"))

    asyncio.run(_runner(env_a, client).run_once(env_a.environment.id))

    job = _db.session.get(DurableJob, message_id)
    assert job.status == "queued"
    assert job.last_error == "graph_request_failed"
