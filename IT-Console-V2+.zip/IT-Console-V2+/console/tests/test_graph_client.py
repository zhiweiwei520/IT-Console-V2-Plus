"""
HttpGraphClient：endpoint allowlist、429/5xx/401 分類、Retry-After 解析、分頁。

用 httpx.MockTransport 模擬回應，不打真實網路（AGENTS.md sandbox 規則亦不允許）。
對應 07-testing-acceptance.md §2 Contract 層（Graph response、429、delta/paging）。

沿用 test_worker_process.py／test_accounts_worker.py 的慣例：測試函式維持同步，
內部用 asyncio.run() 執行 async 邏輯，不額外引入 pytest-asyncio 設定。
"""
from __future__ import annotations

import asyncio
import json

import httpx
import pytest

from app.microsoft.graph_client import (
    GraphRetryableError,
    GraphTerminalError,
    HttpGraphClient,
)


class FakeTokenBroker:
    def __init__(self, token: str = "fake-token") -> None:
        self.token = token
        self.calls = []

    def acquire_token(self, tenant, connection, *, resource="https://graph.microsoft.com"):
        self.calls.append((tenant, connection, resource))
        return self.token


def _client(handler) -> HttpGraphClient:
    transport = httpx.MockTransport(handler)
    http_client = httpx.AsyncClient(transport=transport)
    return HttpGraphClient(FakeTokenBroker(), tenant=object(), connection=object(), http_client=http_client)


def _json_response(status_code: int, payload, headers=None) -> httpx.Response:
    return httpx.Response(status_code, json=payload, headers=headers or {})


def test_get_success_sends_bearer_token_and_returns_payload():
    seen = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["url"] = str(request.url)
        seen["authorization"] = request.headers.get("authorization")
        return _json_response(200, {"value": []})

    client = _client(handler)
    result = asyncio.run(client.get("/users"))

    assert result == {"value": []}
    assert seen["url"] == "https://graph.microsoft.com/v1.0/users"
    assert seen["authorization"] == "Bearer fake-token"


def test_get_rejects_beta_endpoint_without_network_call():
    called = False

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal called
        called = True
        return _json_response(200, {})

    client = _client(handler)
    with pytest.raises(GraphTerminalError) as exc_info:
        asyncio.run(client.get("/beta/users"))
    assert exc_info.value.code == "graph_beta_not_allowed"
    assert called is False


def test_get_rejects_absolute_non_graph_host():
    client = _client(lambda request: _json_response(200, {}))
    with pytest.raises(GraphTerminalError) as exc_info:
        asyncio.run(client.get("https://evil.example.com/v1.0/users"))
    assert exc_info.value.code == "graph_endpoint_not_allowed"


def test_get_accepts_absolute_graph_v1_url_used_for_next_link():
    def handler(request: httpx.Request) -> httpx.Response:
        assert str(request.url) == "https://graph.microsoft.com/v1.0/users?$skiptoken=abc"
        return _json_response(200, {"value": []})

    client = _client(handler)
    result = asyncio.run(client.get("https://graph.microsoft.com/v1.0/users?$skiptoken=abc"))
    assert result == {"value": []}


def test_429_with_retry_after_header_is_retryable():
    client = _client(lambda request: _json_response(429, {}, headers={"Retry-After": "7"}))
    with pytest.raises(GraphRetryableError) as exc_info:
        asyncio.run(client.get("/users"))
    assert exc_info.value.code == "graph_throttled"
    assert exc_info.value.retry_after == 7
    assert exc_info.value.status_code == 429


def test_429_without_retry_after_header_defaults_to_30():
    client = _client(lambda request: _json_response(429, {}))
    with pytest.raises(GraphRetryableError) as exc_info:
        asyncio.run(client.get("/users"))
    assert exc_info.value.retry_after == 30


def test_retry_after_clamped_to_3600_max():
    client = _client(lambda request: _json_response(429, {}, headers={"Retry-After": "999999"}))
    with pytest.raises(GraphRetryableError) as exc_info:
        asyncio.run(client.get("/users"))
    assert exc_info.value.retry_after == 3600


def test_retry_after_invalid_value_defaults_to_30():
    client = _client(lambda request: _json_response(429, {}, headers={"Retry-After": "not-a-number"}))
    with pytest.raises(GraphRetryableError) as exc_info:
        asyncio.run(client.get("/users"))
    assert exc_info.value.retry_after == 30


def test_5xx_is_retryable_service_unavailable():
    client = _client(lambda request: _json_response(503, {}))
    with pytest.raises(GraphRetryableError) as exc_info:
        asyncio.run(client.get("/users"))
    assert exc_info.value.code == "graph_service_unavailable"


@pytest.mark.parametrize("status_code", [401, 403])
def test_401_403_are_terminal_authorization_failed(status_code):
    client = _client(lambda request: _json_response(status_code, {}))
    with pytest.raises(GraphTerminalError) as exc_info:
        asyncio.run(client.get("/users"))
    assert exc_info.value.code == "graph_authorization_failed"


def test_other_4xx_is_terminal_request_rejected():
    client = _client(lambda request: _json_response(400, {"error": "bad request"}))
    with pytest.raises(GraphTerminalError) as exc_info:
        asyncio.run(client.get("/users"))
    assert exc_info.value.code == "graph_request_rejected"


def test_non_json_response_is_terminal():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=b"not json")

    client = _client(handler)
    with pytest.raises(GraphTerminalError) as exc_info:
        asyncio.run(client.get("/users"))
    assert exc_info.value.code == "graph_response_not_json"


def test_non_dict_json_response_is_terminal():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=json.dumps([1, 2, 3]).encode())

    client = _client(handler)
    with pytest.raises(GraphTerminalError) as exc_info:
        asyncio.run(client.get("/users"))
    assert exc_info.value.code == "graph_response_invalid"


def test_transport_error_is_retryable():
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("boom", request=request)

    client = _client(handler)
    with pytest.raises(GraphRetryableError) as exc_info:
        asyncio.run(client.get("/users"))
    assert exc_info.value.code == "graph_transport_error"


def test_paged_get_follows_next_link_until_exhausted():
    pages = [
        {"value": [1], "@odata.nextLink": "https://graph.microsoft.com/v1.0/users?page=2"},
        {"value": [2]},
    ]
    calls = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(str(request.url))
        return _json_response(200, pages[len(calls) - 1])

    async def _collect():
        client = _client(handler)
        return [page async for page in client.paged_get("/users")]

    collected = asyncio.run(_collect())

    assert collected == pages
    assert calls == [
        "https://graph.microsoft.com/v1.0/users",
        "https://graph.microsoft.com/v1.0/users?page=2",
    ]


def test_paged_get_rejects_non_string_next_link():
    client = _client(lambda request: _json_response(200, {"value": [], "@odata.nextLink": 123}))

    async def _drain():
        async for _ in client.paged_get("/users"):
            pass

    with pytest.raises(GraphTerminalError) as exc_info:
        asyncio.run(_drain())
    assert exc_info.value.code == "graph_next_link_invalid"
