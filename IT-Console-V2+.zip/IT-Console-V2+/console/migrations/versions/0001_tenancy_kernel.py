"""tenancy kernel: principals, environments, memberships, managed tenants, accounts capability, RLS

Revision ID: 0001
Revises:
Create Date: 2026-07-10

RLS 設計對應 03-tenancy-identity-data.md §7：
  - Environment-only 表：USING/WITH CHECK 比對 current_setting('app.environment_id').
  - Managed-Tenant 表：Worker 路徑（app.managed_tenant_id 已釘選單一 tenant）直接比對；
    Web 路徑（app.managed_tenant_id 空字串）改查 environment_memberships +
    membership_tenant_grants，不把大型 allowed-id list 塞進 session variable。
  - 僅 PostgreSQL 執行 RLS 語句；SQLite（dev／單元測試）略過，防線退回 repository 層
    （app/storage/repository.py），見 docs/capability-manifest.md 已知落差說明。

應用 DB role（不得為 table owner、不得 BYPASSRLS）與 migration 專用 role 屬 IaC／DBA 範疇，
不在此 migration 內建立，見 README「PostgreSQL 正式部署」章節。
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from app.storage.types import GUID

# revision identifiers, used by Alembic.
revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def _is_postgres() -> bool:
    return op.get_bind().dialect.name == "postgresql"


def _enable_rls(table: str) -> None:
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")


def _environment_policy(table: str) -> None:
    _enable_rls(table)
    expr = (
        "environment_id::text = current_setting('app.environment_id', true)"
    )
    op.execute(
        f"CREATE POLICY {table}_environment_isolation ON {table} "
        f"USING ({expr}) WITH CHECK ({expr})"
    )


def _tenant_grant_exists_sql(table: str, tenant_id_expr: str) -> str:
    return (
        "EXISTS (SELECT 1 FROM environment_memberships m "
        f"WHERE m.environment_id = {table}.environment_id "
        "AND m.principal_id::text = current_setting('app.principal_id', true) "
        "AND m.status = 'active' "
        "AND (m.all_managed_tenants = true OR EXISTS ("
        "SELECT 1 FROM membership_tenant_grants g "
        f"WHERE g.membership_id = m.id AND g.managed_tenant_id = {tenant_id_expr})))"
    )


def _tenant_policy(table: str, tenant_id_column: str) -> None:
    """table 需同時具備 environment_id 與 tenant_id_column（自身 PK 或 managed_tenant_id 欄位）。"""
    _enable_rls(table)
    tenant_id_expr = f"{table}.{tenant_id_column}"
    grant_check = _tenant_grant_exists_sql(table, tenant_id_expr)
    expr = (
        "environment_id::text = current_setting('app.environment_id', true) "
        "AND (("
        "current_setting('app.managed_tenant_id', true) <> '' "
        f"AND {tenant_id_expr}::text = current_setting('app.managed_tenant_id', true)"
        ") OR ("
        "current_setting('app.managed_tenant_id', true) = '' "
        f"AND {grant_check}"
        "))"
    )
    op.execute(
        f"CREATE POLICY {table}_tenant_isolation ON {table} "
        f"USING ({expr}) WITH CHECK ({expr})"
    )


def upgrade() -> None:
    # ── Platform（全域，非 Environment 範圍，不套 RLS）──────────────────────
    op.create_table(
        "principals",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("display_name", sa.String(128), nullable=False),
        sa.Column("status", sa.String(16), nullable=False, server_default="active"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
    )

    op.create_table(
        "external_logins",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("principal_id", GUID(), sa.ForeignKey("principals.id"), nullable=False),
        sa.Column("canonical_issuer", sa.String(256), nullable=False),
        sa.Column("subject", sa.String(256), nullable=False),
        sa.Column("issuer_tenant_id", sa.String(64), nullable=True),
        sa.Column("object_id", sa.String(64), nullable=True),
        sa.Column("home_account_id", sa.String(128), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("canonical_issuer", "subject", name="uq_external_login_issuer_subject"),
    )
    op.create_index("ix_external_logins_principal_id", "external_logins", ["principal_id"])

    op.create_table(
        "platform_local_logins",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("principal_id", GUID(), sa.ForeignKey("principals.id"), nullable=False, unique=True),
        sa.Column("normalized_username", sa.String(64), nullable=False, unique=True),
        sa.Column("password_hash", sa.String(256), nullable=False),
        sa.Column("failed_login_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("locked_until", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
    )

    op.create_table(
        "platform_role_assignments",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("principal_id", GUID(), sa.ForeignKey("principals.id"), nullable=False),
        sa.Column("role_code", sa.String(32), nullable=False),
        sa.Column("granted_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("principal_id", "role_code", name="uq_platform_role_principal_code"),
    )
    op.create_index("ix_platform_role_assignments_principal_id", "platform_role_assignments", ["principal_id"])

    op.create_table(
        "permissions",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("code", sa.String(64), nullable=False, unique=True),
        sa.Column("label", sa.String(96), nullable=False),
        sa.Column("category", sa.String(32), nullable=False, server_default="general"),
        sa.Column("is_builtin", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )

    # ── Environment（Environment 範圍，套 environment-only RLS）─────────────
    op.create_table(
        "management_environments",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("slug", sa.String(64), nullable=False, unique=True),
        sa.Column("name", sa.String(128), nullable=False),
        sa.Column("status", sa.String(16), nullable=False, server_default="provisioning"),
        sa.Column("isolation_mode", sa.String(16), nullable=False, server_default="pooled"),
        sa.Column("membership_version", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
    )

    op.create_table(
        "environment_roles",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False),
        sa.Column("code", sa.String(32), nullable=False),
        sa.Column("label", sa.String(64), nullable=False),
        sa.Column("is_builtin", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("environment_id", "code", name="uq_environment_role_env_code"),
    )
    op.create_index("ix_environment_roles_environment_id", "environment_roles", ["environment_id"])

    op.create_table(
        "role_permissions",
        sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False),
        sa.Column("role_id", GUID(), sa.ForeignKey("environment_roles.id"), primary_key=True),
        sa.Column("permission_id", GUID(), sa.ForeignKey("permissions.id"), primary_key=True),
        sa.Column("granted_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_role_permissions_environment_id", "role_permissions", ["environment_id"])

    op.create_table(
        "environment_memberships",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False),
        sa.Column("principal_id", GUID(), sa.ForeignKey("principals.id"), nullable=False),
        sa.Column("status", sa.String(16), nullable=False, server_default="active"),
        sa.Column("all_managed_tenants", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("version", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("environment_id", "principal_id", name="uq_membership_env_principal"),
    )
    op.create_index("ix_environment_memberships_environment_id", "environment_memberships", ["environment_id"])
    op.create_index("ix_environment_memberships_principal_id", "environment_memberships", ["principal_id"])

    op.create_table(
        "role_assignments",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False),
        sa.Column("membership_id", GUID(), sa.ForeignKey("environment_memberships.id"), nullable=False),
        sa.Column("role_id", GUID(), sa.ForeignKey("environment_roles.id"), nullable=False),
        sa.Column("granted_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("membership_id", "role_id", name="uq_role_assignment_membership_role"),
    )
    op.create_index("ix_role_assignments_environment_id", "role_assignments", ["environment_id"])
    op.create_index("ix_role_assignments_membership_id", "role_assignments", ["membership_id"])
    op.create_index("ix_role_assignments_role_id", "role_assignments", ["role_id"])

    op.create_table(
        "environment_local_logins",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False),
        sa.Column("principal_id", GUID(), sa.ForeignKey("principals.id"), nullable=False),
        sa.Column("normalized_username", sa.String(64), nullable=False),
        sa.Column("password_hash", sa.String(256), nullable=False),
        sa.Column("failed_login_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("locked_until", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("environment_id", "normalized_username", name="uq_env_local_login_username"),
        sa.UniqueConstraint("environment_id", "principal_id", name="uq_env_local_login_principal"),
    )
    op.create_index("ix_environment_local_logins_environment_id", "environment_local_logins", ["environment_id"])

    op.create_table(
        "environment_audit_logs",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False),
        sa.Column("actor_principal_id", GUID(), sa.ForeignKey("principals.id"), nullable=True),
        sa.Column("action", sa.String(64), nullable=False),
        sa.Column("target_type", sa.String(32), nullable=True),
        sa.Column("target_id", sa.String(64), nullable=True),
        sa.Column("outcome", sa.String(16), nullable=False, server_default="success"),
        sa.Column("reason", sa.String(256), nullable=True),
        sa.Column("correlation_id", sa.String(64), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_environment_audit_logs_environment_id", "environment_audit_logs", ["environment_id"])
    op.create_index("ix_environment_audit_logs_action", "environment_audit_logs", ["action"])
    op.create_index("ix_environment_audit_logs_correlation_id", "environment_audit_logs", ["correlation_id"])
    op.create_index("ix_environment_audit_logs_created_at", "environment_audit_logs", ["created_at"])

    # ── Managed Tenant（environment_id + tenant grant RLS）─────────────────
    op.create_table(
        "managed_tenants",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False),
        sa.Column("entra_tenant_id", sa.String(64), nullable=False),
        sa.Column("cloud", sa.String(16), nullable=False, server_default="public"),
        sa.Column("display_name", sa.String(128), nullable=False),
        sa.Column("domain", sa.String(256), nullable=True),
        sa.Column("status", sa.String(16), nullable=False, server_default="pending"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("environment_id", "entra_tenant_id", name="uq_managed_tenant_env_entra"),
    )
    op.create_index("ix_managed_tenants_environment_id", "managed_tenants", ["environment_id"])

    op.create_table(
        "membership_tenant_grants",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False),
        sa.Column("membership_id", GUID(), sa.ForeignKey("environment_memberships.id"), nullable=False),
        sa.Column("managed_tenant_id", GUID(), sa.ForeignKey("managed_tenants.id"), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("membership_id", "managed_tenant_id", name="uq_tenant_grant_membership_tenant"),
    )
    op.create_index("ix_membership_tenant_grants_environment_id", "membership_tenant_grants", ["environment_id"])
    op.create_index("ix_membership_tenant_grants_membership_id", "membership_tenant_grants", ["membership_id"])
    op.create_index("ix_membership_tenant_grants_managed_tenant_id", "membership_tenant_grants", ["managed_tenant_id"])

    op.create_table(
        "tenant_connections",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False),
        sa.Column("managed_tenant_id", GUID(), sa.ForeignKey("managed_tenants.id"), nullable=False, unique=True),
        sa.Column("auth_mode", sa.String(16), nullable=False, server_default="provider_bundle"),
        sa.Column("client_id", sa.String(64), nullable=True),
        sa.Column("credential_ref", sa.String(256), nullable=True),
        sa.Column("credential_version", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("status", sa.String(16), nullable=False, server_default="pending"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_tenant_connections_environment_id", "tenant_connections", ["environment_id"])

    # ── accounts capability（vertical slice）────────────────────────────────
    op.create_table(
        "accounts",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False),
        sa.Column("managed_tenant_id", GUID(), sa.ForeignKey("managed_tenants.id"), nullable=False),
        sa.Column("source_object_id", sa.String(64), nullable=False),
        sa.Column("display_name", sa.String(128), nullable=False),
        sa.Column("user_principal_name", sa.String(256), nullable=False),
        sa.Column("account_enabled", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("managed_tenant_id", "source_object_id", name="uq_account_tenant_source_object"),
    )
    op.create_index("ix_accounts_environment_id", "accounts", ["environment_id"])
    op.create_index("ix_accounts_managed_tenant_id", "accounts", ["managed_tenant_id"])

    if not _is_postgres():
        return

    for table in (
        "environment_roles",
        "role_permissions",
        "environment_memberships",
        "role_assignments",
        "environment_local_logins",
        "environment_audit_logs",
        "membership_tenant_grants",
    ):
        _environment_policy(table)

    _tenant_policy("managed_tenants", "id")
    _tenant_policy("tenant_connections", "managed_tenant_id")
    _tenant_policy("accounts", "managed_tenant_id")


def downgrade() -> None:
    op.drop_table("accounts")
    op.drop_table("tenant_connections")
    op.drop_table("membership_tenant_grants")
    op.drop_table("managed_tenants")
    op.drop_table("environment_audit_logs")
    op.drop_table("environment_local_logins")
    op.drop_table("role_assignments")
    op.drop_table("environment_memberships")
    op.drop_table("role_permissions")
    op.drop_table("environment_roles")
    op.drop_table("management_environments")
    op.drop_table("permissions")
    op.drop_table("platform_role_assignments")
    op.drop_table("platform_local_logins")
    op.drop_table("external_logins")
    op.drop_table("principals")
