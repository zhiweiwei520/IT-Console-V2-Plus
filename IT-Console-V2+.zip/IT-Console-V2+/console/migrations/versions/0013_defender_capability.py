"""add tenant-scoped Defender security alert quick audit"""
from alembic import op
import sqlalchemy as sa
from app.storage.types import GUID
revision,down_revision="0013","0012"; branch_labels=depends_on=None
def policy(table):
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY"); op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY"); expr="environment_id::text = current_setting('app.environment_id', true) AND managed_tenant_id::text = current_setting('app.managed_tenant_id', true)"; op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING ({expr}) WITH CHECK ({expr})")
def upgrade():
    op.create_table("defender_alerts",sa.Column("id",GUID(),primary_key=True),sa.Column("environment_id",GUID(),sa.ForeignKey("management_environments.id"),nullable=False),sa.Column("managed_tenant_id",GUID(),sa.ForeignKey("managed_tenants.id"),nullable=False),sa.Column("source_object_id",sa.String(128),nullable=False),sa.Column("title",sa.String(512),nullable=False),sa.Column("category",sa.String(128)),sa.Column("severity",sa.String(32)),sa.Column("status",sa.String(32)),sa.Column("created_datetime",sa.DateTime(),nullable=False),sa.Column("last_update_datetime",sa.DateTime()),sa.Column("service_source",sa.String(128)),sa.Column("detection_source",sa.String(128)),sa.Column("description",sa.Text()),sa.Column("alert_web_url",sa.String(1024)),sa.Column("created_at",sa.DateTime(),nullable=False),sa.Column("updated_at",sa.DateTime(),nullable=False),sa.UniqueConstraint("managed_tenant_id","source_object_id",name="uq_defender_alert_tenant_source"))
    op.create_table("defender_sync_checkpoints",sa.Column("id",GUID(),primary_key=True),sa.Column("job_id",GUID(),sa.ForeignKey("durable_jobs.id"),nullable=False,unique=True),sa.Column("environment_id",GUID(),sa.ForeignKey("management_environments.id"),nullable=False),sa.Column("managed_tenant_id",GUID(),sa.ForeignKey("managed_tenants.id"),nullable=False),sa.Column("window_start",sa.String(32)),sa.Column("next_resource",sa.String(2048)),sa.Column("processed_count",sa.Integer(),nullable=False),sa.Column("status",sa.String(16),nullable=False),sa.Column("started_at",sa.DateTime(),nullable=False),sa.Column("updated_at",sa.DateTime(),nullable=False),sa.Column("completed_at",sa.DateTime()))
    op.create_index("ix_defender_alerts_tenant_created","defender_alerts",["managed_tenant_id","created_datetime"])
    for table in ("defender_alerts","defender_sync_checkpoints"):
        op.create_index(f"ix_{table}_environment_id",table,["environment_id"]); op.create_index(f"ix_{table}_managed_tenant_id",table,["managed_tenant_id"])
        if op.get_bind().dialect.name=="postgresql": policy(table)
def downgrade(): op.drop_table("defender_sync_checkpoints"); op.drop_table("defender_alerts")
