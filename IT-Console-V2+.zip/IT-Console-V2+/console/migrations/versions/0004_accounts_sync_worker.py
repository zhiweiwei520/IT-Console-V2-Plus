"""add accounts sync checkpoint and marker

Revision ID: 0004
Revises: 0003
Create Date: 2026-07-11
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from app.storage.types import GUID

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def _is_postgres() -> bool:
    return op.get_bind().dialect.name == "postgresql"


def upgrade() -> None:
    op.add_column("accounts", sa.Column("last_seen_sync_id", GUID(), nullable=True))
    op.create_index("ix_accounts_last_seen_sync_id", "accounts", ["last_seen_sync_id"])

    op.create_table(
        "account_sync_checkpoints",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("job_id", GUID(), sa.ForeignKey("durable_jobs.id"), nullable=False, unique=True),
        sa.Column(
            "environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False,
        ),
        sa.Column("managed_tenant_id", GUID(), sa.ForeignKey("managed_tenants.id"), nullable=False),
        sa.Column("next_resource", sa.String(2048), nullable=True),
        sa.Column("processed_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("status", sa.String(16), nullable=False, server_default="running"),
        sa.Column("started_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("completed_at", sa.DateTime(), nullable=True),
    )
    op.create_index(
        "ix_account_sync_checkpoints_environment_id", "account_sync_checkpoints", ["environment_id"],
    )
    op.create_index(
        "ix_account_sync_checkpoints_managed_tenant_id",
        "account_sync_checkpoints",
        ["managed_tenant_id"],
    )

    if _is_postgres():
        op.execute("ALTER TABLE account_sync_checkpoints ENABLE ROW LEVEL SECURITY")
        op.execute("ALTER TABLE account_sync_checkpoints FORCE ROW LEVEL SECURITY")
        tenant_expr = (
            "environment_id::text = current_setting('app.environment_id', true) AND "
            "managed_tenant_id::text = current_setting('app.managed_tenant_id', true)"
        )
        op.execute(
            "CREATE POLICY account_sync_checkpoints_tenant_isolation "
            f"ON account_sync_checkpoints USING ({tenant_expr}) WITH CHECK ({tenant_expr})"
        )


def downgrade() -> None:
    op.drop_table("account_sync_checkpoints")
    op.drop_index("ix_accounts_last_seen_sync_id", table_name="accounts")
    op.drop_column("accounts", "last_seen_sync_id")
