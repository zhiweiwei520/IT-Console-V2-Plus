"""add environment-scoped durable job queue

Revision ID: 0003
Revises: 0002
Create Date: 2026-07-11
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from app.storage.types import GUID

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def _is_postgres() -> bool:
    return op.get_bind().dialect.name == "postgresql"


def _enable_environment_rls(table: str) -> None:
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
    expr = "environment_id::text = current_setting('app.environment_id', true)"
    op.execute(
        f"CREATE POLICY {table}_environment_isolation ON {table} "
        f"USING ({expr}) WITH CHECK ({expr})"
    )


def upgrade() -> None:
    op.create_table(
        "durable_jobs",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column(
            "environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False,
        ),
        sa.Column("managed_tenant_id", GUID(), sa.ForeignKey("managed_tenants.id"), nullable=True),
        sa.Column("execution_id", GUID(), nullable=True),
        sa.Column("schema_version", sa.SmallInteger(), nullable=False, server_default="1"),
        sa.Column("job_type", sa.String(64), nullable=False),
        sa.Column("job_version", sa.SmallInteger(), nullable=False, server_default="1"),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("idempotency_key", sa.String(160), nullable=False),
        sa.Column("status", sa.String(16), nullable=False, server_default="queued"),
        sa.Column("attempt", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("max_attempts", sa.Integer(), nullable=False, server_default="5"),
        sa.Column("available_at", sa.DateTime(), nullable=False),
        sa.Column("lease_owner", sa.String(128), nullable=True),
        sa.Column("lease_expires_at", sa.DateTime(), nullable=True),
        sa.Column("trace_id", sa.String(64), nullable=True),
        sa.Column("last_error", sa.String(512), nullable=True),
        sa.Column("requested_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("completed_at", sa.DateTime(), nullable=True),
        sa.UniqueConstraint(
            "environment_id", "idempotency_key", name="uq_durable_job_env_idempotency",
        ),
    )
    op.create_index("ix_durable_jobs_environment_id", "durable_jobs", ["environment_id"])
    op.create_index("ix_durable_jobs_managed_tenant_id", "durable_jobs", ["managed_tenant_id"])
    op.create_index("ix_durable_jobs_execution_id", "durable_jobs", ["execution_id"])
    op.create_index("ix_durable_jobs_job_type", "durable_jobs", ["job_type"])
    op.create_index("ix_durable_jobs_status", "durable_jobs", ["status"])
    op.create_index("ix_durable_jobs_available_at", "durable_jobs", ["available_at"])
    op.create_index("ix_durable_jobs_lease_expires_at", "durable_jobs", ["lease_expires_at"])
    op.create_index(
        "ix_durable_jobs_env_claim",
        "durable_jobs",
        ["environment_id", "status", "available_at", "lease_expires_at"],
    )

    op.create_table(
        "job_dead_letters",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("job_id", GUID(), sa.ForeignKey("durable_jobs.id"), nullable=False, unique=True),
        sa.Column(
            "environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False,
        ),
        sa.Column("managed_tenant_id", GUID(), sa.ForeignKey("managed_tenants.id"), nullable=True),
        sa.Column("job_type", sa.String(64), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("attempts", sa.Integer(), nullable=False),
        sa.Column("reason", sa.String(512), nullable=False),
        sa.Column("dead_lettered_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_job_dead_letters_environment_id", "job_dead_letters", ["environment_id"])
    op.create_index("ix_job_dead_letters_managed_tenant_id", "job_dead_letters", ["managed_tenant_id"])

    if _is_postgres():
        _enable_environment_rls("durable_jobs")
        _enable_environment_rls("job_dead_letters")


def downgrade() -> None:
    op.drop_table("job_dead_letters")
    op.drop_table("durable_jobs")
