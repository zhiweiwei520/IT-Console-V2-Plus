"""add per-environment audit hash chain

Revision ID: 0002
Revises: 0001
Create Date: 2026-07-11
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime
import hashlib
import json
import uuid

import sqlalchemy as sa
from alembic import op

from app.storage.types import GUID

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

GENESIS_HASH = "0" * 64


def _is_postgres() -> bool:
    return op.get_bind().dialect.name == "postgresql"


def _uuid_text(value) -> str | None:
    return str(uuid.UUID(str(value))) if value is not None else None


def _timestamp_text(value: datetime) -> str:
    return value.isoformat(timespec="microseconds")


def _entry_hash(row, *, sequence: int, previous_hash: str) -> str:
    payload = {
        "action": row["action"],
        "actor_principal_id": _uuid_text(row["actor_principal_id"]),
        "chain_sequence": sequence,
        "correlation_id": row["correlation_id"],
        "created_at": _timestamp_text(row["created_at"]),
        "entry_id": _uuid_text(row["id"]),
        "environment_id": _uuid_text(row["environment_id"]),
        "hash_version": 1,
        "outcome": row["outcome"],
        "previous_hash": previous_hash,
        "reason": row["reason"],
        "target_id": row["target_id"],
        "target_type": row["target_type"],
    }
    encoded = json.dumps(
        payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def upgrade() -> None:
    op.add_column("environment_audit_logs", sa.Column("chain_sequence", sa.BigInteger(), nullable=True))
    op.add_column("environment_audit_logs", sa.Column("previous_hash", sa.String(64), nullable=True))
    op.add_column("environment_audit_logs", sa.Column("entry_hash", sa.String(64), nullable=True))
    op.add_column(
        "environment_audit_logs",
        sa.Column("hash_version", sa.SmallInteger(), nullable=True, server_default="1"),
    )

    op.create_table(
        "environment_audit_chain_heads",
        sa.Column(
            "environment_id", GUID(), sa.ForeignKey("management_environments.id"), primary_key=True,
        ),
        sa.Column("last_sequence", sa.BigInteger(), nullable=False, server_default="0"),
        sa.Column("last_hash", sa.String(64), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
    )

    bind = op.get_bind()
    if _is_postgres():
        op.execute("ALTER TABLE environment_audit_logs DISABLE ROW LEVEL SECURITY")

    audit = sa.table(
        "environment_audit_logs",
        sa.column("id", GUID()),
        sa.column("environment_id", GUID()),
        sa.column("actor_principal_id", GUID()),
        sa.column("action", sa.String()),
        sa.column("target_type", sa.String()),
        sa.column("target_id", sa.String()),
        sa.column("outcome", sa.String()),
        sa.column("reason", sa.String()),
        sa.column("correlation_id", sa.String()),
        sa.column("created_at", sa.DateTime()),
        sa.column("chain_sequence", sa.BigInteger()),
        sa.column("previous_hash", sa.String()),
        sa.column("entry_hash", sa.String()),
        sa.column("hash_version", sa.SmallInteger()),
    )
    heads = sa.table(
        "environment_audit_chain_heads",
        sa.column("environment_id", GUID()),
        sa.column("last_sequence", sa.BigInteger()),
        sa.column("last_hash", sa.String()),
        sa.column("updated_at", sa.DateTime()),
    )

    grouped = defaultdict(list)
    rows = bind.execute(sa.select(audit)).mappings().all()
    for row in rows:
        grouped[_uuid_text(row["environment_id"])].append(row)

    for environment_rows in grouped.values():
        environment_rows.sort(key=lambda row: (row["created_at"], _uuid_text(row["id"])))
        previous_hash = GENESIS_HASH
        for sequence, row in enumerate(environment_rows, start=1):
            entry_hash = _entry_hash(row, sequence=sequence, previous_hash=previous_hash)
            bind.execute(
                audit.update().where(audit.c.id == row["id"]).values(
                    chain_sequence=sequence,
                    previous_hash=previous_hash,
                    entry_hash=entry_hash,
                    hash_version=1,
                )
            )
            previous_hash = entry_hash
        final = environment_rows[-1]
        bind.execute(heads.insert().values(
            environment_id=final["environment_id"],
            last_sequence=len(environment_rows),
            last_hash=previous_hash,
            updated_at=final["created_at"],
        ))

    with op.batch_alter_table("environment_audit_logs") as batch_op:
        batch_op.alter_column("chain_sequence", existing_type=sa.BigInteger(), nullable=False)
        batch_op.alter_column("previous_hash", existing_type=sa.String(64), nullable=False)
        batch_op.alter_column("entry_hash", existing_type=sa.String(64), nullable=False)
        batch_op.alter_column("hash_version", existing_type=sa.SmallInteger(), nullable=False)
        batch_op.create_unique_constraint(
            "uq_audit_log_env_chain_sequence", ["environment_id", "chain_sequence"],
        )

    if _is_postgres():
        op.execute("ALTER TABLE environment_audit_logs ENABLE ROW LEVEL SECURITY")
        op.execute("ALTER TABLE environment_audit_logs FORCE ROW LEVEL SECURITY")
        op.execute("ALTER TABLE environment_audit_chain_heads ENABLE ROW LEVEL SECURITY")
        op.execute("ALTER TABLE environment_audit_chain_heads FORCE ROW LEVEL SECURITY")
        expr = "environment_id::text = current_setting('app.environment_id', true)"
        op.execute(
            "CREATE POLICY environment_audit_chain_heads_environment_isolation "
            f"ON environment_audit_chain_heads USING ({expr}) WITH CHECK ({expr})"
        )


def downgrade() -> None:
    op.drop_table("environment_audit_chain_heads")
    with op.batch_alter_table("environment_audit_logs") as batch_op:
        batch_op.drop_constraint("uq_audit_log_env_chain_sequence", type_="unique")
        batch_op.drop_column("hash_version")
        batch_op.drop_column("entry_hash")
        batch_op.drop_column("previous_hash")
        batch_op.drop_column("chain_sequence")
