"""add tenant_connections.encrypted_client_secret for BYO app self-service credential entry

Revision ID: 0005
Revises: 0004
Create Date: 2026-07-11

支援環境管理者透過網頁表單自助輸入 BYO app client secret（無需維運人員先手動設定 OS
環境變數）。密文欄位本身不套 RLS 額外邏輯——tenant_connections 表已有的 environment_id
+ managed_tenant_id tenant policy（見 0001 migration）已涵蓋這一欄。
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "tenant_connections",
        sa.Column("encrypted_client_secret", sa.Text(), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("tenant_connections", "encrypted_client_secret")
