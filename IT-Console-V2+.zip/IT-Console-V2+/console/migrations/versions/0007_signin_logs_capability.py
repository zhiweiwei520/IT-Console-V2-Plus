"""add signin_logs capability (Entra sign-in logs, incremental) + sync checkpoint

Revision ID: 0007
Revises: 0006
Create Date: 2026-07-11

sign_in_logs 為 tenant-scoped 快取表（RLS 樣式比照 0001 accounts/_tenant_policy）。
與 accounts/devices 不同：append-only 增量，無 last_seen_sync_id 欄位、無 full-sync 刪除。
sign_in_log_sync_checkpoints 只由 Worker 寫入，比照 0004 的 environment+tenant 直接比對樣式，
額外多一個 window_start（本次增量的 createdDateTime 下界）。
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from app.storage.types import GUID

revision = "0007"
down_revision = "0006"
branch_labels = None
depends_on = None


def _is_postgres() -> bool:
    return op.get_bind().dialect.name == "postgresql"


def _tenant_grant_exists_sql(table: str, tenant_id_expr: str) -> str:
    return (
        "EXISTS (SELECT 1 FROM environment_memberships m "
        f"WHERE m.environment_id = {table}.environment_id "
        "AND m.principal_id::text = current_setting('app.principal_id', true) "
        "AND m.status = 'active' "
        "AND (m.all_managed_tenants = true OR EXISTS ("
        "SELECT 1 FROM membership_tenant_grants g "
        f"WHERE g.membership_id = m.id AND g.managed_tenant_id = {tenant_id_expr})))"
    )


def _tenant_policy(table: str, tenant_id_column: str) -> None:
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
    tenant_id_expr = f"{table}.{tenant_id_column}"
    grant_check = _tenant_grant_exists_sql(table, tenant_id_expr)
    expr = (
        "environment_id::text = current_setting('app.environment_id', true) "
        "AND (("
        "current_setting('app.managed_tenant_id', true) <> '' "
        f"AND {tenant_id_expr}::text = current_setting('app.managed_tenant_id', true)"
        ") OR ("
        "current_setting('app.managed_tenant_id', true) = '' "
        f"AND {grant_check}"
        "))"
    )
    op.execute(
        f"CREATE POLICY {table}_tenant_isolation ON {table} "
        f"USING ({expr}) WITH CHECK ({expr})"
    )


def upgrade() -> None:
    op.create_table(
        "sign_in_logs",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False),
        sa.Column("managed_tenant_id", GUID(), sa.ForeignKey("managed_tenants.id"), nullable=False),
        sa.Column("source_object_id", sa.String(64), nullable=False),
        sa.Column("created_datetime", sa.DateTime(), nullable=False),
        sa.Column("user_principal_name", sa.String(256), nullable=True),
        sa.Column("user_display_name", sa.String(256), nullable=True),
        sa.Column("app_display_name", sa.String(256), nullable=True),
        sa.Column("ip_address", sa.String(64), nullable=True),
        sa.Column("client_app_used", sa.String(64), nullable=True),
        sa.Column("status", sa.String(16), nullable=True),
        sa.Column("failure_reason", sa.String(256), nullable=True),
        sa.Column("conditional_access_status", sa.String(32), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("managed_tenant_id", "source_object_id", name="uq_signin_tenant_source_object"),
    )
    op.create_index("ix_sign_in_logs_environment_id", "sign_in_logs", ["environment_id"])
    op.create_index("ix_sign_in_logs_managed_tenant_id", "sign_in_logs", ["managed_tenant_id"])
    op.create_index(
        "ix_sign_in_logs_tenant_created", "sign_in_logs", ["managed_tenant_id", "created_datetime"],
    )

    op.create_table(
        "sign_in_log_sync_checkpoints",
        sa.Column("id", GUID(), primary_key=True),
        sa.Column("job_id", GUID(), sa.ForeignKey("durable_jobs.id"), nullable=False, unique=True),
        sa.Column(
            "environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False,
        ),
        sa.Column("managed_tenant_id", GUID(), sa.ForeignKey("managed_tenants.id"), nullable=False),
        sa.Column("window_start", sa.String(32), nullable=True),
        sa.Column("next_resource", sa.String(2048), nullable=True),
        sa.Column("processed_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("status", sa.String(16), nullable=False, server_default="running"),
        sa.Column("started_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("completed_at", sa.DateTime(), nullable=True),
    )
    op.create_index(
        "ix_sign_in_log_sync_checkpoints_environment_id",
        "sign_in_log_sync_checkpoints",
        ["environment_id"],
    )
    op.create_index(
        "ix_sign_in_log_sync_checkpoints_managed_tenant_id",
        "sign_in_log_sync_checkpoints",
        ["managed_tenant_id"],
    )

    if not _is_postgres():
        return

    _tenant_policy("sign_in_logs", "managed_tenant_id")

    op.execute("ALTER TABLE sign_in_log_sync_checkpoints ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE sign_in_log_sync_checkpoints FORCE ROW LEVEL SECURITY")
    tenant_expr = (
        "environment_id::text = current_setting('app.environment_id', true) AND "
        "managed_tenant_id::text = current_setting('app.managed_tenant_id', true)"
    )
    op.execute(
        "CREATE POLICY sign_in_log_sync_checkpoints_tenant_isolation "
        f"ON sign_in_log_sync_checkpoints USING ({tenant_expr}) WITH CHECK ({tenant_expr})"
    )


def downgrade() -> None:
    op.drop_table("sign_in_log_sync_checkpoints")
    op.drop_table("sign_in_logs")
