"""add tenant-scoped license and MFA audit capability"""
from alembic import op
import sqlalchemy as sa
from app.storage.types import GUID

revision, down_revision = "0008", "0007"
branch_labels = depends_on = None


def _tenant_policy(table):
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
    expr = (
        "environment_id::text = current_setting('app.environment_id', true) AND "
        "managed_tenant_id::text = current_setting('app.managed_tenant_id', true)"
    )
    op.execute(f"CREATE POLICY {table}_tenant_isolation ON {table} USING ({expr}) WITH CHECK ({expr})")

def upgrade():
    def common(): return [sa.Column("id", GUID(), primary_key=True), sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False), sa.Column("managed_tenant_id", GUID(), sa.ForeignKey("managed_tenants.id"), nullable=False), sa.Column("source_object_id", sa.String(64), nullable=False)]
    op.create_table("license_skus", *common(), sa.Column("sku_part_number", sa.String(128), nullable=False), sa.Column("capability_status", sa.String(32)), sa.Column("enabled_units", sa.Integer(), nullable=False), sa.Column("consumed_units", sa.Integer(), nullable=False), sa.Column("warning_units", sa.Integer(), nullable=False), sa.Column("suspended_units", sa.Integer(), nullable=False), sa.Column("last_seen_sync_id", GUID()), sa.Column("created_at", sa.DateTime(), nullable=False), sa.Column("updated_at", sa.DateTime(), nullable=False), sa.UniqueConstraint("managed_tenant_id", "source_object_id", name="uq_license_sku_tenant_source"))
    op.create_table("mfa_registrations", *common(), sa.Column("user_principal_name", sa.String(256), nullable=False), sa.Column("user_display_name", sa.String(256)), sa.Column("is_mfa_registered", sa.Boolean(), nullable=False), sa.Column("is_mfa_capable", sa.Boolean(), nullable=False), sa.Column("methods_registered", sa.String(512)), sa.Column("last_seen_sync_id", GUID()), sa.Column("created_at", sa.DateTime(), nullable=False), sa.Column("updated_at", sa.DateTime(), nullable=False), sa.UniqueConstraint("managed_tenant_id", "source_object_id", name="uq_mfa_registration_tenant_source"))
    op.create_table("license_audit_checkpoints", sa.Column("id", GUID(), primary_key=True), sa.Column("job_id", GUID(), sa.ForeignKey("durable_jobs.id"), nullable=False, unique=True), sa.Column("environment_id", GUID(), sa.ForeignKey("management_environments.id"), nullable=False), sa.Column("managed_tenant_id", GUID(), sa.ForeignKey("managed_tenants.id"), nullable=False), sa.Column("phase", sa.String(16), nullable=False), sa.Column("next_resource", sa.String(2048)), sa.Column("processed_count", sa.Integer(), nullable=False), sa.Column("status", sa.String(16), nullable=False), sa.Column("started_at", sa.DateTime(), nullable=False), sa.Column("updated_at", sa.DateTime(), nullable=False), sa.Column("completed_at", sa.DateTime()))
    for table in ("license_skus", "mfa_registrations", "license_audit_checkpoints"):
        op.create_index(f"ix_{table}_environment_id", table, ["environment_id"]); op.create_index(f"ix_{table}_managed_tenant_id", table, ["managed_tenant_id"])
    if op.get_bind().dialect.name == "postgresql":
        for table in ("license_skus", "mfa_registrations", "license_audit_checkpoints"):
            _tenant_policy(table)

def downgrade():
    op.drop_table("license_audit_checkpoints"); op.drop_table("mfa_registrations"); op.drop_table("license_skus")
