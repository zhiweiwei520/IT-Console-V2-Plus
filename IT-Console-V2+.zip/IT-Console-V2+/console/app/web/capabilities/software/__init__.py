"""Software inventory web package."""
