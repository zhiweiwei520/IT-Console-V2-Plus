"""Dashboard web package."""
