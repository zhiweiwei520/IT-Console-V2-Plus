# Changelog

## Unreleased

### Changed
- **V2+ console**：多 Tenant 管理改為 server-side session 鎖定單一目前 Tenant；切換環境、登出或授權失效會清除 Tenant，功能頁參數不可覆寫，所有既有與後續模組禁止跨 Tenant 同時管理。導覽改為 IT Console V2 同型左側階層式 sidebar。
