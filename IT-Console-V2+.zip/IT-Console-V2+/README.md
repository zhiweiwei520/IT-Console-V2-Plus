# IT Console V2+ 前置評估與開發文件

> 文件狀態：Proposed  
> 基線日期：2026-07-10（UTC+8）  
> 適用範圍：純 Microsoft Entra ID／Azure／Microsoft 365 管理版本，以及後續 SaaS 版本

## 1. 結論摘要

V2+ 不應直接由現行單 Tenant 架構加上 `tenant_id` 後上線。現行登入身分、RBAC、Graph 憑證、設定、快取、排程、報表、稽核鏈與檔案路徑皆是全域範圍，必須一起建立管理環境與受管 Tenant 邊界。

建議以現有 Flask 程式為基礎，採「模組化單體 + 獨立背景 Worker」，不進行一次性框架重寫。SaaS 目標架構採：

- 共享 Control Plane：管理客戶、管理環境、方案、部署位置與生命週期。
- Deployment Stamp Data Plane：承載一個或多個管理環境。
- `ManagementEnvironment`：客戶的獨立管理邊界。
- `ManagedTenant`：環境內被管理的 Entra Tenant；一個環境可管理多個。
- 分級隔離：標準方案使用共享 Stamp + PostgreSQL RLS；專屬方案可升級為獨立資料庫或獨立 Stamp，程式碼不分叉。

## 2. 已確認前提

1. 平台系統管理認證沿用現行本地登入、Entra SSO、Flask-Login、signed-cookie session + DB active-session registry、鎖定、閒置逾時、CSRF 與 RBAC。
2. 「沿用」不代表沿用現有全域資料表；Principal 為全域身分，Membership、角色、direct grant 與資料權限改為 Environment 範圍。Environment 管理者是否仍可使用本地帳號列為 D-03 產品決策，不在文件中默認取消。
3. Microsoft 功能涵蓋 Entra ID、Microsoft Graph、Intune、Teams、SharePoint、Defender、Azure Monitor／Log Analytics。
4. V2+ 首版維持唯讀稽核／查詢定位；任何寫入客戶 Tenant 的能力須另案評估權限與風險。
5. Azure Public Cloud 為首發環境；GCC、China 等 Sovereign Cloud 僅保留模型擴充點。
6. SaaS 管理環境可為邏輯隔離或實體專屬，但必須共用同一版產品與自動化部署流程。

## 3. 文件導覽

| 文件 | 用途 | 主要決策 |
|---|---|---|
| [01-current-state-and-scope.md](./01-current-state-and-scope.md) | 現況、功能邊界、技術缺口 | 保留／重構／移除範圍 |
| [02-target-architecture.md](./02-target-architecture.md) | Control Plane、Stamp、元件與資料流 | 目標部署與服務邊界 |
| [03-tenancy-identity-data.md](./03-tenancy-identity-data.md) | 多環境、多 Tenant、多人與資料模型 | 身分、RBAC、RLS、資料隔離 |
| [04-microsoft-connection-and-consent.md](./04-microsoft-connection-and-consent.md) | Graph App、Admin Consent、Token 與同步 | 平台登入與受管連線分離 |
| [05-security-operations.md](./05-security-operations.md) | 安全、秘密、稽核、可觀測性、BCDR | SaaS 營運基線 |
| [06-migration-roadmap.md](./06-migration-roadmap.md) | 分支、資料遷移、階段與退場流程 | 可回復的實作順序 |
| [07-testing-acceptance.md](./07-testing-acceptance.md) | 測試策略與驗收門檻 | 跨環境洩漏零容忍 |
| [08-decision-log-and-backlog.md](./08-decision-log-and-backlog.md) | ADR、待決策事項與 Epic backlog | 開發啟動清單 |
| [09-development-standards.md](./09-development-standards.md) | V2+ 程式與 API 規約 | Tenant context、migration、訊息格式 |
| [10-requirement-traceability.md](./10-requirement-traceability.md) | 需求到證據追蹤 | Requirement → ADR → Epic → Test → Evidence → Owner |
| [11-final-architecture.md](./11-final-architecture.md) | 審查整合、可行性、FastAPI 評估與最終架構定案 | MVP cut、Go/No-Go gate、ADR-007、D-17～D-19、Anti-Slop 前端反模板、Δ 修正清單 |

## 4. 建議立刻定案的三件事

1. `ManagementEnvironment` 的付費隔離選項：共享 DB + RLS、獨立 DB、獨立 Stamp。
2. 受管 Tenant Graph 授權模式：SaaS Provider 多租戶 App、客戶自帶 App，或雙模式。
3. 客戶管理者是否可用其所屬 Entra Tenant 登入 V2+；若是，需立即採 unique `(canonical_issuer, subject)`，並另存 Tenant／object ID 的身分模型。

## 5. 成功標準

- 同一管理環境可安全管理多個 Entra Tenant 與多位使用者。
- 同一使用者可加入多個管理環境，且每個環境可有不同角色與 Tenant 授權。
- 即使知道其他環境的 UUID、Graph ID 或報表路徑，也無法讀取、修改或推測其資料。
- 單一 Tenant 的 Graph 429、撤銷同意或大量工作不影響其他 Tenant。
- 標準與專屬環境由同一映像、同一 migration 與同一 IaC 佈署。
- 所有管理、同步、匯出與支援操作均可追溯至環境、受管 Tenant、操作者與 correlation ID。

## 6. 官方設計依據

- [Azure 多租戶架構檢查表](https://learn.microsoft.com/en-us/azure/architecture/guide/multitenant/checklist)
- [Deployment Stamps pattern](https://learn.microsoft.com/en-us/azure/architecture/patterns/deployment-stamp)
- [多租戶 Control Plane 考量](https://learn.microsoft.com/en-us/azure/architecture/guide/multitenant/considerations/control-planes)
- [Microsoft identity platform Admin Consent](https://learn.microsoft.com/en-us/entra/identity-platform/v2-admin-consent)
- [Microsoft Graph throttling guidance](https://learn.microsoft.com/en-us/graph/throttling)
- [Azure Database for PostgreSQL 多租戶指引](https://learn.microsoft.com/en-gb/azure/architecture/guide/multitenant/service/postgresql)
